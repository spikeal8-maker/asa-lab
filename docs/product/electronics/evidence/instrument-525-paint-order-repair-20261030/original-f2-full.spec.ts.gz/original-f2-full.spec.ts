import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { expect, test, type Page } from '@playwright/test';
import pg from 'pg';
import type { SchematicDocument } from '../apps/web/src/api';
import {
  localProjectDraftFingerprint,
  localProjectDraftKey,
  readLocalProjectDraftEntry,
} from '../apps/web/src/modules/project-local-draft';
import { collectBrowserFailures } from './browser-failures';
import { loginWithOrganization } from './organization-login';
import { e2eAdminPool, seedTeacher, type SeededTeacher } from './seed';

const ARTIFACT_DIR = 'e2e/artifacts/electronics-simulation';
const persistenceVideoTest = test.extend({ video: 'on' });

let admin: pg.Pool;
let teacher: SeededTeacher;

interface OwnerCatalogFixture {
  readonly components: ReadonlyArray<{
    readonly componentId: string;
    readonly pins: ReadonlyArray<{ readonly id: string }>;
  }>;
}

const ownerCatalog = JSON.parse(
  readFileSync(
    resolve(process.cwd(), 'apps/web/public/assets/electronics/owner-catalog/manifest.json'),
    'utf8',
  ),
) as OwnerCatalogFixture;
const breadboardPinIds = ownerCatalog.components
  .find((component) => component.componentId === 'breadboard-medium')
  ?.pins.map((pin) => pin.id);

if (!breadboardPinIds) throw new Error('breadboard-medium owner manifest entry is missing');

function circuitDocument(options: {
  readonly switchClosed: boolean;
  readonly resistorOhms: number;
  readonly reversedLed: boolean;
  readonly running?: boolean;
}): SchematicDocument {
  const ledInput = options.reversedLed ? 'cathode' : 'anode';
  const ledReturn = options.reversedLed ? 'anode' : 'cathode';
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-2',
        variantId: 'battery-holder-aa-2',
        name: 'Источник 3 В',
        position: { x: 70, y: 110 },
        rotation: 0,
        value: 3,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 2 },
      },
      {
        id: 'board',
        kind: 'breadboard',
        componentTypeId: 'breadboard-medium',
        variantId: 'breadboard-medium',
        name: 'Макетная плата',
        position: { x: 260, y: 380 },
        rotation: 0,
        value: 0,
        pinIds: ['J1', 'I1'],
        internalConnections: [['J1', 'I1']],
        stateProperties: {},
      },
      {
        id: 'switch',
        kind: 'switch',
        componentTypeId: 'switch-spdt',
        variantId: 'switch-spdt',
        name: 'SW1',
        position: { x: 390, y: 120 },
        rotation: 0,
        value: 0,
        state: options.switchClosed,
        pinIds: ['throw-left', 'common', 'throw-right'],
        stateProperties: { selectedThrow: options.switchClosed ? 'right' : 'left' },
      },
      {
        id: 'resistor',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'R1',
        position: { x: 610, y: 150 },
        rotation: 90,
        value: options.resistorOhms,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'Ом' },
      },
      {
        id: 'led',
        kind: 'led',
        componentTypeId: 'led-5mm',
        variantId: 'led-5mm',
        name: 'LED1',
        position: { x: 790, y: 140 },
        rotation: 0,
        value: 2,
        pinIds: ['anode', 'cathode'],
        stateProperties: { ledColour: 'red', ledBrightness: 0, ledFault: 'none' },
      },
    ],
    connections: [
      {
        id: 'wire-source-board',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'board', terminal: 'J1' },
        color: '#e3212b',
        vertices: [{ x: 230, y: 300 }],
      },
      {
        id: 'wire-board-switch',
        from: { componentId: 'board', terminal: 'I1' },
        to: { componentId: 'switch', terminal: 'common' },
        color: '#e3212b',
        vertices: [{ x: 430, y: 320 }],
      },
      {
        id: 'wire-switch-resistor',
        from: { componentId: 'switch', terminal: 'throw-right' },
        to: { componentId: 'resistor', terminal: 'lead-1' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'wire-resistor-led',
        from: { componentId: 'resistor', terminal: 'lead-2' },
        to: { componentId: 'led', terminal: ledInput },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'wire-led-source',
        from: { componentId: 'led', terminal: ledReturn },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [
          { x: 820, y: 330 },
          { x: 160, y: 330 },
        ],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: options.running ?? false, maxIterations: 24 },
  };
}

function diodeProfileDocument(componentTypeId: 'diode-do35' | 'diode-do41'): SchematicDocument {
  const seeded = circuitDocument({ switchClosed: true, resistorOhms: 220, reversedLed: false });
  return {
    ...seeded,
    components: seeded.components.map((item) =>
      item.id === 'led'
        ? {
            ...item,
            kind: 'diode' as const,
            componentTypeId,
            variantId: componentTypeId,
            name: componentTypeId === 'diode-do41' ? 'Диод DO-41' : 'Диод DO-35',
            value: 0.7,
            pinIds: ['anode', 'cathode'],
            stateProperties: {},
          }
        : item,
    ),
  };
}

function photoresistorDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-2',
        variantId: 'battery-holder-aa-2',
        name: 'Источник 3 В',
        position: { x: 150, y: 360 },
        rotation: 0,
        value: 3,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 2 },
      },
      {
        id: 'resistor',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'R1 10 кОм',
        position: { x: 520, y: 170 },
        rotation: 90,
        value: 10_000,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'кОм' },
      },
      {
        id: 'ldr',
        kind: 'photoresistor',
        componentTypeId: 'photoresistor',
        variantId: 'photoresistor',
        name: 'Фоторезистор',
        position: { x: 740, y: 190 },
        rotation: 0,
        value: 15_000,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { illumination: 0.5 },
      },
    ],
    connections: [
      {
        id: 'positive-resistor',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'resistor', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'resistor-ldr',
        from: { componentId: 'resistor', terminal: 'lead-2' },
        to: { componentId: 'ldr', terminal: 'lead-1' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'ldr-negative',
        from: { componentId: 'ldr', terminal: 'lead-2' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function incandescentLampDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-4',
        variantId: 'battery-holder-aa-4',
        name: 'Источник 6 В',
        position: { x: 190, y: 340 },
        rotation: 0,
        value: 6,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 4 },
      },
      {
        id: 'lamp',
        kind: 'lamp',
        componentTypeId: 'incandescent-lamp',
        variantId: 'incandescent-lamp',
        name: 'Лампа накаливания',
        position: { x: 650, y: 220 },
        rotation: 0,
        value: 6,
        pinIds: ['L1', 'L2'],
        stateProperties: { lampLevel: 'off' },
      },
    ],
    connections: [
      {
        id: 'positive-lamp',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'lamp', terminal: 'L1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'lamp-negative',
        from: { componentId: 'lamp', terminal: 'L2' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function npnKeyDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-3',
        variantId: 'battery-holder-aa-3',
        name: 'Источник 4,5 В',
        position: { x: 120, y: 300 },
        rotation: 0,
        value: 4.5,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 3 },
      },
      {
        id: 'rb',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'Rbase 100 кОм',
        position: { x: 360, y: 180 },
        rotation: 90,
        value: 100_000,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'кОм' },
      },
      {
        id: 'rc',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'Rcollector 470 Ом',
        position: { x: 570, y: 180 },
        rotation: 90,
        value: 470,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'Ом' },
      },
      {
        id: 'q1',
        kind: 'transistor',
        componentTypeId: 'transistor-npn',
        variantId: 'transistor-npn',
        name: 'NPN-транзистор',
        position: { x: 610, y: 350 },
        rotation: 0,
        value: 100,
        pinIds: ['collector', 'base', 'emitter'],
        stateProperties: {
          transistorType: 'npn',
          currentGain: 100,
          baseEmitterVoltage: 0.7,
          saturationVoltage: 0.2,
          earlyVoltage: 100,
          maxCollectorCurrent: 0.2,
        },
      },
    ],
    connections: [
      {
        id: 'positive-base',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'rb', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'base-drive',
        from: { componentId: 'rb', terminal: 'lead-2' },
        to: { componentId: 'q1', terminal: 'base' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'positive-collector',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'rc', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'collector-load',
        from: { componentId: 'rc', terminal: 'lead-2' },
        to: { componentId: 'q1', terminal: 'collector' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'emitter-return',
        from: { componentId: 'q1', terminal: 'emitter' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function buttonCircuitDocument(resistorOhms: number): SchematicDocument {
  const seeded = circuitDocument({
    switchClosed: false,
    resistorOhms,
    reversedLed: false,
  });
  return {
    ...seeded,
    components: seeded.components.map((item) =>
      item.id === 'switch'
        ? {
            ...item,
            id: 'button',
            kind: 'button' as const,
            componentTypeId: 'button-tactile-6mm',
            variantId: 'button-tactile-6mm',
            name: 'S1',
            state: false,
            pinIds: ['SW-A1', 'SW-A2', 'SW-B1', 'SW-B2'],
            internalConnections: [
              ['SW-A1', 'SW-A2'],
              ['SW-B1', 'SW-B2'],
            ],
            stateProperties: {},
          }
        : item,
    ),
    connections: seeded.connections.map((wire) =>
      wire.id === 'wire-board-switch'
        ? {
            ...wire,
            to: { componentId: 'button', terminal: 'SW-A2' },
          }
        : wire.id === 'wire-switch-resistor'
          ? {
              ...wire,
              from: { componentId: 'button', terminal: 'SW-B2' },
            }
          : wire,
    ),
  };
}

function capacitorInteractionDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'resistor',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'Резистор',
        position: { x: 620, y: 250 },
        rotation: 0,
        value: 1_000,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'кОм' },
      },
      {
        id: 'capacitor',
        kind: 'visual',
        componentTypeId: 'electrolytic-capacitor',
        variantId: 'electrolytic-capacitor',
        name: 'Электролитический конденсатор',
        position: { x: 360, y: 250 },
        rotation: 0,
        value: 10_000,
        pinIds: ['negative', 'positive'],
        stateProperties: { initialVoltageVolt: 0, voltageRatingVolt: 25 },
      },
      {
        id: 'battery-holder',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-2',
        variantId: 'battery-holder-aa-2',
        name: 'Батарейный отсек 2×AA',
        position: { x: 850, y: 210 },
        rotation: 0,
        value: 3,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 2, internalResistanceOhm: 0.3, maxContinuousCurrentAmp: 2 },
      },
    ],
    connections: [],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function dcMotorDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-4',
        variantId: 'battery-holder-aa-4',
        name: 'Источник 6 В',
        position: { x: 180, y: 340 },
        rotation: 0,
        value: 6,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 4 },
      },
      {
        id: 'motor',
        kind: 'visual',
        componentTypeId: 'dc-motor',
        variantId: 'dc-motor',
        name: 'Двигатель постоянного тока',
        position: { x: 600, y: 260 },
        rotation: 0,
        value: 6,
        pinIds: ['negative', 'positive'],
        stateProperties: {},
      },
    ],
    connections: [
      {
        id: 'motor-positive',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'motor', terminal: 'positive' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'motor-negative',
        from: { componentId: 'motor', terminal: 'negative' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 60, y: 80, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function gearmotorDocument(): SchematicDocument {
  const document = dcMotorDocument();
  return {
    ...document,
    components: document.components.map((component) =>
      component.id === 'motor'
        ? {
            ...component,
            componentTypeId: 'gearmotor',
            variantId: 'gearmotor',
            name: 'Мотор-редуктор TT 1:48',
            stateProperties: { motorAssemblyProfileId: 'adafruit-3777-tt-48to1' },
          }
        : component,
    ),
  };
}

function gearmotorOvervoltageDocument(): SchematicDocument {
  const document = gearmotorDocument();
  return {
    ...document,
    components: document.components.map((component) =>
      component.id === 'source'
        ? {
            ...component,
            componentTypeId: 'battery-holder-aa-8',
            variantId: 'battery-holder-aa-8',
            name: 'Источник 12 В',
            position: { x: 100, y: 430 },
            value: 12,
            stateProperties: { cells: 8 },
          }
        : component.id === 'motor'
          ? { ...component, position: { x: 720, y: 150 } }
          : component,
    ),
  };
}

function dcMotorOvervoltageDocument(): SchematicDocument {
  const document = dcMotorDocument();
  return {
    ...document,
    components: document.components.map((component) =>
      component.id === 'source'
        ? {
            ...component,
            name: 'Источник 23 В',
            value: 23,
            stateProperties: { ...component.stateProperties, internalResistanceOhm: 0 },
          }
        : component,
    ),
  };
}

function reverseCapacitorDocument(): SchematicDocument {
  const interaction = capacitorInteractionDocument();
  return {
    ...interaction,
    components: interaction.components.filter((component) =>
      ['resistor', 'capacitor', 'battery-holder'].includes(component.id),
    ),
    connections: [
      {
        id: 'reverse-source-resistor',
        from: { componentId: 'battery-holder', terminal: 'BAT+' },
        to: { componentId: 'resistor', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'reverse-resistor-capacitor',
        from: { componentId: 'resistor', terminal: 'lead-2' },
        to: { componentId: 'capacitor', terminal: 'negative' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'reverse-capacitor-return',
        from: { componentId: 'capacitor', terminal: 'positive' },
        to: { componentId: 'battery-holder', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
  };
}

function pnpAstableDocument(capacitanceMicrofarad = 10): SchematicDocument {
  const resistor = (id: string, name: string, x: number, y: number, value: number) => ({
    id,
    kind: 'resistor' as const,
    componentTypeId: 'resistor-axial',
    variantId: 'resistor-axial',
    name,
    position: { x, y },
    rotation: 90 as const,
    value,
    pinIds: ['lead-1', 'lead-2'],
    stateProperties: { tolerancePercent: 5, resistanceUnit: value >= 1_000 ? 'кОм' : 'Ом' },
  });
  const transistor = (id: string, name: string, x: number) => ({
    id,
    kind: 'transistor' as const,
    componentTypeId: 'transistor-pnp',
    variantId: 'transistor-pnp',
    name,
    position: { x, y: 350 },
    rotation: 0 as const,
    value: 100,
    pinIds: ['collector', 'base', 'emitter'],
    stateProperties: { transistorType: 'pnp', currentGain: 100 },
  });
  const led = (id: string, name: string, x: number) => ({
    id,
    kind: 'led' as const,
    componentTypeId: 'led-5mm',
    variantId: 'led-5mm',
    name,
    position: { x, y: 650 },
    rotation: 0 as const,
    value: 2,
    pinIds: ['anode', 'cathode'],
    stateProperties: { ledColour: 'red', ledBrightness: 0, ledFault: 'none' },
  });
  const capacitor = (id: string, name: string, x: number) => ({
    id,
    kind: 'visual' as const,
    componentTypeId: 'electrolytic-capacitor',
    variantId: 'electrolytic-capacitor',
    name,
    position: { x, y: 470 },
    rotation: 0 as const,
    value: capacitanceMicrofarad,
    pinIds: ['negative', 'positive'],
    stateProperties: { voltageRatingVolt: 25, initialVoltageVolt: 0 },
  });
  const wire = (
    id: string,
    fromComponentId: string,
    fromTerminal: string,
    toComponentId: string,
    toTerminal: string,
  ) => ({
    id,
    from: { componentId: fromComponentId, terminal: fromTerminal },
    to: { componentId: toComponentId, terminal: toTerminal },
    color: '#149447',
    vertices: [],
  });

  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-3',
        variantId: 'battery-holder-aa-3',
        name: 'Источник 4,5 В',
        position: { x: 120, y: 430 },
        rotation: 0,
        value: 4.5,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 3, internalResistanceOhm: 0.1, maxContinuousCurrentAmp: 5 },
      },
      resistor('rc1', 'R светодиода 1', 480, 560, 1_000),
      resistor('rc2', 'R светодиода 2', 900, 560, 1_000),
      resistor('rb1', 'R базы 1', 590, 250, 10_000),
      resistor('rb2', 'R базы 2', 790, 250, 10_000),
      transistor('q1', 'PNP-транзистор 1', 530),
      transistor('q2', 'PNP-транзистор 2', 850),
      led('led1', 'Светодиод 1', 480),
      led('led2', 'Светодиод 2', 900),
      capacitor('c1', 'Конденсатор 1', 630),
      capacitor('c2', 'Конденсатор 2', 750),
    ],
    connections: [
      wire('w1', 'q1', 'collector', 'rc1', 'lead-1'),
      wire('w2', 'rc1', 'lead-2', 'led1', 'anode'),
      wire('w3', 'led1', 'cathode', 'source', 'BAT-'),
      wire('w4', 'q2', 'collector', 'rc2', 'lead-1'),
      wire('w5', 'rc2', 'lead-2', 'led2', 'anode'),
      wire('w6', 'led2', 'cathode', 'source', 'BAT-'),
      wire('w7', 'q1', 'base', 'rb1', 'lead-1'),
      wire('w8', 'rb1', 'lead-2', 'source', 'BAT-'),
      wire('w9', 'q2', 'base', 'rb2', 'lead-1'),
      wire('w10', 'rb2', 'lead-2', 'source', 'BAT-'),
      wire('w11', 'q1', 'emitter', 'source', 'BAT+'),
      wire('w12', 'q2', 'emitter', 'source', 'BAT+'),
      wire('w13', 'c1', 'negative', 'q1', 'collector'),
      wire('w14', 'c1', 'positive', 'q2', 'base'),
      wire('w15', 'c2', 'negative', 'q2', 'collector'),
      wire('w16', 'c2', 'positive', 'q1', 'base'),
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 32 },
  };
}

function breadboardDocument(): SchematicDocument {
  const seeded = circuitDocument({
    switchClosed: false,
    resistorOhms: 220,
    reversedLed: false,
  });
  return {
    ...seeded,
    components: seeded.components
      .filter((component) => component.id === 'board')
      .map((component) => ({ ...component, pinIds: breadboardPinIds })),
    connections: [],
  };
}

function shortCircuitDocument(): SchematicDocument {
  const source = circuitDocument({
    switchClosed: true,
    resistorOhms: 220,
    reversedLed: false,
  }).components.find((component) => component.id === 'source');
  if (!source) throw new Error('source fixture is missing');
  return {
    schemaVersion: 4,
    components: [source],
    connections: [
      {
        id: 'wire-direct-short',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#e3212b',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function isolatedSourceDiagnosticsDocument(): SchematicDocument {
  const seeded = circuitDocument({
    switchClosed: true,
    resistorOhms: 220,
    reversedLed: false,
  });
  const originalSource = seeded.components.find((component) => component.id === 'source');
  const originalResistor = seeded.components.find((component) => component.id === 'resistor');
  const originalLed = seeded.components.find((component) => component.id === 'led');
  if (!originalSource || !originalResistor || !originalLed) {
    throw new Error('isolated source diagnostics fixture is incomplete');
  }
  return {
    schemaVersion: 4,
    components: [
      {
        ...originalSource,
        id: 'shorted-source',
        name: 'Источник с КЗ',
        position: { x: 120, y: 360 },
      },
      {
        ...originalSource,
        id: 'safe-source',
        name: 'Исправный источник',
        position: { x: 540, y: 360 },
      },
      {
        ...originalSource,
        id: 'burnout-source',
        name: 'Источник LED без резистора',
        position: { x: 960, y: 360 },
      },
      {
        ...originalResistor,
        id: 'safe-resistor',
        name: 'R безопасной цепи',
        position: { x: 660, y: 200 },
      },
      {
        ...originalLed,
        id: 'safe-led',
        name: 'Исправный LED',
        position: { x: 570, y: 120 },
      },
      {
        ...originalLed,
        id: 'burned-led',
        name: 'LED без резистора',
        position: { x: 1_060, y: 120 },
      },
    ],
    connections: [
      {
        id: 'shorted-wire',
        from: { componentId: 'shorted-source', terminal: 'BAT+' },
        to: { componentId: 'shorted-source', terminal: 'BAT-' },
        color: '#149447',
        vertices: [{ x: 120, y: 300 }],
      },
      {
        id: 'safe-positive',
        from: { componentId: 'safe-source', terminal: 'BAT+' },
        to: { componentId: 'safe-resistor', terminal: 'lead-1' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'safe-limited',
        from: { componentId: 'safe-resistor', terminal: 'lead-2' },
        to: { componentId: 'safe-led', terminal: 'anode' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'safe-return',
        from: { componentId: 'safe-led', terminal: 'cathode' },
        to: { componentId: 'safe-source', terminal: 'BAT-' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'burnout-positive',
        from: { componentId: 'burnout-source', terminal: 'BAT+' },
        to: { componentId: 'burned-led', terminal: 'anode' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'burnout-return',
        from: { componentId: 'burned-led', terminal: 'cathode' },
        to: { componentId: 'burnout-source', terminal: 'BAT-' },
        color: '#149447',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function conflictingParallelSourcesDocument(): SchematicDocument {
  const seeded = circuitDocument({
    switchClosed: true,
    resistorOhms: 100,
    reversedLed: false,
  });
  const originalSource = seeded.components.find((component) => component.id === 'source');
  const originalResistor = seeded.components.find((component) => component.id === 'resistor');
  if (!originalSource || !originalResistor) {
    throw new Error('parallel source conflict fixture is incomplete');
  }
  return {
    schemaVersion: 4,
    components: [
      {
        ...originalSource,
        id: 'source-high',
        name: 'Источник 3 В',
        position: { x: 240, y: 360 },
      },
      {
        ...originalSource,
        id: 'source-low',
        componentTypeId: 'battery-holder-aa-1',
        variantId: 'battery-holder-aa-1',
        name: 'Источник 1,5 В',
        value: 1.5,
        position: { x: 600, y: 360 },
        stateProperties: { cells: 1 },
      },
      {
        ...originalResistor,
        id: 'parallel-load',
        name: 'Нагрузка 100 Ом',
        value: 100,
        position: { x: 940, y: 180 },
      },
    ],
    connections: [
      {
        id: 'high-positive',
        from: { componentId: 'source-high', terminal: 'BAT+' },
        to: { componentId: 'parallel-load', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'high-negative',
        from: { componentId: 'source-high', terminal: 'BAT-' },
        to: { componentId: 'parallel-load', terminal: 'lead-2' },
        color: '#2a3035',
        vertices: [],
      },
      {
        id: 'low-positive',
        from: { componentId: 'source-low', terminal: 'BAT+' },
        to: { componentId: 'parallel-load', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'low-negative',
        from: { componentId: 'source-low', terminal: 'BAT-' },
        to: { componentId: 'parallel-load', terminal: 'lead-2' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function resistorOverloadDocument(): SchematicDocument {
  const seeded = circuitDocument({
    switchClosed: true,
    resistorOhms: 1,
    reversedLed: false,
  });
  const source = seeded.components.find((component) => component.id === 'source');
  const resistor = seeded.components.find((component) => component.id === 'resistor');
  if (!source || !resistor) throw new Error('resistor overload fixture is incomplete');
  return {
    schemaVersion: 4,
    components: [source, resistor],
    connections: [
      {
        id: 'wire-overload-positive',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'resistor', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'wire-overload-return',
        from: { componentId: 'resistor', terminal: 'lead-2' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function directLedWithLoosePartsDocument(): SchematicDocument {
  const seeded = circuitDocument({
    switchClosed: true,
    resistorOhms: 166,
    reversedLed: false,
  });
  const source = seeded.components.find((component) => component.id === 'source');
  const board = seeded.components.find((component) => component.id === 'board');
  const resistor = seeded.components.find((component) => component.id === 'resistor');
  const led = seeded.components.find((component) => component.id === 'led');
  if (!source || !board || !resistor || !led) throw new Error('direct LED fixture is incomplete');

  return {
    ...seeded,
    components: [
      board,
      {
        ...source,
        id: 'open-source',
        name: 'Неподключённый источник',
        position: { x: 80, y: 500 },
      },
      source,
      resistor,
      led,
      { ...led, id: 'unused-led', name: 'Свободный LED', position: { x: 980, y: 360 } },
      {
        id: 'unused-potentiometer',
        kind: 'potentiometer',
        componentTypeId: 'potentiometer',
        variantId: 'potentiometer',
        name: 'Свободный потенциометр',
        position: { x: 1_050, y: 480 },
        rotation: 0,
        value: 1_000,
        pinIds: ['terminal-1', 'terminal-2', 'wiper'],
        stateProperties: {},
      },
      {
        id: 'unused-transistor',
        kind: 'transistor',
        componentTypeId: 'transistor-npn',
        variantId: 'transistor-npn',
        name: 'Свободный NPN',
        position: { x: 1_150, y: 480 },
        rotation: 0,
        value: 100,
        pinIds: ['base', 'collector', 'emitter'],
        stateProperties: {
          currentGain: 100,
          saturationVoltage: 0.2,
          baseEmitterVoltage: 0.7,
          maxCollectorCurrent: 0.2,
        },
      },
      {
        id: 'unused-rgb-led',
        kind: 'rgb-led',
        componentTypeId: 'rgb-led',
        variantId: 'rgb-led',
        name: 'Свободный RGB LED',
        position: { x: 1_250, y: 480 },
        rotation: 0,
        value: 0,
        pinIds: ['red', 'common', 'green', 'blue'],
        stateProperties: { commonMode: 'common-cathode' },
      },
    ],
    connections: [
      {
        id: 'wire-open-source',
        from: { componentId: 'board', terminal: 'J1' },
        to: { componentId: 'open-source', terminal: 'BAT+' },
        color: '#149447',
        vertices: [],
      },
      {
        id: 'wire-positive',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'resistor', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'wire-limited',
        from: { componentId: 'resistor', terminal: 'lead-2' },
        to: { componentId: 'led', terminal: 'anode' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'wire-negative',
        from: { componentId: 'led', terminal: 'cathode' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#149447',
        vertices: [],
      },
    ],
  };
}

function rgbLedDocument(commonMode: 'common-cathode' | 'common-anode'): SchematicDocument {
  const commonCathode = commonMode === 'common-cathode';
  const channels = ['red', 'green', 'blue'] as const;
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-4',
        variantId: 'battery-holder-aa-4',
        name: 'Источник 6 В',
        position: { x: 100, y: 260 },
        rotation: 0,
        value: 6,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 4 },
      },
      ...channels.map((channel, index) => ({
        id: `resistor-${channel}`,
        kind: 'resistor' as const,
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: `R ${channel.toUpperCase()}`,
        position: { x: 430 + index * 120, y: 390 },
        rotation: 0,
        value: 220,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'Ом' },
      })),
      {
        id: 'rgb',
        kind: 'rgb-led',
        componentTypeId: 'rgb-led',
        variantId: 'rgb-led',
        name: 'RGB LED',
        position: { x: 560, y: 160 },
        rotation: 0,
        value: 0,
        pinIds: ['red', 'common', 'green', 'blue'],
        stateProperties: { commonMode },
      },
    ],
    connections: commonCathode
      ? [
          ...channels.flatMap((channel) => [
            {
              id: `positive-${channel}`,
              from: { componentId: 'source', terminal: 'BAT+' },
              to: { componentId: `resistor-${channel}`, terminal: 'lead-1' },
              color: '#e3212b',
              vertices: [],
            },
            {
              id: `channel-${channel}`,
              from: { componentId: `resistor-${channel}`, terminal: 'lead-2' },
              to: { componentId: 'rgb', terminal: channel },
              color: channel === 'red' ? '#e3212b' : channel === 'green' ? '#149447' : '#2868d7',
              vertices: [],
            },
          ]),
          {
            id: 'common-return',
            from: { componentId: 'rgb', terminal: 'common' },
            to: { componentId: 'source', terminal: 'BAT-' },
            color: '#2a3035',
            vertices: [],
          },
        ]
      : [
          {
            id: 'common-positive',
            from: { componentId: 'source', terminal: 'BAT+' },
            to: { componentId: 'rgb', terminal: 'common' },
            color: '#e3212b',
            vertices: [],
          },
          ...channels.flatMap((channel) => [
            {
              id: `channel-${channel}`,
              from: { componentId: 'rgb', terminal: channel },
              to: { componentId: `resistor-${channel}`, terminal: 'lead-1' },
              color: channel === 'red' ? '#e3212b' : channel === 'green' ? '#149447' : '#2868d7',
              vertices: [],
            },
            {
              id: `return-${channel}`,
              from: { componentId: `resistor-${channel}`, terminal: 'lead-2' },
              to: { componentId: 'source', terminal: 'BAT-' },
              color: '#2a3035',
              vertices: [],
            },
          ]),
        ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function sevenSegmentDocument(commonMode: 'common-cathode' | 'common-anode'): SchematicDocument {
  const commonCathode = commonMode === 'common-cathode';
  const segmentPins = {
    a: 'top-4',
    b: 'top-5',
    d: 'bottom-2',
    e: 'bottom-1',
    g: 'top-1',
  } as const;
  const segments = Object.keys(segmentPins) as Array<keyof typeof segmentPins>;
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-2',
        variantId: 'battery-holder-aa-2',
        name: 'Источник 3 В',
        position: { x: 100, y: 300 },
        rotation: 0,
        value: 3,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 2 },
      },
      ...segments.map((segment, index) => ({
        id: `resistor-${segment}`,
        kind: 'resistor' as const,
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: `R ${segment.toUpperCase()}`,
        position: { x: 380 + index * 100, y: 430 },
        rotation: 0 as const,
        value: 220,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'Ом' },
      })),
      {
        id: 'display',
        kind: 'seven-segment',
        componentTypeId: 'seven-segment-display',
        variantId: 'seven-segment-display',
        name: 'Семисегментный индикатор',
        position: { x: 600, y: 170 },
        rotation: 0,
        value: 0,
        pinIds: [
          'top-1',
          'top-2',
          'top-3',
          'top-4',
          'top-5',
          'bottom-1',
          'bottom-2',
          'bottom-3',
          'bottom-4',
          'bottom-5',
        ],
        stateProperties: { commonMode, segmentColor: 'red' },
      },
    ],
    connections: commonCathode
      ? [
          ...segments.flatMap((segment) => [
            {
              id: `positive-${segment}`,
              from: { componentId: 'source', terminal: 'BAT+' },
              to: { componentId: `resistor-${segment}`, terminal: 'lead-1' },
              color: '#e3212b',
              vertices: [],
            },
            {
              id: `segment-${segment}`,
              from: { componentId: `resistor-${segment}`, terminal: 'lead-2' },
              to: { componentId: 'display', terminal: segmentPins[segment] },
              color: '#149447',
              vertices: [],
            },
          ]),
          {
            id: 'common-return',
            from: { componentId: 'display', terminal: 'top-3' },
            to: { componentId: 'source', terminal: 'BAT-' },
            color: '#2a3035',
            vertices: [],
          },
        ]
      : [
          {
            id: 'common-positive',
            from: { componentId: 'source', terminal: 'BAT+' },
            to: { componentId: 'display', terminal: 'bottom-3' },
            color: '#e3212b',
            vertices: [],
          },
          ...segments.flatMap((segment) => [
            {
              id: `segment-${segment}`,
              from: { componentId: 'display', terminal: segmentPins[segment] },
              to: { componentId: `resistor-${segment}`, terminal: 'lead-1' },
              color: '#149447',
              vertices: [],
            },
            {
              id: `return-${segment}`,
              from: { componentId: `resistor-${segment}`, terminal: 'lead-2' },
              to: { componentId: 'source', terminal: 'BAT-' },
              color: '#2a3035',
              vertices: [],
            },
          ]),
        ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function ownerRedBlueRgbDocument(): SchematicDocument {
  const seeded = rgbLedDocument('common-cathode');
  return {
    ...seeded,
    components: seeded.components
      .filter((item) => ['source', 'resistor-red', 'rgb'].includes(item.id))
      .map((item) =>
        item.id === 'source'
          ? {
              ...item,
              componentTypeId: 'battery-holder-aa-2',
              variantId: 'battery-holder-aa-2',
              name: 'Источник 3 В',
              value: 3,
              stateProperties: { cells: 2 },
            }
          : item.id === 'rgb'
            ? {
                ...item,
                stateProperties: { commonMode: 'common-cathode', pinLayout: 'RCBG' },
              }
            : item,
      ),
    connections: [
      ...seeded.connections.filter((wire) =>
        ['positive-red', 'channel-red', 'common-return'].includes(wire.id),
      ),
      {
        id: 'direct-blue',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'rgb', terminal: 'blue' },
        color: '#2868d7',
        vertices: [],
      },
    ],
  };
}

function ownerGreenBlueEqualRgbDocument(): SchematicDocument {
  const seeded = rgbLedDocument('common-cathode');
  return {
    ...seeded,
    components: seeded.components
      .filter((item) => ['source', 'resistor-green', 'resistor-blue', 'rgb'].includes(item.id))
      .map((item) =>
        item.id === 'source'
          ? {
              ...item,
              componentTypeId: 'battery-holder-aa-2',
              variantId: 'battery-holder-aa-2',
              name: 'Источник 3 В',
              value: 3,
              stateProperties: { cells: 2 },
            }
          : item.id === 'rgb'
            ? {
                ...item,
                stateProperties: { commonMode: 'common-cathode', pinLayout: 'RCBG' },
              }
            : item,
      ),
    connections: seeded.connections.filter((wire) =>
      [
        'positive-green',
        'channel-green',
        'positive-blue',
        'channel-blue',
        'common-return',
      ].includes(wire.id),
    ),
  };
}

function singleChannelRgbLedDocument(options: {
  readonly componentMode: 'common-cathode' | 'common-anode';
  readonly wiringMode: 'common-cathode' | 'common-anode';
  readonly resistorOhms: number | null;
}): SchematicDocument {
  const seeded = rgbLedDocument(options.wiringMode);
  const components = seeded.components
    .filter((item) => ['source', 'resistor-green', 'rgb'].includes(item.id))
    .filter((item) => options.resistorOhms !== null || item.id !== 'resistor-green')
    .map((item) =>
      item.id === 'source'
        ? {
            ...item,
            componentTypeId: 'battery-holder-aa-2',
            variantId: 'battery-holder-aa-2',
            name: 'Источник 3 В',
            value: 3,
            stateProperties: { cells: 2 },
          }
        : item.id === 'resistor-green'
          ? { ...item, value: options.resistorOhms ?? 0 }
          : item.id === 'rgb'
            ? { ...item, stateProperties: { commonMode: options.componentMode } }
            : item,
    );
  const direct = options.resistorOhms === null;
  const connections =
    options.wiringMode === 'common-cathode'
      ? [
          ...(direct
            ? [
                {
                  id: 'direct-green',
                  from: { componentId: 'source', terminal: 'BAT+' },
                  to: { componentId: 'rgb', terminal: 'green' },
                  color: '#149447',
                  vertices: [],
                },
              ]
            : seeded.connections.filter((wire) =>
                ['positive-green', 'channel-green'].includes(wire.id),
              )),
          ...seeded.connections.filter((wire) => wire.id === 'common-return'),
        ]
      : [
          ...seeded.connections.filter((wire) => wire.id === 'common-positive'),
          ...(direct
            ? [
                {
                  id: 'direct-green-return',
                  from: { componentId: 'rgb', terminal: 'green' },
                  to: { componentId: 'source', terminal: 'BAT-' },
                  color: '#149447',
                  vertices: [],
                },
              ]
            : seeded.connections.filter((wire) =>
                ['channel-green', 'return-green'].includes(wire.id),
              )),
        ];
  return { ...seeded, components, connections };
}

function multimeterDcVoltageDocument(reverseProbes = false): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-2',
        variantId: 'battery-holder-aa-2',
        name: 'Источник 3 В',
        position: { x: 170, y: 390 },
        rotation: 0,
        value: 3,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 2 },
      },
      {
        id: 'meter',
        kind: 'visual',
        componentTypeId: 'multimeter',
        variantId: 'multimeter',
        name: 'Мультиметр',
        position: { x: 660, y: 230 },
        rotation: 0,
        value: 0,
        pinIds: ['com', 'v-ohm-ma'],
        stateProperties: { measurementMode: 'dc-voltage', meterRange: 'auto' },
      },
    ],
    connections: reverseProbes
      ? [
          {
            id: 'negative-red-probe',
            from: { componentId: 'source', terminal: 'BAT-' },
            to: { componentId: 'meter', terminal: 'v-ohm-ma' },
            color: '#e3212b',
            vertices: [],
          },
          {
            id: 'positive-black-probe',
            from: { componentId: 'source', terminal: 'BAT+' },
            to: { componentId: 'meter', terminal: 'com' },
            color: '#2a3035',
            vertices: [],
          },
        ]
      : [
          {
            id: 'positive-red-probe',
            from: { componentId: 'source', terminal: 'BAT+' },
            to: { componentId: 'meter', terminal: 'v-ohm-ma' },
            color: '#e3212b',
            vertices: [],
          },
          {
            id: 'negative-black-probe',
            from: { componentId: 'source', terminal: 'BAT-' },
            to: { componentId: 'meter', terminal: 'com' },
            color: '#2a3035',
            vertices: [],
          },
        ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function multimeterDcCurrentDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'source',
        kind: 'source',
        componentTypeId: 'battery-holder-aa-2',
        variantId: 'battery-holder-aa-2',
        name: 'Источник 3 В',
        position: { x: 170, y: 390 },
        rotation: 0,
        value: 3,
        pinIds: ['BAT-', 'BAT+'],
        stateProperties: { cells: 2 },
      },
      {
        id: 'load',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'Нагрузка 100 Ом',
        position: { x: 520, y: 310 },
        rotation: 90,
        value: 100,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { powerRatingWatt: 0.25 },
      },
      {
        id: 'meter',
        kind: 'visual',
        componentTypeId: 'multimeter',
        variantId: 'multimeter',
        name: 'Мультиметр',
        position: { x: 760, y: 230 },
        rotation: 0,
        value: 0,
        pinIds: ['com', 'v-ohm-ma'],
        stateProperties: { measurementMode: 'dc-voltage', meterRange: 'auto' },
      },
    ],
    connections: [
      {
        id: 'supply',
        from: { componentId: 'source', terminal: 'BAT+' },
        to: { componentId: 'load', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'meter-input',
        from: { componentId: 'load', terminal: 'lead-2' },
        to: { componentId: 'meter', terminal: 'v-ohm-ma' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'return',
        from: { componentId: 'meter', terminal: 'com' },
        to: { componentId: 'source', terminal: 'BAT-' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function multimeterResistanceDocument(powered = false): SchematicDocument {
  const resistor = {
    id: 'load',
    kind: 'resistor' as const,
    componentTypeId: 'resistor-axial',
    variantId: 'resistor-axial',
    name: 'Резистор 1 кОм',
    position: { x: 420, y: 390 },
    rotation: 90 as const,
    value: 1_000,
    pinIds: ['lead-1', 'lead-2'],
    stateProperties: { powerRatingWatt: 0.25 },
  };
  const meter = {
    id: 'meter',
    kind: 'visual' as const,
    componentTypeId: 'multimeter',
    variantId: 'multimeter',
    name: 'Мультиметр',
    position: { x: 760, y: 230 },
    rotation: 0 as const,
    value: 0,
    pinIds: ['com', 'v-ohm-ma'],
    stateProperties: { measurementMode: powered ? 'resistance' : 'dc-voltage', meterRange: 'auto' },
  };
  const source = {
    id: 'source',
    kind: 'source' as const,
    componentTypeId: 'battery-holder-aa-2',
    variantId: 'battery-holder-aa-2',
    name: 'Источник 3 В',
    position: { x: 150, y: 390 },
    rotation: 0 as const,
    value: 3,
    pinIds: ['BAT-', 'BAT+'],
    stateProperties: { cells: 2 },
  };
  return {
    schemaVersion: 4,
    components: powered ? [source, resistor, meter] : [resistor, meter],
    connections: [
      {
        id: 'probe-red',
        from: { componentId: 'meter', terminal: 'v-ohm-ma' },
        to: { componentId: 'load', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'probe-black',
        from: { componentId: 'meter', terminal: 'com' },
        to: { componentId: 'load', terminal: 'lead-2' },
        color: '#2a3035',
        vertices: [],
      },
      ...(powered
        ? [
            {
              id: 'supply-positive',
              from: { componentId: 'source', terminal: 'BAT+' },
              to: { componentId: 'load', terminal: 'lead-1' },
              color: '#e3212b',
              vertices: [],
            },
            {
              id: 'supply-negative',
              from: { componentId: 'source', terminal: 'BAT-' },
              to: { componentId: 'load', terminal: 'lead-2' },
              color: '#2a3035',
              vertices: [],
            },
          ]
        : []),
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function regulatedPowerSupplyDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [
      {
        id: 'bench-supply',
        kind: 'source',
        componentTypeId: 'regulated-power-supply',
        variantId: 'regulated-power-supply',
        name: 'Лабораторный источник',
        position: { x: 270, y: 250 },
        rotation: 0,
        value: 5,
        state: false,
        pinIds: ['positive', 'negative'],
        stateProperties: {
          voltageSetpointVolt: 5,
          currentLimitAmp: 1,
          outputEnabled: false,
          outputResistanceOhm: 0.05,
        },
      },
      {
        id: 'load',
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        name: 'Нагрузка 100 Ом',
        position: { x: 760, y: 310 },
        rotation: 90,
        value: 100,
        pinIds: ['lead-1', 'lead-2'],
        stateProperties: { powerRatingWatt: 5 },
      },
    ],
    connections: [
      {
        id: 'supply-positive',
        from: { componentId: 'bench-supply', terminal: 'positive' },
        to: { componentId: 'load', terminal: 'lead-1' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'supply-negative',
        from: { componentId: 'bench-supply', terminal: 'negative' },
        to: { componentId: 'load', terminal: 'lead-2' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

async function createProject(page: Page, title: string): Promise<string> {
  const response = await page.context().request.post('/api/projects', {
    headers: {
      origin: new URL(page.url()).origin,
      'idempotency-key': `electronics-simulation-${crypto.randomUUID()}`,
    },
    data: {
      scope: 'personal',
      classroomId: null,
      module: 'electronics',
      title,
    },
  });
  expect(response.status()).toBe(201);
  const payload = (await response.json()) as { project: { id: string } };
  return payload.project.id;
}

async function saveDocument(
  page: Page,
  projectId: string,
  document: SchematicDocument,
): Promise<void> {
  const origin = new URL(page.url()).origin;
  const opened = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin },
  });
  expect(opened.status()).toBe(200);
  const current = (await opened.json()) as { draft: { revision: number } };
  const response = await page.context().request.put(`/api/projects/${projectId}/draft`, {
    headers: { origin },
    data: {
      document,
      baseRevision: current.draft.revision,
      mutationId: crypto.randomUUID(),
    },
  });
  expect(response.status()).toBe(200);
}

async function openProject(page: Page, projectId: string): Promise<void> {
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
  await expect(page.getByLabel('Название проекта')).toHaveValue('R4-M1 live simulation');
}

function component(page: Page, componentTypeId: string) {
  return page.locator(
    `[data-testid="schematic-component"][data-component-type="${componentTypeId}"]`,
  );
}

/**
 * Диагностическая метка детали.
 *
 * Метки рисуются отдельным слоем поверх схемы — иначе подсказка тонула под
 * проводами и деталями, нарисованными позже. Деталь метка называет сама, так
 * что искать её нужно по имени детали, а не внутри её группы.
 */
function diagnostic(page: Page, componentTypeId: string, testId: string) {
  return page.locator(
    `[data-testid="component-diagnostic"][data-component-type="${componentTypeId}"] [data-testid="${testId}"]`,
  );
}

async function brightnessValue(page: Page): Promise<number> {
  const value = await component(page, 'led-5mm')
    .locator('.workbench-production-visual')
    .getAttribute('data-led-brightness');
  return Number(value ?? '0');
}

async function selectLed(page: Page): Promise<void> {
  const led = component(page, 'led-5mm');
  const burnout = diagnostic(page, 'led-5mm', 'led-burnout-explosion');
  if ((await burnout.count()) > 0 && (await burnout.isVisible())) {
    await burnout.locator('.workbench-led-explosion-inner').click();
  } else {
    try {
      // The owner asset itself is pointer-transparent: the stage resolves the
      // exact alpha silhouette so transparent viewBox pixels pass through.
      await led.locator('.workbench-part').click({ timeout: 2_000, force: true });
    } catch (error) {
      if ((await burnout.count()) === 0 || !(await burnout.isVisible())) throw error;
      await burnout.locator('.workbench-led-explosion-inner').click();
    }
  }
  await expect(page.getByRole('complementary', { name: 'Параметры выделения' })).toBeVisible();
  await expect(page.getByRole('combobox', { name: /^Цвет(?: светодиода)?$/ })).toBeVisible();
}

async function holeCenter(page: Page, holeId: string): Promise<{ x: number; y: number }> {
  const box = await page
    .locator(`[data-hole-id="${holeId}"] .workbench-breadboard-hole-hit`)
    .boundingBox();
  if (!box) throw new Error(`breadboard hole ${holeId} is not rendered`);
  return { x: box.x + box.width / 2, y: box.y + box.height / 2 };
}

async function dragCatalogComponent(
  page: Page,
  name: string,
  target: { x: number; y: number },
): Promise<void> {
  const card = page.getByRole('button', { name, exact: true });
  const box = await card.boundingBox();
  if (!box) throw new Error(`catalog card ${name} is not rendered`);
  const before = await page.locator('[data-testid="schematic-component"]').count();
  const start = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
  await page.mouse.move(start.x, start.y);
  await page.mouse.down();
  await page.mouse.move(start.x - 4, start.y, { steps: 2 });
  await expect(page.locator('.workbench-picked-up')).toHaveCount(1);
  await page.mouse.move(target.x, target.y, { steps: 12 });
  await expect(page.locator('.workbench-picked-up')).toHaveCount(1);
  await expect(page.getByTestId('catalog-placement-preview')).toHaveCount(1);
  await page.mouse.up();
  await expect(page.locator('.workbench-picked-up')).toHaveCount(0);
  await expect(page.getByTestId('catalog-placement-preview')).toHaveCount(0);
  await expect(page.locator('[data-testid="schematic-component"]')).toHaveCount(before + 1);
}

async function unobstructedComponentPoint(
  page: Page,
  componentTypeId: string,
): Promise<{ x: number; y: number }> {
  return page
    .locator(
      `[data-testid="schematic-component"][data-component-type="${componentTypeId}"] .workbench-part`,
    )
    .evaluate((element, typeId) => {
      const rect = element.getBoundingClientRect();
      for (let y = rect.top + 8; y < rect.bottom - 8; y += 12) {
        for (let x = rect.left + 8; x < rect.right - 8; x += 12) {
          const hit = document.elementFromPoint(x, y);
          if (
            hit &&
            (element.contains(hit) || hit.classList.contains('workbench-grid-hit')) &&
            !hit.closest('.workbench-terminal-hit, .workbench-breadboard-hole-hit')
          ) {
            return { x, y };
          }
        }
      }
      throw new Error(`no unobstructed point found for ${typeId}`);
    }, componentTypeId);
}

function arduinoInputDocument(
  mode: 'button' | 'buttons' | 'ladder' | 'pot',
  pin = '2',
): SchematicDocument {
  const base = circuitDocument({ switchClosed: false, resistorOhms: 330, reversedLed: false });
  const outputPin = mode === 'pot' ? '9' : '13';
  const terminal = pin.startsWith('A') ? pin.toLowerCase() : `d${pin}`;
  const source =
    mode === 'pot'
      ? `void setup(){pinMode(9,OUTPUT);}void loop(){analogWrite(9,map(analogRead(${pin}),0,1023,0,255));delay(10);}`
      : mode === 'button'
        ? `void setup(){pinMode(${pin},INPUT_PULLUP);pinMode(13,OUTPUT);}void loop(){if(digitalRead(${pin})==LOW){digitalWrite(13,HIGH);}else{digitalWrite(13,LOW);}delay(10);}`
        : mode === 'ladder'
          ? 'void setup(){pinMode(13,OUTPUT);}void loop(){if(analogRead(A1)>200){digitalWrite(13,HIGH);}else{digitalWrite(13,LOW);}delay(10);}'
          : 'void setup(){pinMode(2,INPUT);pinMode(4,INPUT);pinMode(13,OUTPUT);}void loop(){if(digitalRead(2)==HIGH || digitalRead(4)==HIGH){digitalWrite(13,HIGH);}else{digitalWrite(13,LOW);}delay(10);}';
  const components: SchematicDocument['components'][number][] = [
    {
      id: 'uno',
      kind: 'visual',
      componentTypeId: 'arduino-uno',
      variantId: 'arduino-uno',
      name: 'Arduino Uno',
      position: { x: 120, y: 120 },
      value: 5,
      pinIds: ownerCatalog.components
        .find((c) => c.componentId === 'arduino-uno')!
        .pins.map((p) => p.id),
      stateProperties: { arduinoSource: source },
    },
    { ...base.components.find((c) => c.id === 'resistor')!, position: { x: 650, y: 190 } },
    { ...base.components.find((c) => c.id === 'led')!, position: { x: 840, y: 190 } },
  ];
  const connections: SchematicDocument['connections'][number][] = [];
  const wire = (from: string, fromPin: string, to: string, toPin: string) =>
    connections.push({
      id: `wire-${connections.length}`,
      from: { componentId: from, terminal: fromPin },
      to: { componentId: to, terminal: toPin },
      color: '#149447',
      vertices: [],
    });
  wire('uno', `d${outputPin}`, 'resistor', 'lead-1');
  wire('resistor', 'lead-2', 'led', 'anode');
  wire('led', 'cathode', 'uno', 'power-gnd-1');
  if (mode === 'pot') {
    components.push({
      id: 'pot',
      kind: 'potentiometer',
      componentTypeId: 'potentiometer',
      variantId: 'potentiometer',
      name: 'Потенциометр',
      position: { x: 580, y: 400 },
      value: 10_000,
      wiperPosition: 0,
      pinIds: ownerCatalog.components
        .find((c) => c.componentId === 'potentiometer')!
        .pins.map((p) => p.id),
      stateProperties: {},
    });
    wire('uno', 'power-5v', 'pot', 'terminal-1');
    wire('uno', 'power-gnd-1', 'pot', 'terminal-2');
    wire('pot', 'wiper', 'uno', terminal);
  } else {
    const count = mode === 'button' ? 1 : 2;
    for (let index = 0; index < count; index++) {
      const id = `button-${index}`;
      const input =
        mode === 'button' ? terminal : mode === 'ladder' ? 'a1' : index === 0 ? 'd2' : 'd4';
      components.push({
        ...buttonCircuitDocument(330).components.find((c) => c.id === 'button')!,
        id,
        name: `Кнопка ${index + 1}`,
        position: { x: 510 + index * 210, y: 410 },
      });
      if (mode === 'button') {
        wire('uno', input, id, 'SW-A1');
        wire(id, 'SW-B1', 'uno', 'power-gnd-1');
      } else {
        wire('uno', 'power-5v', id, 'SW-A1');
        const resistanceId = `pull-${index}`;
        components.push({
          ...base.components.find((c) => c.id === 'resistor')!,
          id: resistanceId,
          name: `R${index + 2}`,
          position: { x: 510 + index * 210, y: 540 },
          value: mode === 'ladder' ? (index + 1) * 10_000 : 10_000,
        });
        if (mode === 'ladder') {
          wire(id, 'SW-B1', resistanceId, 'lead-1');
          wire(resistanceId, 'lead-2', 'uno', input);
        } else {
          wire(id, 'SW-B1', 'uno', input);
          wire('uno', input, resistanceId, 'lead-1');
          wire(resistanceId, 'lead-2', 'uno', 'power-gnd-1');
        }
      }
    }
    if (mode === 'ladder') {
      components.push({
        ...base.components.find((c) => c.id === 'resistor')!,
        id: 'ladder-ground',
        name: 'R4',
        position: { x: 930, y: 480 },
        value: 10_000,
      });
      wire('uno', 'a1', 'ladder-ground', 'lead-1');
      wire('ladder-ground', 'lead-2', 'uno', 'power-gnd-1');
    }
  }
  return { ...base, components, connections };
}

const ARDUINO_RESET_HIGH_HOLD_MILLISECONDS = 20_000;
const ARDUINO_RESET_LOW_TIMEOUT_MILLISECONDS = ARDUINO_RESET_HIGH_HOLD_MILLISECONDS * 3;

function arduinoResetAcceptanceDocument(): SchematicDocument {
  const base = arduinoInputDocument('button', '2');
  const source = `void setup(){pinMode(13,OUTPUT);digitalWrite(13,HIGH);delay(${ARDUINO_RESET_HIGH_HOLD_MILLISECONDS});}void loop(){digitalWrite(13,LOW);delay(60000);}`;
  return {
    ...base,
    components: base.components.map((component) =>
      component.id === 'uno'
        ? {
            ...component,
            stateProperties: { ...component.stateProperties, arduinoSource: source },
          }
        : component,
    ),
  };
}

async function observeSimulationWorkerClock(page: Page): Promise<void> {
  await page.addInitScript(() => {
    type ClockSample = {
      workerId: number;
      generationId: number;
      requestedMicroseconds: number;
      committedMicroseconds: number;
      status: string;
      receivedAt: number;
    };
    const clockWindow = window as Window & {
      __simulationClockSamples?: ClockSample[];
      __simulationWorkerCount?: number;
    };
    const samples: ClockSample[] = [];
    clockWindow.__simulationClockSamples = samples;
    let workerId = 0;
    window.Worker = new Proxy(window.Worker, {
      construct(target, args, newTarget) {
        const worker = Reflect.construct(target, args, newTarget) as Worker;
        if ((args[1] as WorkerOptions | undefined)?.name !== 'asa-electronics-simulation') {
          return worker;
        }
        const id = ++workerId;
        clockWindow.__simulationWorkerCount = workerId;
        worker.addEventListener('message', (event: MessageEvent) => {
          const response = event.data as {
            ok?: boolean;
            kind?: string;
            generationId?: number;
            advance?: {
              requestedHorizonMicroseconds: number;
              committedHorizonMicroseconds: number;
              executionStatus: string;
            };
          };
          if (!response.ok || response.kind !== 'advance' || !response.advance) return;
          samples.push({
            workerId: id,
            generationId: response.generationId ?? -1,
            requestedMicroseconds: response.advance.requestedHorizonMicroseconds,
            committedMicroseconds: response.advance.committedHorizonMicroseconds,
            status: response.advance.executionStatus,
            receivedAt: Date.now(),
          });
          if (samples.length > 20) samples.shift();
        });
        return worker;
      },
    });
  });
}

async function holdNextSimulationPreflight(page: Page): Promise<void> {
  await page.addInitScript(() => {
    const probe = window as Window & {
      __secondSimulationPreflightQueued?: boolean;
      __armNextSimulationPreflight?: () => void;
      __releaseSecondSimulationPreflight?: () => void;
    };
    let holdNext = false;
    let release: (() => void) | null = null;
    probe.__secondSimulationPreflightQueued = false;
    probe.__armNextSimulationPreflight = () => {
      holdNext = true;
    };
    probe.__releaseSecondSimulationPreflight = () => {
      const pending = release;
      release = null;
      pending?.();
    };
    window.Worker = new Proxy(window.Worker, {
      construct(target, args, newTarget) {
        const worker = Reflect.construct(target, args, newTarget) as Worker;
        if ((args[1] as WorkerOptions | undefined)?.name !== 'asa-electronics-simulation') {
          return worker;
        }
        const originalPost = worker.postMessage.bind(worker);
        worker.postMessage = ((message: { kind?: string }) => {
          if (message.kind === 'preflight' && holdNext) {
            holdNext = false;
            release = () => originalPost(message);
            probe.__secondSimulationPreflightQueued = true;
            return;
          }
          originalPost(message);
        }) as Worker['postMessage'];
        return worker;
      },
    });
  });
}

async function simulationWorkerObservation(page: Page) {
  return page.evaluate(() => {
    const clockWindow = window as Window & {
      __simulationWorkerCount?: number;
      __simulationClockSamples?: Array<{
        workerId: number;
        generationId: number;
        requestedMicroseconds: number;
        committedMicroseconds: number;
        status: string;
        receivedAt: number;
      }>;
    };
    const led = document.querySelector('[data-testid="schematic-component"][data-kind="led"]');
    return {
      workerCount: clockWindow.__simulationWorkerCount ?? 0,
      workerSamples: (clockWindow.__simulationClockSamples ?? [])
        .slice(-5)
        .map(({ receivedAt, ...sample }) => ({ ...sample, ageMs: Date.now() - receivedAt })),
      toolbarClock: document.querySelector('.workbench-simulation-time')?.textContent?.trim(),
      ledDiagnostics: led?.getAttribute('data-diagnostics'),
      ledRuntimeState: led
        ?.querySelector('.workbench-production-visual')
        ?.getAttribute('data-led-runtime-state'),
      ledImageHref: led?.querySelector('image:not([filter])')?.getAttribute('href'),
    };
  });
}

async function expectArduinoBrightness(
  page: Page,
  expected: 'high' | 'low',
  phase: string,
): Promise<void> {
  try {
    if (expected === 'high') {
      await expect.poll(() => brightnessValue(page), { timeout: 10_000 }).toBeGreaterThan(0);
    } else {
      await expect
        .poll(() => brightnessValue(page), { timeout: ARDUINO_RESET_LOW_TIMEOUT_MILLISECONDS })
        .toBe(0);
    }
  } catch (error) {
    const observation = await simulationWorkerObservation(page);
    throw new Error(
      `Arduino Reset ${phase}: expected ${expected}, brightness=${await brightnessValue(page)}, ` +
        `clock=${JSON.stringify(observation)}`,
      { cause: error },
    );
  }
}

for (const scenario of [
  { mode: 'button', pin: '2' },
  { mode: 'button', pin: 'A0' },
  { mode: 'buttons', pin: '2' },
  { mode: 'ladder', pin: 'A1' },
  { mode: 'pot', pin: 'A0' },
  { mode: 'pot', pin: 'A5' },
] as const) {
  test(`Arduino correctness: ${scenario.mode} ${scenario.pin}`, async ({ page }) => {
    test.setTimeout(90_000);
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    await page.setViewportSize({ width: 1600, height: 1000 });
    await loginWithOrganization(page, teacher);
    const projectId = await createProject(page, `Arduino ${scenario.mode} ${scenario.pin}`);
    const document = arduinoInputDocument(scenario.mode, scenario.pin);
    const source = String(
      document.components.find((item) => item.id === 'uno')?.stateProperties?.['arduinoSource'],
    );
    await saveDocument(page, projectId, document);
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();
    // Loading the editor must not replace source-only imported sketches with
    // the default block program, even though the panel is pre-mounted hidden.
    await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(page.locator('.arduino-source-editor textarea')).toHaveValue(source);
    await page.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    if (scenario.mode === 'pot') {
      await component(page, 'potentiometer').locator('.workbench-part').click();
      await page
        .locator('.workbench-inspector')
        .getByRole('button', { name: /Техническое состояние/ })
        .click();
      const slider = page.getByRole('slider', { name: 'Положение движка' });
      await slider.press('Home');
      await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
      const first = await brightnessValue(page);
      await slider.press('End');
      await expect.poll(() => brightnessValue(page)).toBe(0);
      const second = await brightnessValue(page);
      await slider.press('Home');
      await expect.poll(() => brightnessValue(page)).toBe(first);
      expect(first).toBeGreaterThan(0);
      expect(second).toBe(0);
    } else {
      await expect.poll(() => brightnessValue(page)).toBe(0);
      const buttons = component(page, 'button-tactile-6mm');
      for (let index = 0; index < (await buttons.count()); index++) {
        const box = await buttons.nth(index).locator('.workbench-part').boundingBox();
        if (!box) throw new Error('Button is not visible');
        if (scenario.mode === 'buttons' && index === 0) {
          // F2: this fixture deliberately crosses the foreground button with a
          // wire. The hidden wire hit geometry must not own the pointer through
          // the component body; the button remains the interactive surface.
          const pointerOwner = await page.evaluate(
            ({ x, y }) => {
              const top = document.elementFromPoint(x, y);
              return {
                wire: Boolean(top?.closest('.workbench-wire-hit, .workbench-wire-segment-hit')),
                componentType: top?.closest<SVGElement>('[data-testid="schematic-component"]')
                  ?.dataset['componentType'],
              };
            },
            { x: box.x + box.width / 2, y: box.y + box.height / 2 },
          );
          expect(pointerOwner.wire).toBe(false);
          expect(pointerOwner.componentType).toBe('button-tactile-6mm');
        }
        await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
        await page.mouse.down();
        await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
        await page.screenshot({
          path: `${ARTIFACT_DIR}/arduino-${scenario.mode}-${scenario.pin}-${index}.png`,
        });
        await page.mouse.up();
        await expect.poll(() => brightnessValue(page)).toBe(0);
      }
    }
    await page.screenshot({ path: `${ARTIFACT_DIR}/arduino-${scenario.mode}-${scenario.pin}.png` });
    await page.getByRole('button', { name: 'Остановить моделирование' }).click();
    await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(page.locator('.arduino-source-editor textarea')).toHaveValue(source);
    failures.assertEmpty();
  });
}

test('E-OPT-3D acceptance: Arduino Reset restarts an already progressed canonical run', async ({
  page,
}) => {
  // Two 20-second model-time HIGH phases must complete within bounded wall time.
  test.setTimeout(180_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await observeSimulationWorkerClock(page);
  await holdNextSimulationPreflight(page);
  await page.setViewportSize({ width: 1600, height: 1000 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'E-OPT-3D Arduino reset acceptance');
  await saveDocument(page, projectId, arduinoResetAcceptanceDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();

  // Prove the canonical Arduino runtime has progressed beyond its initial state:
  // setup() holds D13 high long enough for a loaded browser to observe it,
  // then the first loop iteration holds it low. Both phases repeat after Reset.
  await expectArduinoBrightness(page, 'high', 'before Reset');
  await expectArduinoBrightness(page, 'low', 'before Reset');
  const beforeResetWorker = await simulationWorkerObservation(page);
  const beforeResetSample = beforeResetWorker.workerSamples.at(-1);
  expect(
    beforeResetSample?.committedMicroseconds,
    JSON.stringify(beforeResetWorker),
  ).toBeGreaterThanOrEqual(ARDUINO_RESET_HIGH_HOLD_MILLISECONDS * 1_000);
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'running',
  );
  await expect(page.locator('.workbench-simulation-time')).not.toHaveText(
    'Время моделирования: 00:00:00',
  );

  const resetButton = page.getByTestId('arduino-reset-button');
  await expect(resetButton).toHaveAttribute('aria-label', 'Перезапустить Arduino');
  await page.evaluate(() =>
    (
      window as Window & { __armNextSimulationPreflight?: () => void }
    ).__armNextSimulationPreflight?.(),
  );
  await resetButton.click();

  await expect
    .poll(() =>
      page.evaluate(
        () =>
          (window as Window & { __secondSimulationPreflightQueued?: boolean })
            .__secondSimulationPreflightQueued ?? false,
      ),
    )
    .toBe(true);
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'starting',
  );
  await expect(page.locator('.workbench-simulation-time')).toHaveText(
    'Время моделирования: 00:00:00',
  );
  await page.evaluate(() =>
    (
      window as Window & { __releaseSecondSimulationPreflight?: () => void }
    ).__releaseSecondSimulationPreflight?.(),
  );
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'running',
  );

  // Reset must discard the old continuation and replay setup()/loop() from time zero.
  await expectArduinoBrightness(page, 'high', 'after Reset');
  await page.waitForTimeout(350);
  expect(await brightnessValue(page)).toBeGreaterThan(0);

  // The same deterministic sequence must repeat without a fault/stuck runtime.
  await expectArduinoBrightness(page, 'low', 'after Reset');
  const afterResetWorker = await simulationWorkerObservation(page);
  expect(
    afterResetWorker.workerSamples.some(
      (sample) =>
        sample.committedMicroseconds >= ARDUINO_RESET_HIGH_HOLD_MILLISECONDS * 1_000 &&
        (sample.workerId > (beforeResetSample?.workerId ?? 0) ||
          sample.generationId > (beforeResetSample?.generationId ?? 0)),
    ),
    JSON.stringify(afterResetWorker),
  ).toBe(true);
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  failures.assertEmpty();
});

test('Arduino correctness: Uno numeric types and scopes across delay', async ({ page }) => {
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1600, height: 1000 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Arduino typed arithmetic');
  const source = `int value=1;
void setup(){
  pinMode(13,OUTPUT);
  int halves=5/2;
  byte rollover=255;
  rollover++;
  {int value=9;delay(10);}
  digitalWrite(13,halves==2 && rollover==0 && value==1 && map(512,0,1023,0,255)==127);
}
void loop(){delay(100);}`;
  const base = arduinoInputDocument('button', '2');
  await saveDocument(page, projectId, {
    ...base,
    components: base.components.map((entry) =>
      entry.id === 'uno' ? { ...entry, stateProperties: { arduinoSource: source } } : entry,
    ),
  });
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
  await page.screenshot({ path: `${ARTIFACT_DIR}/arduino-numeric-types.png` });
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
  await expect(page.locator('.arduino-source-editor textarea')).toHaveValue(source);
  failures.assertEmpty();
});

function tmp36Document(withArduino: boolean): SchematicDocument {
  const base = arduinoInputDocument('button');
  const source =
    'void setup(){pinMode(13,OUTPUT);} void loop(){digitalWrite(13,analogRead(A0)>200);delay(10);}';
  const components: SchematicDocument['components'][number][] = withArduino
    ? base.components
        .filter((part) => ['uno', 'led', 'resistor'].includes(part.id))
        .map((part) =>
          part.id === 'uno' ? { ...part, stateProperties: { arduinoSource: source } } : part,
        )
    : [
        {
          id: 'supply',
          kind: 'source',
          componentTypeId: 'battery-holder-aa-2',
          variantId: 'battery-holder-aa-2',
          value: 3,
          position: { x: 100, y: 150 },
          pinIds: ['BAT+', 'BAT-'],
          stateProperties: { cells: 2 },
        },
      ];
  components.push(
    {
      id: 'tmp',
      kind: 'visual',
      componentTypeId: 'temperature-sensor',
      variantId: 'temperature-sensor',
      name: 'TMP36',
      value: 0,
      position: { x: 510, y: 400 },
      pinIds: ['pin-1', 'pin-2', 'pin-3'],
      stateProperties: { temperatureCelsius: 25 },
    },
    {
      id: 'meter',
      kind: 'visual',
      componentTypeId: 'multimeter',
      variantId: 'multimeter',
      name: 'Мультиметр',
      value: 0,
      position: { x: 790, y: 430 },
      pinIds: ['v-ohm-ma', 'com'],
      stateProperties: { measurementMode: 'dc-voltage' },
    },
  );
  const wires: string[][] = [
    [withArduino ? 'uno' : 'supply', withArduino ? 'power-5v' : 'BAT+', 'tmp', 'pin-1'],
    [withArduino ? 'uno' : 'supply', withArduino ? 'power-gnd-1' : 'BAT-', 'tmp', 'pin-3'],
    ['tmp', 'pin-2', 'meter', 'v-ohm-ma'],
    ['tmp', 'pin-3', 'meter', 'com'],
  ];
  if (withArduino)
    wires.push(
      ['tmp', 'pin-2', 'uno', 'a0'],
      ['uno', 'd13', 'resistor', 'lead-1'],
      ['resistor', 'lead-2', 'led', 'anode'],
      ['led', 'cathode', 'uno', 'power-gnd-1'],
    );
  return {
    ...base,
    components,
    connections: wires.map(([from, a, to, b], index) => ({
      id: `tmp-wire-${index}`,
      from: { componentId: from, terminal: a },
      to: { componentId: to, terminal: b },
      color: '#149447',
      vertices: [],
    })),
  };
}

for (const withArduino of [false, true]) {
  test(`TMP36 temperature-sensor: ${withArduino ? 'Arduino ADC' : 'standalone multimeter'} and save/reload`, async ({
    page,
  }) => {
    test.setTimeout(120_000);
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    await page.setViewportSize({ width: 1440, height: 900 });
    await loginWithOrganization(page, teacher);
    const projectId = await createProject(page, `TMP36 ${withArduino ? 'Arduino' : 'Multimeter'}`);
    await saveDocument(page, projectId, tmp36Document(withArduino));
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();
    await component(page, 'temperature-sensor').locator('.workbench-part').press('Enter');
    const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
    const input = inspector.getByRole('spinbutton', { name: 'Температура TMP36, °C' });
    await expect(input).toHaveValue('25');
    await expect(inspector.getByLabel('Модель датчика температуры')).toHaveValue('TMP36 · TO-92');
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    const display = component(page, 'multimeter').getByTestId('multimeter-runtime-display');
    await expect(display).toContainText('0.750 V');
    if (withArduino) await expect.poll(() => brightnessValue(page)).toBe(0);
    for (const [temperature, text] of [
      [0, '0.500 V'],
      [100, '1.500 V'],
    ] as const) {
      await input.fill(String(temperature));
      await expect(display).toContainText(text);
    }
    if (withArduino) await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
    await page.screenshot({
      path: `${ARTIFACT_DIR}/tmp36-${withArduino ? 'arduino' : 'multimeter'}.png`,
    });
    await page.getByRole('button', { name: 'Остановить моделирование' }).click();
    await saveEditorNow(page);
    // GET recomputes the stored document through the API's shared electronics provider.
    await expect
      .poll(
        async () => {
          const response = await page.context().request.get(`/api/projects/${projectId}`, {
            headers: { origin: new URL(page.url()).origin },
          });
          expect(response.ok()).toBe(true);
          const payload = (await response.json()) as {
            draft: { document: SchematicDocument };
            result: {
              solved: boolean;
              components: { componentId: string; sensorOutputVoltageVolt?: number }[];
            };
          };
          const saved = payload.draft.document.components.find((p) => p.id === 'tmp')
            ?.stateProperties?.['temperatureCelsius'];
          return (
            saved === 100 &&
            payload.result.solved &&
            Math.abs(
              (payload.result.components.find((p) => p.componentId === 'tmp')
                ?.sensorOutputVoltageVolt ?? 0) - 1.5,
            ) < 0.001
          );
        },
        { timeout: 25_000 },
      )
      .toBe(true);
    await page.reload();
    await component(page, 'temperature-sensor').locator('.workbench-part').press('Enter');
    await expect(input).toHaveValue('100');
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    await expect(display).toContainText('1.500 V');
    failures.assertEmpty();
  });
}

for (const withArduino of [false, true]) {
  test(`soil-moisture-sensor: ${withArduino ? 'Arduino ADC' : 'multimeter'} live moisture and persistence`, async ({
    page,
  }) => {
    test.setTimeout(120_000);
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    await page.setViewportSize({ width: 1440, height: 900 });
    await loginWithOrganization(page, teacher);
    const base = tmp36Document(withArduino);
    const doc: SchematicDocument = {
      ...base,
      components: base.components.map((p) =>
        p.id === 'tmp'
          ? {
              ...p,
              componentTypeId: 'soil-moisture-sensor',
              variantId: 'soil-moisture-sensor',
              name: 'Датчик влажности',
              pinIds: ['vcc', 'signal', 'gnd'],
              stateProperties: { moisturePercent: 50 },
            }
          : p.id === 'source' || p.id === 'supply'
            ? {
                ...p,
                componentTypeId: 'battery-holder-aa-3',
                variantId: 'battery-holder-aa-3',
                value: 4.5,
                stateProperties: { cells: 3 },
              }
            : p.id === 'uno'
              ? {
                  ...p,
                  stateProperties: {
                    arduinoSource:
                      'void setup() { pinMode(13, OUTPUT); } void loop() { digitalWrite(13, analogRead(A0) > 500); delay(1); }',
                  },
                }
              : p,
      ),
      connections: base.connections.map((w) => ({
        ...w,
        from:
          w.from.componentId === 'tmp'
            ? {
                ...w.from,
                terminal: (
                  { 'pin-1': 'vcc', 'pin-2': 'signal', 'pin-3': 'gnd' } as Record<string, string>
                )[w.from.terminal]!,
              }
            : w.from,
        to:
          w.to.componentId === 'tmp'
            ? {
                ...w.to,
                terminal: (
                  { 'pin-1': 'vcc', 'pin-2': 'signal', 'pin-3': 'gnd' } as Record<string, string>
                )[w.to.terminal]!,
              }
            : w.to,
      })),
    };
    const projectId = await createProject(page, `Soil ${withArduino ? 'Arduino' : 'Multimeter'}`);
    await saveDocument(page, projectId, doc);
    await page.goto(`/#/home/${projectId}`);
    await component(page, 'soil-moisture-sensor').locator('.workbench-part').press('Enter');
    const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
    const input = inspector.getByRole('spinbutton', { name: 'Влажность почвы, %' });
    await expect(input).toHaveValue('50');
    await expect(inspector.getByLabel('Модель датчика влажности')).toHaveValue(
      'Резистивный модуль',
    );
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    const display = component(page, 'multimeter').getByTestId('multimeter-runtime-display');
    for (const moisture of [50, 0, 100]) {
      await input.fill(String(moisture));
      const bottom = 1 / (1 / 10000 + 1 / 10e6);
      const expected =
        ((withArduino ? 5 : 4.5) * bottom) /
        (1e6 * 1e-3 ** (moisture / 100) + bottom + (withArduino ? 0 : 0.675));
      await expect
        .poll(async () =>
          Math.abs(Number.parseFloat((await display.textContent()) ?? '') - expected),
        )
        .toBeLessThan(0.002);
      if (withArduino && moisture !== 100) await expect.poll(() => brightnessValue(page)).toBe(0);
      if (withArduino && moisture === 100)
        await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
    }
    await page.screenshot({
      path: `${ARTIFACT_DIR}/soil-${withArduino ? 'arduino' : 'multimeter'}.png`,
    });
    await page.getByRole('button', { name: 'Остановить моделирование' }).click();
    await saveEditorNow(page);
    await expect
      .poll(
        async () => {
          const response = await page.context().request.get(`/api/projects/${projectId}`, {
            headers: { origin: new URL(page.url()).origin },
          });
          expect(response.ok()).toBe(true);
          const payload = await response.json();
          return (
            payload.draft.document.components.find((p: { id: string }) => p.id === 'tmp')
              ?.stateProperties?.moisturePercent === 100 &&
            payload.result.solved &&
            payload.result.components.find((p: { componentId: string }) => p.componentId === 'tmp')
              ?.sensorOutputVoltageVolt > (withArduino ? 4.5 : 4)
          );
        },
        { timeout: 25_000 },
      )
      .toBe(true);
    await page.reload();
    await component(page, 'soil-moisture-sensor').locator('.workbench-part').press('Enter');
    await expect(input).toHaveValue('100');
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    await expect
      .poll(async () => Number.parseFloat((await display.textContent()) ?? ''))
      .toBeGreaterThan(withArduino ? 4.5 : 4);
    failures.assertEmpty();
  });
}

test.beforeAll(async () => {
  mkdirSync(ARTIFACT_DIR, { recursive: true });
  admin = e2eAdminPool();
});

test.beforeEach(async ({ browserName: _browserName }, testInfo) => {
  void _browserName;
  // Authentication intentionally allows ten attempts per identifier in five
  // minutes. Give each isolated journey its own isolated teacher instead of
  // weakening that production guard or making the eleventh test fail by
  // construction.
  teacher = await seedTeacher(admin, `e2e-electronics-${testInfo.workerIndex}-${testInfo.retry}`);
});

test.afterAll(async () => {
  await admin.end();
});

// #525 BEFORE: explicit seeded mirrors; all rotations are native group commands.
test.describe('ELECTRONICS-525 complete instrument mirror matrix', () => {
  let cookies: import('@playwright/test').Cookie[];
  let actorId: string;
  test.beforeAll(async ({ browser, baseURL }, info) => {
    const context = await browser.newContext({ baseURL });
    try {
      const page = await context.newPage();
      const identity = await seedTeacher(admin, `instrument525-auth-${info.workerIndex}`);
      await loginWithOrganization(page, identity);
      const me = await context.request.get('/api/auth/me');
      expect(me.status()).toBe(200);
      const actor = (await me.json()) as { authenticated: boolean; user: { id: string } };
      expect(actor.authenticated).toBe(true);
      actorId = actor.user.id;
      cookies = await context.cookies();
    } finally {
      await context.close();
    }
  });
  for (const width of [1440, 1024, 390, 320]) {
    for (const mirror of [
      { name: 'none', x: false, y: false },
      { name: 'x', x: true, y: false },
      { name: 'y', x: false, y: true },
      { name: 'xy', x: true, y: true },
    ]) {
      test(`${width}px seeded ${mirror.name}: four instruments through all four rotations`, async ({
        browser,
        baseURL,
      }, info) => {
        test.setTimeout(120_000);
        const context = await browser.newContext({
          baseURL,
          viewport: { width, height: 1000 },
          hasTouch: width < 500,
        });
        const page = await context.newPage();
        const failures = collectBrowserFailures(page, { allowAdminAccessProbe: true });
        const rows: Record<string, unknown>[] = [];
        type Put525 = {
          id: number;
          page: string;
          phase: string;
          requestedAt: number;
          request: { baseRevision: number; mutationId: string; document: SchematicDocument };
          expected: SchematicDocument;
          runtimeSnapshot?: SchematicDocument;
          response?: {
            status: number;
            at: number;
            body: { draft: { revision: number; document: SchematicDocument } };
          };
          failure?: string;
        };
        const puts: Put525[] = [];
        const ledger: Record<string, unknown>[] = [];
        const nativeDelivered: Array<{
          page: string;
          event: {
            type: string;
            trusted: boolean;
            key?: string;
            componentId?: string;
            label?: string;
          };
        }> = [];
        const ledgerErrors: string[] = [];
        const initiators: Array<{
          page: string;
          requestId: string;
          body: Put525['request'];
          wallAt: number;
          timestamp: number;
          initiator: unknown;
        }> = [];
        const pendingResponses = new Set<Promise<void>>();
        let phase = 'matrix';
        let revision = 2;
        let acknowledged: SchematicDocument;
        let currentExpected: SchematicDocument;
        let allowedRotations = [0];
        let activeExpected: SchematicDocument[] = [];
        let finalPutCount: number | undefined;
        const journal: Record<string, unknown> = {
          width,
          mirror,
          actorId,
          rows,
          puts,
          ledger,
          nativeDelivered,
          ledgerErrors,
          initiators,
          journeyComplete: false,
        };
        const write = () => {
          try {
            writeFileSync(
              info.outputPath('instrument525-raw.json'),
              JSON.stringify(journal, null, 2),
              { flush: true },
            );
          } catch (error) {
            ledgerErrors.push(`durable journal write: ${String(error)}`);
          }
        };
        const checkpoint = (name: string, observation?: unknown) => {
          journal['lastCheckpoint'] = name;
          rows.push({ name, at: Date.now(), observation });
          write();
        };
        const acknowledge = (kind: string, data: unknown) => {
          ledger.push({ seq: ledger.length + 1, kind, at: Date.now(), phase, data });
          write(); // Node synchronous durable acknowledgement, before any assertion/teardown.
        };
        const ledgerHealthy = () => {
          expect(ledgerErrors).toEqual([]);
          expect(ledger.map((row) => row['seq'])).toEqual(ledger.map((_, index) => index + 1));
          expect(puts.every((put) => put.response && !put.failure)).toBe(true);
          const dispatches = ledger
            .filter((row) => row['kind'] === 'public-fetch-dispatch-checkpoint')
            .map(
              (row) => row['data'] as { page: string; observation: { body: Put525['request'] } },
            );
          const views = [
            puts.map((put) => ({ page: put.page, body: put.request })),
            initiators.map((entry) => ({ page: entry.page, body: entry.body })),
            dispatches.map((entry) => ({ page: entry.page, body: entry.observation.body })),
          ];
          // All three views must be bijective, not merely PW -> native provenance.
          // Reverse checks reject a native write that lost its PW request/response record.
          for (const view of views) {
            expect(view).toHaveLength(puts.length);
            for (const entry of view) {
              for (const otherView of views) {
                const matches = otherView.filter(
                  (candidate) =>
                    candidate.page === entry.page &&
                    candidate.body.mutationId === entry.body.mutationId,
                );
                expect(matches).toHaveLength(1);
                expect(matches[0]!.body).toEqual(entry.body);
              }
            }
          }
          expect(initiators.every((entry) => Boolean(entry.initiator))).toBe(true);
        };
        const settleLedger = async () => {
          if (puts.some((put) => !put.response && !put.failure))
            await expect.poll(() => puts.every((put) => put.response || put.failure)).toBe(true);
          while (pendingResponses.size) await Promise.all([...pendingResponses]);
          // Native and Playwright event deliveries may be in flight on different channels.
          // Observe convergence under the existing assertion deadline; never treat an orphan as complete.
          await expect
            .poll(
              () =>
                puts.length === initiators.length &&
                puts.length ===
                  ledger.filter((row) => row['kind'] === 'public-fetch-dispatch-checkpoint')
                    .length &&
                pendingResponses.size === 0 &&
                puts.every((put) => put.response || put.failure),
            )
            .toBe(true);
          ledgerHealthy();
        };
        let reopenedContext: import('@playwright/test').BrowserContext | undefined;
        let cleanupError: unknown;
        const orientation: Array<{
          label: string;
          axesError: number;
          centerError: number;
          windowAxesError: number;
          windowMatrixError: number;
          windowPositionError: number;
        }> = [];
        try {
          await context.addCookies(cookies);
          journal['initialOrigins'] = (await context.storageState()).origins;
          write();
          expect(journal['initialOrigins']).toEqual([]);
          // API seeds only the initial fixture. The measured Save below is native.
          const origin = baseURL!;
          const installStorageWitness = async (
            target: import('@playwright/test').BrowserContext,
          ) => {
            await target.addInitScript((origin) => {
              if (window !== window.top || location.origin !== new URL(origin).origin) return;
              const entries = (storage: Storage) =>
                Object.keys(storage).map((key) => [key, storage.getItem(key)]);
              (window as unknown as { instrument525PreApp: unknown }).instrument525PreApp = {
                local: entries(localStorage),
                session: entries(sessionStorage),
              };
            }, origin);
          };
          await context.addInitScript(() => {
            type Response =
              import('../apps/web/src/electronics/simulation-worker-protocol').ElectronicsSimulationWorkerResponse;
            const probe = window as unknown as { instrument525Committed?: Response };
            window.Worker = new Proxy(window.Worker, {
              construct(target, args, newTarget) {
                const worker = Reflect.construct(target, args, newTarget) as Worker;
                if ((args[1] as WorkerOptions | undefined)?.name === 'asa-electronics-simulation') {
                  worker.addEventListener('message', (event: MessageEvent<Response>) => {
                    const response = event.data;
                    if (
                      response.ok &&
                      response.kind === 'advance' &&
                      response.advance.executionStatus === 'ready'
                    )
                      probe.instrument525Committed = response;
                  });
                }
                return worker;
              },
            });
          });
          await installStorageWitness(context);
          await page.goto('/');
          const projectId = await createProject(page, `Instrument525 ${width} ${mirror.name}`);
          const key = `asa-project-local-draft:user:account:${encodeURIComponent(actorId)}:${encodeURIComponent(projectId)}`;
          const voltage = multimeterDcVoltageDocument(true);
          const supply = regulatedPowerSupplyDocument();
          const instrumentIds = ['meter', 'bench-supply', 'generator', 'scope'];
          const initial: SchematicDocument = {
            ...voltage,
            components: [
              ...voltage.components.map((item) => ({
                ...item,
                position: item.id === 'source' ? { x: 30, y: 30 } : { x: 180, y: 30 },
              })),
              ...supply.components.map((item) =>
                item.id === 'bench-supply'
                  ? {
                      ...item,
                      position: { x: 600, y: 30 },
                      state: true,
                      stateProperties: { ...item.stateProperties, outputEnabled: true },
                    }
                  : {
                      ...item,
                      position: { x: 810, y: 30 },
                      stateProperties: {
                        tolerancePercent: 5,
                        resistanceUnit: 'Ω',
                        ...item.stateProperties,
                      },
                    },
              ),
              {
                id: 'generator',
                kind: 'source',
                componentTypeId: 'signal-generator',
                variantId: 'signal-generator',
                name: 'Генератор',
                position: { x: 80, y: 340 },
                rotation: 0,
                value: 1_000,
                state: true,
                pinIds: ['signal', 'ground'],
                stateProperties: {
                  waveform: 'sine',
                  frequencyHz: 1_000,
                  amplitudeVpp: 5,
                  dcOffsetVolt: -0.25,
                  outputEnabled: true,
                  outputResistanceOhm: 50,
                  maxContinuousCurrentAmp: 0.1,
                },
              },
              {
                id: 'scope',
                kind: 'visual',
                componentTypeId: 'oscilloscope',
                variantId: 'oscilloscope',
                name: 'Осциллограф',
                position: { x: 520, y: 340 },
                rotation: 0,
                value: 1,
                state: true,
                pinIds: ['signal', 'ground'],
                stateProperties: {
                  voltsPerDivision: 1,
                  timePerDivisionMs: 1,
                  triggerLevelVolt: 0,
                  displayEnabled: true,
                  coupling: 'DC',
                },
              },
            ],
            connections: [
              ...voltage.connections,
              ...supply.connections,
              {
                id: 'generator-signal',
                from: { componentId: 'generator', terminal: 'signal' },
                to: { componentId: 'scope', terminal: 'signal' },
                color: '#e3212b',
                vertices: [],
              },
              {
                id: 'generator-ground',
                from: { componentId: 'generator', terminal: 'ground' },
                to: { componentId: 'scope', terminal: 'ground' },
                color: '#2a3035',
                vertices: [],
              },
            ],
            viewport: { x: 0, y: 0, zoom: 0.7 },
          };
          // Explicit fixture identities from the registered model definitions, not server output.
          const modelIdentities: Record<
            string,
            Pick<
              SchematicDocument['components'][number],
              | 'electricalModelId'
              | 'electricalModelVersion'
              | 'modelProfileId'
              | 'modelProfileVersion'
            >
          > = {
            source: {
              electricalModelId: 'ideal-dc-source',
              electricalModelVersion: 1,
              modelProfileId: 'generic-battery-pack-aa-2',
              modelProfileVersion: 1,
            },
            meter: {
              electricalModelId: 'digital-multimeter',
              electricalModelVersion: 1,
              modelProfileId: 'asa-two-terminal-dmm',
              modelProfileVersion: 3,
            },
            'bench-supply': {
              electricalModelId: 'regulated-dc-supply',
              electricalModelVersion: 1,
              modelProfileId: 'asa-bench-supply-30v-5a',
              modelProfileVersion: 1,
            },
            load: {
              electricalModelId: 'resistor',
              electricalModelVersion: 1,
              modelProfileId: 'axial-resistor',
              modelProfileVersion: 1,
            },
            generator: {
              electricalModelId: 'function-generator',
              electricalModelVersion: 1,
              modelProfileId: 'asa-function-generator-1mhz',
              modelProfileVersion: 1,
            },
            scope: {
              electricalModelId: 'oscilloscope',
              electricalModelVersion: 1,
              modelProfileId: 'asa-two-terminal-oscilloscope',
              modelProfileVersion: 1,
            },
          };
          const seeded: SchematicDocument = {
            ...initial,
            components: initial.components.map((original) => {
              const item = { ...original, ...modelIdentities[original.id] };
              return instrumentIds.includes(item.id)
                ? {
                    ...item,
                    stateProperties: {
                      ...item.stateProperties,
                      mirrorX: mirror.x,
                      mirrorY: mirror.y,
                    },
                  }
                : item;
            }),
          };
          journal['projectId'] = projectId;
          journal['initial'] = seeded;
          await saveDocument(page, projectId, seeded);
          const seed = await e01Server(page, projectId);
          journal['seed'] = seed;
          write();
          expect(seed.draft.revision).toBe(2);
          expect(seed.draft.document).toEqual(seeded);
          acknowledged = structuredClone(seeded);
          currentExpected = structuredClone(seeded);
          // Only viewport is the pre-existing geometry oracle's observed premise.
          // Every other byte comes from the seed, declared rotation, or public setter contract.
          const independentDocument = (
            rotation: number,
            viewport: SchematicDocument['viewport'],
          ) => ({
            ...seeded,
            viewport,
            components: seeded.components.map((item) => {
              if (!instrumentIds.includes(item.id)) return item;
              const size = dimensions.find((value) => value.id === item.id)!;
              const radians = (rotation * Math.PI) / 180;
              const w =
                Math.abs(size.width * Math.cos(radians)) +
                Math.abs(size.height * Math.sin(radians));
              const h =
                Math.abs(size.width * Math.sin(radians)) +
                Math.abs(size.height * Math.cos(radians));
              return {
                ...item,
                rotation: rotation as typeof item.rotation,
                position: {
                  x: item.position.x + (size.width - w) / 2,
                  y: item.position.y + (size.height - h) / 2,
                },
              };
            }),
          });
          const sameDocument = (left: SchematicDocument, right: SchematicDocument) => {
            // Preserve the existing toBeCloseTo(8) geometry premise only for component positions.
            // All other fields/numbers retain exact whole-document equality.
            const adjusted = {
              ...right,
              components: right.components.map((item, index) => {
                const observed = left.components[index];
                if (!instrumentIds.includes(item.id)) return item;
                if (
                  !observed ||
                  item.id !== observed.id ||
                  ![
                    item.position.x,
                    item.position.y,
                    observed.position.x,
                    observed.position.y,
                  ].every(Number.isFinite) ||
                  Math.abs(item.position.x - observed.position.x) >= 5e-9 ||
                  Math.abs(item.position.y - observed.position.y) >= 5e-9
                )
                  return item;
                return { ...item, position: observed.position };
              }),
            };
            try {
              expect(left).toEqual(adjusted);
              return true;
            } catch {
              return false;
            }
          };
          const recordPuts = async (target: Page, pageId: string) => {
            const dispatches = new Map<
              string,
              {
                body: Put525['request'];
                entries: Array<[string, string]>;
                at: number;
                stack?: string;
              }
            >();
            await target.exposeBinding('instrument525ObserverError', (_source, error: string) => {
              ledgerErrors.push(`dispatch observer: ${error}`);
              acknowledge('dispatch-observer-error', error);
              return ledger.length;
            });
            await target.exposeBinding(
              'instrument525DispatchAck',
              (
                _source,
                observation: {
                  body: Put525['request'];
                  entries: Array<[string, string]>;
                  at: number;
                  stack?: string;
                },
              ) => {
                if (dispatches.has(observation.body.mutationId))
                  ledgerErrors.push('Duplicate native dispatch mutation identity');
                dispatches.set(observation.body.mutationId, observation);
                acknowledge('public-fetch-dispatch-checkpoint', {
                  page: pageId,
                  observation,
                  wrapperIdentityInterference: 'UNKNOWN_NONZERO',
                });
                return ledger.length;
              },
            );
            await target.exposeBinding(
              'instrument525NativeAck',
              (_source, event: (typeof nativeDelivered)[number]['event']) => {
                nativeDelivered.push({ page: pageId, event });
                acknowledge('native-delivery', { page: pageId, event });
                return ledger.length;
              },
            );
            const installInstrument525Observer = (projectId: string) => {
              const probe = window as unknown as {
                instrument525ObserverProjectId?: string;
                instrument525ObserverError: (error: string) => Promise<number>;
                instrument525DispatchAck: (observation: unknown) => Promise<number>;
                instrument525DispatchAcks: Promise<number>[];
                instrument525NativeAck: (event: unknown) => Promise<number>;
                instrument525NativeAcks: Promise<number>[];
              };
              if (probe.instrument525ObserverProjectId === projectId) return;
              if (probe.instrument525ObserverProjectId !== undefined)
                throw new Error('Observer already installed for another project');
              probe.instrument525DispatchAcks = [];
              const descriptor = Object.getOwnPropertyDescriptor(window, 'fetch')!;
              if (!descriptor || typeof descriptor.value !== 'function')
                throw new Error('No unchanged own native fetch descriptor');
              const originalFetch = window.fetch;
              const observedFetch = new Proxy(originalFetch, {
                apply(target, receiver, args: Parameters<typeof fetch>) {
                  try {
                    const [input, options] = args;
                    const url = new URL(
                      input instanceof Request ? input.url : String(input),
                      location.href,
                    );
                    if (
                      options?.method === 'PUT' &&
                      url.pathname === `/api/projects/${projectId}/draft`
                    ) {
                      const observation = {
                        body: JSON.parse(String(options.body)),
                        entries: Object.entries(localStorage),
                        at: performance.timeOrigin + performance.now(),
                        stack: new Error('public fetch dispatch').stack,
                      };
                      // Snapshot is synchronous before the original dispatch; never await/replace its Promise.
                      probe.instrument525DispatchAcks.push(
                        probe.instrument525DispatchAck(observation),
                      );
                    }
                  } catch (error) {
                    // Observation failure must never prevent or delay the original dispatch.
                    try {
                      probe.instrument525DispatchAcks.push(
                        probe.instrument525ObserverError(String(error)),
                      );
                    } catch {
                      /* Missing ACK is detected as an incomplete dispatch checkpoint. */
                    }
                  }
                  return Reflect.apply(target, receiver, args);
                },
              });
              Object.defineProperty(window, 'fetch', { ...descriptor, value: observedFetch });
              probe.instrument525NativeAcks = [];
              for (const type of ['keydown', 'keyup', 'pointerdown', 'pointerup', 'click'])
                window.addEventListener(
                  type,
                  (event) => {
                    const target = event.target instanceof Element ? event.target : null;
                    const key = (event as KeyboardEvent).key;
                    const label =
                      target?.closest('[aria-label]')?.getAttribute('aria-label') ?? undefined;
                    if (key !== 'Enter' && label !== 'Сохранить проект') return;
                    const delivered = {
                      type,
                      key,
                      label,
                      trusted: event.isTrusted,
                      at: performance.timeOrigin + event.timeStamp,
                      componentId:
                        target?.closest('[data-component-id]')?.getAttribute('data-component-id') ??
                        undefined,
                    };
                    probe.instrument525NativeAcks.push(probe.instrument525NativeAck(delivered));
                  },
                  { capture: true, passive: true },
                );
              probe.instrument525ObserverProjectId = projectId;
            };
            await target.addInitScript(installInstrument525Observer, projectId);
            await target.evaluate(installInstrument525Observer, projectId);
            const observerReady = await target.evaluate(
              (id) =>
                (window as unknown as { instrument525ObserverProjectId?: string })
                  .instrument525ObserverProjectId === id,
              projectId,
            );
            acknowledge('public-observer-ready', { page: pageId, projectId, ready: observerReady });
            expect(observerReady).toBe(true);
            // Passive Chromium protocol provenance plus the transparent public fetch snapshot above.
            // Neither observer accesses product callbacks or changes the native fetch result/dispatch order.
            const protocol = await target.context().newCDPSession(target);
            protocol.on('Network.requestWillBeSent', (event) => {
              if (
                event.request.method !== 'PUT' ||
                new URL(event.request.url).pathname !== `/api/projects/${projectId}/draft`
              )
                return;
              try {
                if (!event.request.postData) throw new Error('Missing native initiator full body');
                const entry = {
                  page: pageId,
                  requestId: event.requestId,
                  body: JSON.parse(event.request.postData) as Put525['request'],
                  wallAt: event.wallTime * 1000,
                  timestamp: event.timestamp,
                  initiator: event.initiator,
                };
                initiators.push(entry);
                acknowledge('native-network-initiator', entry);
              } catch (error) {
                ledgerErrors.push(`native initiator capture: ${String(error)}`);
                acknowledge('initiator-error', String(error));
              }
            });
            await protocol.send('Network.enable', { maxPostDataSize: 65536 });
            const requests = new Map<import('@playwright/test').Request, Put525>();
            const runtimeCaptures = new Map<import('@playwright/test').Request, Promise<void>>();
            const matches = (request: import('@playwright/test').Request) =>
              request.method() === 'PUT' &&
              new URL(request.url()).pathname === `/api/projects/${projectId}/draft`;
            target.on('request', (request) => {
              if (!matches(request)) return;
              try {
                const body = request.postDataJSON() as Put525['request'];
                const rotationsAtRequest = [...allowedRotations];
                const expectedAtRequest = structuredClone(activeExpected);
                const put: Put525 = {
                  id: puts.length + 1,
                  page: pageId,
                  phase,
                  requestedAt: Date.now(),
                  request: body,
                  expected: structuredClone(currentExpected),
                };
                puts.push(put);
                requests.set(request, put);
                acknowledge('put-request', {
                  ...put,
                  url: request.url(),
                  resourceType: request.resourceType(),
                  navigation: request.isNavigationRequest(),
                  frameUrl: request.frame().url(),
                  timing: request.timing(),
                });

                if (!body.mutationId || typeof body.mutationId !== 'string')
                  ledgerErrors.push(`PUT ${put.id}: missing mutation identity`);
                if (puts.some((prior) => prior !== put && !prior.response))
                  ledgerErrors.push(`PUT ${put.id}: overlapping unresolved write`);
                const capture = (async () => {
                  try {
                    await expect.poll(() => dispatches.has(body.mutationId)).toBe(true);
                    const dispatch = dispatches.get(body.mutationId)!;
                    expect(dispatch.body).toEqual(body);
                    const raw = pendingElectronicsLocalDraft(dispatch.entries, projectId, actorId);
                    if (!raw) throw new Error('No public local runtime checkpoint at PUT dispatch');
                    const runtime = (JSON.parse(raw) as { document: SchematicDocument }).document;
                    put.runtimeSnapshot = runtime;
                    const candidates =
                      put.phase === 'matrix'
                        ? rotationsAtRequest.map((rotation) =>
                            independentDocument(rotation, runtime.viewport),
                          )
                        : expectedAtRequest;
                    const expected = candidates.find(
                      (candidate) =>
                        sameDocument(runtime, candidate) && sameDocument(body.document, candidate),
                    );
                    acknowledge('put-runtime-checkpoint', {
                      id: put.id,
                      runtime,
                      candidates,
                      matched: Boolean(expected),
                    });
                    if (!expected)
                      throw new Error('No independent causal expected runtime checkpoint');
                    put.expected = {
                      ...structuredClone(expected),
                      components: expected.components.map((item, index) => ({
                        ...item,
                        position: instrumentIds.includes(item.id)
                          ? runtime.components[index]!.position
                          : item.position,
                      })),
                    };
                    expect(body.document).toEqual(put.expected);
                  } catch (error) {
                    put.failure = String(error);
                    ledgerErrors.push(`PUT ${put.id} runtime checkpoint: ${String(error)}`);
                    acknowledge('runtime-checkpoint-error', { id: put.id, error: String(error) });
                  }
                })();
                runtimeCaptures.set(request, capture);
                pendingResponses.add(capture);
                void capture.finally(() => pendingResponses.delete(capture));
                write();
              } catch (error) {
                ledgerErrors.push(`request capture: ${String(error)}`);
                acknowledge('capture-error', String(error));
              }
            });
            target.on('response', (response) => {
              const put = requests.get(response.request());
              if (!put) return;
              const work = (async () => {
                try {
                  await runtimeCaptures.get(response.request());
                  const body = (await response.json()) as NonNullable<Put525['response']>['body'];
                  put.response = { status: response.status(), at: Date.now(), body };
                  acknowledge('put-response', { id: put.id, response: put.response });
                  expect(response.status()).toBe(200);
                  expect(put.request.baseRevision).toBe(revision);
                  expect(body.draft.revision).toBe(revision + 1);
                  expect(body.draft.document).toEqual(put.request.document);
                  expect(sameDocument(body.draft.document, put.expected)).toBe(true);
                  revision = body.draft.revision;
                  // The acknowledged fallback is the independently declared expected checkpoint.
                  acknowledged = structuredClone(put.expected);
                } catch (error) {
                  put.failure = String(error);
                  ledgerErrors.push(`PUT ${put.id}: ${String(error)}`);
                  acknowledge('put-response-error', { id: put.id, error: String(error) });
                }
              })();
              pendingResponses.add(work);
              void work.finally(() => pendingResponses.delete(work));
            });
            target.on('requestfailed', (request) => {
              const put = requests.get(request);
              if (!put) return;
              put.failure = request.failure()?.errorText ?? 'unknown transport failure';
              ledgerErrors.push(`PUT ${put.id}: ${put.failure}`);
              acknowledge('put-transport-failure', { id: put.id, failure: put.failure });
            });
            target.on('close', () => acknowledge('page-closed', { page: pageId }));
          };
          await recordPuts(page, 'original');
          await page.goto(`/#/home/${projectId}`);
          await expect(page.getByTestId('schematic-component')).toHaveCount(
            seeded.components.length,
          );
          const postLoadStorage = async (target: Page, name: string) => {
            const storage = await target.evaluate(() => {
              const drafts = (storage: Storage) =>
                Object.keys(storage)
                  .filter((key) => key.startsWith('asa-project-local-draft:'))
                  .map((key) => [key, storage.getItem(key)]);
              return {
                preApp: (window as unknown as { instrument525PreApp: unknown }).instrument525PreApp,
                local: drafts(localStorage),
                session: drafts(sessionStorage),
              };
            });
            checkpoint(name, storage);
            expect(storage).toEqual({
              preApp: { local: [], session: [] },
              local: [],
              session: [[`${key}:electronics-editor:`, 'saved']],
            });
          };
          await postLoadStorage(page, 'initial-storage');
          const hideLibrary = page.getByRole('button', { name: 'Скрыть компоненты', exact: true });
          if (await hideLibrary.isVisible()) await hideLibrary.click();
          await page.evaluate(() => {
            const events: unknown[] = [];
            (window as unknown as { instrument525Events: unknown[] }).instrument525Events = events;
            for (const type of [
              'keydown',
              'keyup',
              'click',
              'pointerdown',
              'pointerup',
              'pointermove',
              'mousedown',
              'mouseup',
              'mousemove',
            ]) {
              window.addEventListener(
                type,
                (event) => {
                  const key = event as KeyboardEvent;
                  const pointer = event as PointerEvent;
                  const target = event.target instanceof Element ? event.target : null;
                  events.push({
                    type,
                    trusted: event.isTrusted,
                    key: key.key,
                    shift: key.shiftKey,
                    x: pointer.clientX,
                    y: pointer.clientY,
                    pointerType: pointer.pointerType,
                    button: pointer.button,
                    buttons: pointer.buttons,
                    ancestry: target
                      ? Array.from(
                          (function* () {
                            for (let node: Element | null = target; node; node = node.parentElement)
                              yield {
                                tag: node.tagName,
                                id: node.id,
                                class: node.getAttribute('class'),
                              };
                          })(),
                        )
                      : [],
                    componentId: target
                      ?.closest('[data-component-id]')
                      ?.getAttribute('data-component-id'),
                    label: target?.closest('[aria-label]')?.getAttribute('aria-label'),
                  });
                },
                { capture: true, passive: true },
              );
            }
          });
          const local = async () => {
            const entries = await page.evaluate(() => Object.entries(localStorage));
            const raw = pendingElectronicsLocalDraft(entries, projectId, actorId);
            return raw
              ? (JSON.parse(raw) as { document: SchematicDocument }).document
              : structuredClone(acknowledged);
          };
          const part = (id: string) =>
            page.locator(
              `[data-testid="schematic-component"][data-component-id="${id}"] .workbench-part`,
            );
          const dimensions = await page.getByTestId('schematic-component').evaluateAll((nodes) =>
            nodes.map((node) => {
              const hit = node.querySelector<SVGRectElement>('.workbench-component-body-hit')!;
              return {
                id: node.getAttribute('data-component-id')!,
                width: hit.width.baseVal.value,
                height: hit.height.baseVal.value,
              };
            }),
          );
          journal['dimensions'] = dimensions;
          const focusInstrument = async (id: string) => {
            const body = part(id);
            await page.keyboard.press('Escape');
            const canvas = page.locator('.workbench-canvas');
            let field = await canvas.boundingBox();
            let bounds = await body.boundingBox();
            if (!field || !bounds) throw new Error(`Missing native pan geometry ${id}`);
            for (
              let i = 0;
              i < 8 && (bounds.width > field.width - 32 || bounds.height > field.height * 0.7);
              i++
            ) {
              await page.getByRole('button', { name: 'Уменьшить масштаб', exact: true }).click();
              bounds = await body.boundingBox();
              if (!bounds) throw new Error(`Detached body ${id}`);
            }
            const dx = field.x + field.width / 2 - bounds.x - bounds.width / 2;
            const dy = field.y + field.height * 0.4 - bounds.y - bounds.height / 2;
            const panPlan = await page.evaluate(
              ({ dx, dy }) => {
                const canvas = document.querySelector<SVGSVGElement>('.workbench-canvas');
                if (!canvas) throw new Error('Missing pan canvas');
                const rect = canvas.getBoundingClientRect();
                const width = Math.min(innerWidth, rect.right) - Math.max(0, rect.left) - 8;
                const height = Math.min(innerHeight, rect.bottom) - Math.max(0, rect.top) - 8;
                if (![dx, dy, width, height].every(Number.isFinite) || width <= 0 || height <= 0)
                  throw new Error('Invalid native pan extent');
                const count = Math.max(
                  1,
                  Math.ceil(Math.abs(dx) / width),
                  Math.ceil(Math.abs(dy) / height),
                );
                return { count, width, height, dx, dy };
              },
              { dx, dy },
            );
            checkpoint(`pan-${id}-plan`, panPlan);
            if (panPlan.count > 8) throw new Error(`Native pan segment cap ${id}`);
            let movedX = 0;
            let movedY = 0;
            for (let segment = 0; segment < panPlan.count; segment++) {
              const segmentDx = segment === panPlan.count - 1 ? dx - movedX : dx / panPlan.count;
              const segmentDy = segment === panPlan.count - 1 ? dy - movedY : dy / panPlan.count;
              const panPair = await page.evaluate(
                ({ dx, dy }) => {
                  const canvas = document.querySelector<SVGSVGElement>('.workbench-canvas');
                  if (!canvas) throw new Error('Missing pan canvas');
                  const rect = canvas.getBoundingClientRect();
                  const left = Math.max(0, rect.left) + 4;
                  const top = Math.max(0, rect.top) + 4;
                  const right = Math.min(innerWidth, rect.right) - 4;
                  const bottom = Math.min(innerHeight, rect.bottom) - 4;
                  const x0 = Math.max(left, left - dx);
                  const x1 = Math.min(right, right - dx);
                  const y0 = Math.max(top, top - dy);
                  const y1 = Math.min(bottom, bottom - dy);
                  const candidates = [];
                  for (const fy of [0.5, 0.25, 0.75, 0, 1]) {
                    for (const fx of [0.5, 0.25, 0.75, 0, 1]) {
                      const origin = { x: x0 + (x1 - x0) * fx, y: y0 + (y1 - y0) * fy };
                      const destination = { x: origin.x + dx, y: origin.y + dy };
                      const hit = document.elementFromPoint(origin.x, origin.y);
                      const endHit = document.elementFromPoint(destination.x, destination.y);
                      const eligible =
                        x0 <= x1 &&
                        y0 <= y1 &&
                        (hit === canvas ||
                          Boolean(
                            hit?.classList.contains('workbench-grid-hit') && canvas.contains(hit),
                          )) &&
                        Boolean(endHit && canvas.contains(endHit));
                      candidates.push({
                        origin,
                        destination,
                        eligible,
                        hit: hit?.outerHTML.slice(0, 500),
                        endHit: endHit?.outerHTML.slice(0, 500),
                      });
                    }
                  }
                  return {
                    selected: candidates.find((candidate) => candidate.eligible),
                    candidates,
                  };
                },
                { dx: segmentDx, dy: segmentDy },
              );
              checkpoint(`pan-${id}-${segment}-candidates`, { ...panPair, segmentDx, segmentDy });
              if (!panPair.selected) throw new Error(`No owned native pan pair ${id}`);
              const { origin, destination } = panPair.selected;
              const panWitness = async (phase: string) => {
                const observation = await page.evaluate(
                  ({ id, origin, destination }) => {
                    const canvas = document.querySelector<SVGSVGElement>('.workbench-canvas');
                    const body = document.querySelector<SVGGraphicsElement>(
                      `[data-component-id="${id}"] .workbench-part`,
                    );
                    const ancestry = (node: Element | null) => {
                      const result = [];
                      for (; node; node = node.parentElement)
                        result.push({
                          tag: node.tagName,
                          id: node.id,
                          class: node.getAttribute('class'),
                        });
                      return result;
                    };
                    const geometry = (node: SVGGraphicsElement | null) => {
                      const bounds = node?.getBoundingClientRect();
                      const ctm = node?.getScreenCTM();
                      return {
                        bounds: bounds?.toJSON(),
                        ctm: ctm ? [ctm.a, ctm.b, ctm.c, ctm.d, ctm.e, ctm.f] : null,
                        connected: node?.isConnected ?? false,
                      };
                    };
                    return {
                      origin,
                      destination,
                      originHit: ancestry(document.elementFromPoint(origin.x, origin.y)),
                      destinationHit: ancestry(
                        document.elementFromPoint(destination.x, destination.y),
                      ),
                      canvas: geometry(canvas),
                      body: geometry(body),
                      viewBox: canvas?.getAttribute('viewBox'),
                      events: (window as unknown as { instrument525Events: unknown[] })
                        .instrument525Events,
                    };
                  },
                  {
                    id,
                    origin,
                    destination,
                  },
                );
                journal['nativeEvents'] = observation.events;
                checkpoint(`pan-${id}-${segment}-${phase}`, observation);
              };
              await panWitness('before');
              let panWitnessError: unknown;
              try {
                await page.mouse.move(origin.x, origin.y);
                await page.mouse.down({ button: 'middle' });
                await page.mouse.move(destination.x, destination.y, { steps: 4 });
                await page.mouse.up({ button: 'middle' });
              } finally {
                try {
                  await panWitness('after');
                } catch (error) {
                  rows.push({ name: `pan-${id}-witness-error`, error: String(error) });
                  write();
                  panWitnessError = error;
                }
              }
              if (panWitnessError) throw panWitnessError;
              movedX += segmentDx;
              movedY += segmentDy;
            }
            checkpoint(`pan-${id}-total`, { dx, dy, movedX, movedY, count: panPlan.count });
            field = await canvas.boundingBox();
            bounds = await body.boundingBox();
            checkpoint(`focused-${id}`, { field, bounds });
            expect(
              Boolean(
                field &&
                bounds &&
                bounds.x >= field.x + 4 &&
                bounds.y >= field.y + 4 &&
                bounds.x + bounds.width <= field.x + field.width - 4 &&
                bounds.y + bounds.height <= field.y + field.height - 4,
              ),
            ).toBe(true);
            return body;
          };
          const measured: Array<{
            rotation: number;
            state: string;
            id: string;
            readings: Array<{
              text: string | null;
              axesError: number;
              centerError: number;
              windowAxesError: number;
              windowMatrixError: number;
              windowPositionError: number;
              finite: boolean;
              rect: { x: number; y: number; width: number; height: number };
            }>;
          }> = [];
          // Independent declared geometry: the runtime SVG is x=0/y=0, xMidYMid meet.
          // Do not infer its placement/scale from the observed window or hit rectangle.
          const declaredCatalog = JSON.parse(
            readFileSync(
              resolve(
                process.cwd(),
                'apps/web/public/assets/electronics/component-database/catalog.json',
              ),
              'utf8',
            ),
          ) as {
            worldUnitsPerMm: number;
            components: Array<{
              componentId: string;
              physicalWidthMm: number;
              physicalHeightMm: number;
              viewBox: number[];
            }>;
          };
          const capture = async (id: string, rotation: number, state: string) => {
            const declared = declaredCatalog.components.find(
              (entry) =>
                entry.componentId ===
                seeded.components.find((component) => component.id === id)!.componentTypeId,
            )!;
            const body = await focusInstrument(id);
            const observation = await body.evaluate(
              (body, mirror) => {
                const selectors =
                  '.workbench-multimeter-reading,.workbench-regulated-supply-reading,.workbench-signal-generator-readings text,.workbench-oscilloscope-status,.workbench-oscilloscope-scale';
                const matrix = (value: DOMMatrix | null) => {
                  if (!value) throw new Error('Missing readout CTM');
                  return [value.a, value.b, value.c, value.d, value.e, value.f];
                };
                const normalize = (x: number, y: number) => {
                  const length = Math.hypot(x, y);
                  if (!Number.isFinite(length) || !length)
                    throw new Error('Nonfinite readout axis');
                  return [x / length, y / length];
                };
                const bodyMatrix = matrix((body as SVGGraphicsElement).getScreenCTM());
                const canvas = document
                  .querySelector<SVGSVGElement>('.workbench-canvas')!
                  .getScreenCTM()!;
                const radians = (mirror.rotation * Math.PI) / 180,
                  cos = Math.cos(radians),
                  sin = Math.sin(radians);
                const expectedBodyX = normalize(
                  (canvas.a * cos + canvas.c * sin) * (mirror.x ? -1 : 1),
                  (canvas.b * cos + canvas.d * sin) * (mirror.x ? -1 : 1),
                );
                const expectedBodyY = normalize(
                  (-canvas.a * sin + canvas.c * cos) * (mirror.y ? -1 : 1),
                  (-canvas.b * sin + canvas.d * cos) * (mirror.y ? -1 : 1),
                );
                const bodyX = normalize(bodyMatrix[0]!, bodyMatrix[1]!),
                  bodyY = normalize(bodyMatrix[2]!, bodyMatrix[3]!);
                const bodyAxesError = Math.max(
                  ...bodyX.map((v, i) => Math.abs(v - expectedBodyX[i]!)),
                  ...bodyY.map((v, i) => Math.abs(v - expectedBodyY[i]!)),
                );
                const readings = [...body.querySelectorAll<SVGTextElement>(selectors)].map(
                  (text) => {
                    const glyph = text.getScreenCTM()!;
                    const windowMatrix = text.ownerSVGElement!.getScreenCTM()!;
                    const bbox = text.getBBox();
                    const center = new DOMPoint(bbox.x + bbox.width / 2, bbox.y + bbox.height / 2);
                    const actual = center.matrixTransform(glyph);
                    const [viewX, viewY, viewWidth, viewHeight] = mirror.viewBox;
                    const scale = Math.min(mirror.width / viewWidth!, mirror.height / viewHeight!);
                    const offsetX = (mirror.width - viewWidth! * scale) / 2 - viewX! * scale;
                    const offsetY = (mirror.height - viewHeight! * scale) / 2 - viewY! * scale;
                    const expectedWindow = {
                      a: bodyMatrix[0]! * scale,
                      b: bodyMatrix[1]! * scale,
                      c: bodyMatrix[2]! * scale,
                      d: bodyMatrix[3]! * scale,
                      e: bodyMatrix[0]! * offsetX + bodyMatrix[2]! * offsetY + bodyMatrix[4]!,
                      f: bodyMatrix[1]! * offsetX + bodyMatrix[3]! * offsetY + bodyMatrix[5]!,
                    };
                    const expected = {
                      x:
                        expectedWindow.a * center.x +
                        expectedWindow.c * center.y +
                        expectedWindow.e,
                      y:
                        expectedWindow.b * center.x +
                        expectedWindow.d * center.y +
                        expectedWindow.f,
                    };
                    const windowMatrixError = Math.max(
                      Math.abs(windowMatrix.a - expectedWindow.a),
                      Math.abs(windowMatrix.b - expectedWindow.b),
                      Math.abs(windowMatrix.c - expectedWindow.c),
                      Math.abs(windowMatrix.d - expectedWindow.d),
                    );
                    const windowPositionError = Math.hypot(
                      windowMatrix.e - expectedWindow.e,
                      windowMatrix.f - expectedWindow.f,
                    );
                    const rect = text.getBoundingClientRect();
                    const actualX = normalize(glyph.a, glyph.b),
                      actualY = normalize(glyph.c, glyph.d);
                    // Glyph orientation is independent of the observed nested window.
                    const expectedX = normalize(
                      canvas.a * cos + canvas.c * sin,
                      canvas.b * cos + canvas.d * sin,
                    );
                    const expectedY = normalize(
                      -canvas.a * sin + canvas.c * cos,
                      -canvas.b * sin + canvas.d * cos,
                    );
                    const windowX = normalize(windowMatrix.a, windowMatrix.b),
                      windowY = normalize(windowMatrix.c, windowMatrix.d);
                    const windowAxesError = Math.max(
                      ...windowX.map((v, i) => Math.abs(v - expectedBodyX[i]!)),
                      ...windowY.map((v, i) => Math.abs(v - expectedBodyY[i]!)),
                    );
                    const raw = {
                      glyph: matrix(glyph),
                      window: matrix(windowMatrix),
                      expectedWindow: [
                        expectedWindow.a,
                        expectedWindow.b,
                        expectedWindow.c,
                        expectedWindow.d,
                        expectedWindow.e,
                        expectedWindow.f,
                      ],
                      declaredViewport: [mirror.width, mirror.height, ...mirror.viewBox],
                      bbox: [bbox.x, bbox.y, bbox.width, bbox.height],
                      actualX,
                      actualY,
                      expectedX,
                      expectedY,
                      windowX,
                      windowY,
                      expectedWindowX: expectedBodyX,
                      expectedWindowY: expectedBodyY,
                      actualCenter: [actual.x, actual.y],
                      expectedCenter: [expected.x, expected.y],
                    };
                    return {
                      text: text.textContent,
                      raw,
                      rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
                      finite: Object.values(raw).flat().every(Number.isFinite),
                      axesError: Math.max(
                        ...actualX.map((v, i) => Math.abs(v - expectedX[i]!)),
                        ...actualY.map((v, i) => Math.abs(v - expectedY[i]!)),
                      ),
                      windowAxesError,
                      windowMatrixError,
                      windowPositionError,
                      centerError: Math.hypot(actual.x - expected.x, actual.y - expected.y),
                    };
                  },
                );
                const hit = body.querySelector('.workbench-component-body-hit');
                const box = body.getBoundingClientRect();
                const hitTarget = document.elementFromPoint(
                  box.x + box.width / 2,
                  box.y + box.height / 2,
                );
                return {
                  bodyMatrix,
                  canvasMatrix: matrix(canvas),
                  expectedBodyX,
                  expectedBodyY,
                  bodyAxesError,
                  bodyTransform: body.getAttribute('transform'),
                  hit: hit?.outerHTML,
                  centerHitComponent: hitTarget
                    ?.closest('[data-component-id]')
                    ?.getAttribute('data-component-id'),
                  readings,
                  traceCount: body.querySelectorAll('.workbench-oscilloscope-trace').length,
                };
              },
              {
                ...mirror,
                rotation,
                width: declared.physicalWidthMm * declaredCatalog.worldUnitsPerMm,
                height: declared.physicalHeightMm * declaredCatalog.worldUnitsPerMm,
                viewBox: declared.viewBox,
              },
            );
            const committed =
              state === 'active'
                ? await page.evaluate(
                    () =>
                      (
                        window as unknown as {
                          instrument525Committed?: import('../apps/web/src/electronics/simulation-worker-protocol').ElectronicsSimulationWorkerResponse;
                        }
                      ).instrument525Committed,
                  )
                : undefined;
            const row = { id, rotation, state, ...observation, committed };
            measured.push(row);
            checkpoint(`readout-${id}-${rotation}-${state}`, row);
            if (state === 'active') {
              expect(committed?.ok && committed.kind === 'advance').toBe(true);
              if (!committed?.ok || committed.kind !== 'advance')
                throw new Error('Missing committed ready instrument response');
              const advance = committed.advance;
              expect(advance.committedHorizonMicroseconds).toBe(
                advance.requestedHorizonMicroseconds,
              );
              expect(advance.result).toMatchObject({
                solved: true,
                status: 'solved',
                quality: { finite: true, passed: true },
              });
              const finite = (value: unknown): boolean =>
                typeof value === 'number'
                  ? Number.isFinite(value)
                  : Array.isArray(value)
                    ? value.every(finite)
                    : value !== null && typeof value === 'object'
                      ? Object.values(value).every(finite)
                      : true;
              expect(finite(advance.result)).toBe(true);
              if (id === 'meter') {
                const result = advance.result?.components.find(
                  (item) => item.componentId === 'meter',
                );
                expect(result?.measuredValue).toBeCloseTo(-2.999999865, 6);
                expect(result).toMatchObject({
                  measurementMode: 'dc-voltage',
                  measurementUnit: 'V',
                });
              }
              const result = advance.result?.components.find((item) => item.componentId === id);
              if (id === 'bench-supply') {
                expect(result?.regulatedOutputEnabled).toBe(true);
                expect(`${result?.voltageDrop.toFixed(2)} V`).toBe(observation.readings[0]?.text);
                expect(`${Math.abs(result?.current ?? Number.NaN).toFixed(3)} A`).toBe(
                  observation.readings[1]?.text,
                );
              } else if (id === 'generator')
                expect(result).toMatchObject({
                  signalWaveform: 'sine',
                  signalFrequencyHz: 1000,
                  signalAmplitudeVpp: 5,
                  signalOffsetVolt: -0.25,
                  signalOutputEnabled: true,
                });
              else if (id === 'scope')
                expect(result).toMatchObject({
                  oscilloscopeFrequencyHz: 1000,
                  oscilloscopeAmplitudeVpp: 5,
                  oscilloscopeVoltsPerDivision: 1,
                  oscilloscopeTimePerDivisionMs: 1,
                });
            }
            expect(observation.bodyMatrix.every(Number.isFinite)).toBe(true);
            expect(observation.bodyAxesError).toBeLessThan(0.000001);
            const count =
              id === 'meter' ? (state === 'stopped' ? 0 : 1) : id === 'generator' ? 3 : 2;
            expect(observation.readings).toHaveLength(count);
            expect(
              observation.readings.every(
                (r) =>
                  r.finite &&
                  Boolean(r.text?.trim()) &&
                  r.rect.width > 0 &&
                  r.rect.height > 0 &&
                  r.rect.x >= 0 &&
                  r.rect.y >= 0 &&
                  r.rect.x + r.rect.width <= width &&
                  r.rect.y + r.rect.height <= 1000,
              ),
            ).toBe(true);
            if (state === 'active')
              await page.screenshot({
                path: info.outputPath(`instrument525-${rotation}-${id}-active.png`),
              });
            return row;
          };
          const assertGeometry = async (rotation: number) => {
            const actual = await local();
            const intended = {
              ...seeded,
              viewport: actual.viewport,
              simulation: { ...seeded.simulation, running: false },
              components: seeded.components.map((item) => {
                if (!instrumentIds.includes(item.id)) return item;
                const size = dimensions.find((value) => value.id === item.id)!;
                const observed = actual.components.find((value) => value.id === item.id)!;
                const swapped = rotation === 90 || rotation === 270;
                const x =
                  item.position.x + size.width / 2 - (swapped ? size.height : size.width) / 2;
                const y =
                  item.position.y + size.height / 2 - (swapped ? size.width : size.height) / 2;
                expect(observed.position.x).toBeCloseTo(x, 8);
                expect(observed.position.y).toBeCloseTo(y, 8);
                return {
                  ...item,
                  rotation: rotation as 0 | 90 | 180 | 270,
                  position: observed.position,
                };
              }),
            };
            checkpoint(`whole-document-${rotation}`, { actual, intended });
            expect(actual).toEqual(intended);
            await settleLedger();
            const server = await e01Server(page, projectId);
            acknowledge('rotation-server', { rotation, server, revision, acknowledged, intended });
            expect(server.draft.revision).toBe(revision);
            expect(server.draft.document).toEqual(acknowledged);
            const endpoints = await page.evaluate(
              (connections) =>
                connections.flatMap((wire) => {
                  const path = document.querySelector<SVGPathElement>(
                    `[data-testid="schematic-wire"][data-wire-id="${wire.id}"]`,
                  )!;
                  return [wire.from, wire.to].map((endpoint, index) => {
                    const terminal = document.querySelector<SVGGraphicsElement>(
                      `[data-terminal-component-id="${endpoint.componentId}"][data-terminal-id="${endpoint.terminal}"]`,
                    )!;
                    const a = new DOMPoint(0, 0).matrixTransform(terminal.getScreenCTM()!);
                    const point = path.getPointAtLength(index === 0 ? 0 : path.getTotalLength());
                    const b = new DOMPoint(point.x, point.y).matrixTransform(path.getScreenCTM()!);
                    return { wire: wire.id, endpoint, error: Math.hypot(a.x - b.x, a.y - b.y) };
                  });
                }),
              seeded.connections,
            );
            checkpoint(`wire-endpoints-${rotation}`, endpoints);
            expect(
              endpoints.every((entry) => Number.isFinite(entry.error) && entry.error < 0.1),
            ).toBe(true);
            return intended;
          };
          let expected = seeded;
          for (const rotation of [0, 90, 180, 270]) {
            if (rotation) {
              for (const [index, id] of instrumentIds.entries())
                await part(id).press(index ? 'Shift+Enter' : 'Enter');
              expect(await page.locator('.workbench-part.selected').count()).toBe(4);
              allowedRotations = [rotation - 90, rotation - 45];
              acknowledge('native-rotate', { target: rotation - 45 });
              await page.getByRole('button', { name: 'Повернуть на 45° (R)', exact: true }).click();
              allowedRotations = [rotation - 45, rotation];
              acknowledge('native-rotate', { target: rotation });
              await page.getByRole('button', { name: 'Повернуть на 45° (R)', exact: true }).click();
            }
            await assertGeometry(rotation);
            const previousGeneration = await page.evaluate(
              () =>
                (
                  window as unknown as {
                    instrument525Committed?: { generationId: number };
                  }
                ).instrument525Committed?.generationId,
            );
            await page.getByRole('button', { name: 'Начать моделирование', exact: true }).click();
            await expect
              .poll(async () =>
                page.evaluate((previous) => {
                  const current = (
                    window as unknown as { instrument525Committed?: { generationId: number } }
                  ).instrument525Committed;
                  return (
                    typeof current?.generationId === 'number' && current.generationId !== previous
                  );
                }, previousGeneration),
              )
              .toBe(true);
            const meter = component(page, 'multimeter').getByTestId('multimeter-runtime-display');
            await expect
              .poll(async () => Number(await meter.getAttribute('data-measured-value')))
              .toBeCloseTo(-2.999999865, 6);
            await expect(meter.locator('.workbench-multimeter-reading')).toHaveText('-3.000 V');
            await expect(
              component(page, 'regulated-power-supply')
                .locator('.workbench-regulated-supply-reading')
                .first(),
            ).toHaveText('5.00 V');
            await expect(
              component(page, 'oscilloscope').locator('.workbench-oscilloscope-status'),
            ).toHaveText('1.00 kHz · 5.00 Vpp');
            await expect(
              component(page, 'oscilloscope').locator('.workbench-oscilloscope-scale'),
            ).toHaveText('1.00 V/div · 1.00 ms/div');
            await expect(
              component(page, 'signal-generator').locator(
                '.workbench-signal-generator-readings text',
              ),
            ).toHaveText(['1.00 kHz', '5.00 Vpp', '-0.25 V']);
            for (const id of instrumentIds) await capture(id, rotation, 'active');
            // Every mirror/width exercises the real controls, not an oracle-only transform.
            if (rotation === 0) {
              await focusInstrument('meter');
              await meter
                .locator('.workbench-multimeter-mode-button.workbench-multimeter-mode-resistance')
                .click();
              await expect(meter).toHaveAttribute('data-measurement-mode', 'resistance');
              await expect(meter.locator('.workbench-multimeter-reading')).toHaveText('ОШИБКА');
              await capture('meter', rotation, 'external-voltage-error');
              await meter
                .locator('.workbench-multimeter-mode-button.workbench-multimeter-mode-voltage')
                .click();
              await expect(meter.locator('.workbench-multimeter-reading')).toHaveText('-3.000 V');
              await focusInstrument('bench-supply');
              const supply = component(page, 'regulated-power-supply').getByTestId(
                'regulated-power-supply-runtime',
              );
              const clickOwnedRect = async (
                control: import('@playwright/test').Locator,
                label: string,
              ) => {
                const ownedPoint = await control.evaluate((node) => {
                  if (!(node instanceof SVGRectElement) || !node.isConnected)
                    throw new Error('Missing control RECT');
                  const matrix = node.getScreenCTM();
                  if (!matrix) throw new Error('Missing control CTM');
                  const candidates = [];
                  for (const fy of [0.5, 0.25, 0.75]) {
                    for (const fx of [0.5, 0.25, 0.75]) {
                      const point = new DOMPoint(
                        node.x.baseVal.value + node.width.baseVal.value * fx,
                        node.y.baseVal.value + node.height.baseVal.value * fy,
                      ).matrixTransform(matrix);
                      const hit = document.elementFromPoint(point.x, point.y);
                      candidates.push({
                        x: point.x,
                        y: point.y,
                        eligible:
                          Number.isFinite(point.x) &&
                          Number.isFinite(point.y) &&
                          Boolean(hit && (hit === node || node.contains(hit))),
                        hit: hit?.outerHTML.slice(0, 500),
                      });
                    }
                  }
                  return {
                    selected: candidates.find((candidate) => candidate.eligible),
                    candidates,
                  };
                });
                checkpoint(`${label}-owned-candidates`, ownedPoint);
                if (!ownedPoint.selected) throw new Error(`No owned ${label} native point`);
                await page.mouse.click(ownedPoint.selected.x, ownedPoint.selected.y);
              };
              await clickOwnedRect(
                supply.locator('.workbench-regulated-supply-power-slider'),
                'supply-power-slider',
              );
              await expect(supply).toHaveAttribute('data-output-enabled', 'false');
              await expect(supply).toHaveAttribute('data-regulation-mode', 'off');
              await expect(supply.locator('.workbench-regulated-supply-reading')).toHaveText([
                '5.00 V',
                '1.000 A',
              ]);
              await capture('bench-supply', rotation, 'output-disabled');
              await clickOwnedRect(
                supply.locator('.workbench-regulated-supply-power-slider'),
                'supply-power-slider',
              );
              await expect(supply).toHaveAttribute('data-output-enabled', 'true');
              await focusInstrument('generator');
              const generator = component(page, 'signal-generator').getByTestId(
                'signal-generator-runtime',
              );
              await clickOwnedRect(
                generator.locator('.workbench-signal-generator-triangle'),
                'triangle',
              );
              await expect(generator).toHaveAttribute('data-waveform', 'triangle');
              await generator.locator('.workbench-signal-generator-power-slider').click();
              await expect(generator).toHaveAttribute('data-output-enabled', 'false');
              await expect(
                generator.locator('.workbench-signal-generator-readings text'),
              ).toHaveText(['1.00 kHz', '5.00 Vpp', '-0.25 V']);
              await capture('generator', rotation, 'output-disabled');
              await generator.locator('.workbench-signal-generator-power-slider').click();
              await expect(generator).toHaveAttribute('data-output-enabled', 'true');
              await clickOwnedRect(generator.locator('.workbench-signal-generator-sine'), 'sine');
              await expect(generator).toHaveAttribute('data-waveform', 'sine');
            }
            await page
              .getByRole('button', { name: 'Остановить моделирование', exact: true })
              .click();
            await expect(meter.locator('.workbench-multimeter-reading')).toHaveCount(0);
            await expect(
              component(page, 'oscilloscope').getByTestId('oscilloscope-runtime'),
            ).toHaveAttribute('data-display-enabled', 'false');
            await expect(
              component(page, 'oscilloscope').locator('.workbench-oscilloscope-status'),
            ).toHaveText('OFF');
            await capture('scope', rotation, 'stopped');
            expected = await assertGeometry(rotation);
          }
          await settleLedger();
          phase = 'checkpoint';
          currentExpected = structuredClone(expected);
          activeExpected = [currentExpected];
          const save = page.getByRole('button', { name: 'Сохранить проект', exact: true });
          const saveState = async () => {
            const state = {
              disabled: await save.isDisabled(),
              pending: pendingResponses.size,
              revision,
              puts: puts.length,
              local: await local(),
            };
            acknowledge('save-state', state);
            return state;
          };
          // A distinct, explicitly selected checkpoint action, never a final-Save retry.
          let boundary = await saveState();
          if (boundary.pending) {
            await settleLedger();
            boundary = await saveState();
          }
          expect(boundary.local).toEqual(expected);
          if (!boundary.disabled) {
            const before = puts.length;
            acknowledge('checkpoint-save-before', { before, revision, expected });
            if (width < 500) await save.tap();
            else await save.click();
            await expect
              .poll(() => puts.filter((put) => put.phase === 'checkpoint' && put.response).length)
              .toBe(1);
            await settleLedger();
            acknowledge('checkpoint-save-after', { before, puts: puts.length, revision });
            expect(puts.length).toBe(before + 1);
          }
          await expect(save).toBeDisabled();
          await settleLedger();
          const cleanServer = await e01Server(page, projectId);
          acknowledge('clean-acknowledged-boundary', {
            cleanServer,
            expected,
            acknowledged,
            revision,
          });
          expect(cleanServer.draft.revision).toBe(revision);
          expect(cleanServer.draft.document).toEqual(expected);
          expect(acknowledged).toEqual(expected);
          phase = 'final-edits';
          const finalDirtyAt = Date.now();
          acknowledge('final-edit-phase-start', { finalDirtyAt, revision });
          await focusInstrument('generator');
          const inspectorWitness = async (name: string) => {
            const observation = await page.evaluate(() => ({
              shellClass: document.querySelector('.workbench-shell')?.className,
              catalogPressed: document
                .querySelector('[aria-label="Каталог деталей"]')
                ?.getAttribute('aria-pressed'),
              selected: [...document.querySelectorAll('.workbench-part.selected')].map((node) =>
                node.closest('[data-component-id]')?.getAttribute('data-component-id'),
              ),
              active: document.activeElement?.outerHTML.slice(0, 1000),
              events: (window as unknown as { instrument525Events: unknown[] }).instrument525Events,
            }));
            acknowledge(name, observation);
            return observation;
          };
          const enterCount = (events: unknown) =>
            (
              events as Array<{
                type: string;
                trusted: boolean;
                key?: string;
                componentId?: string;
              }>
            ).filter(
              (event) =>
                event.type === 'keydown' &&
                event.trusted &&
                event.key === 'Enter' &&
                event.componentId === 'generator',
            ).length;
          const nativeFence = async () => {
            const sequences = await page.evaluate(async () =>
              Promise.all([
                ...(window as unknown as { instrument525NativeAcks: Promise<number>[] })
                  .instrument525NativeAcks,
                ...(window as unknown as { instrument525DispatchAcks: Promise<number>[] })
                  .instrument525DispatchAcks,
              ]),
            );
            acknowledge('native-ack-fence', { sequences });
            expect(sequences.every((seq) => Number.isInteger(seq) && seq > 0)).toBe(true);
          };
          await nativeFence();
          const beforeNativeEnter = nativeDelivered.filter(
            (entry) =>
              entry.page === 'original' &&
              entry.event.type === 'keydown' &&
              entry.event.key === 'Enter' &&
              entry.event.componentId === 'generator' &&
              entry.event.trusted,
          ).length;
          const beforeEnter = await inspectorWitness('final-enter-before');
          await part('generator').press('Enter');
          await nativeFence();
          const afterNativeEnter = nativeDelivered.filter(
            (entry) =>
              entry.page === 'original' &&
              entry.event.type === 'keydown' &&
              entry.event.key === 'Enter' &&
              entry.event.componentId === 'generator' &&
              entry.event.trusted,
          ).length;
          expect(afterNativeEnter - beforeNativeEnter).toBe(1);
          const afterEnter = await inspectorWitness('final-enter-after');
          expect(afterEnter.selected).toEqual(['generator']);
          expect(enterCount(afterEnter.events) - enterCount(beforeEnter.events)).toBe(1);
          if (width < 500) {
            const beforeInspector = await inspectorWitness('inspector-precondition');
            const open =
              beforeInspector.catalogPressed === 'true' &&
              !String(beforeInspector.shellClass).includes('library-collapsed');
            const closed =
              beforeInspector.catalogPressed === 'false' &&
              String(beforeInspector.shellClass).includes('library-collapsed');
            expect(open || closed).toBe(true);
            if (open) {
              await page.getByRole('button', { name: 'Каталог деталей', exact: true }).tap();
              const afterClose = await inspectorWitness('catalog-native-close-after');
              expect(afterClose.catalogPressed).toBe('false');
              expect(String(afterClose.shellClass)).toContain('library-collapsed');
            }
          }
          const frequency = page.getByLabel('Частота генератора', { exact: true });
          acknowledge('final-input-visibility', {
            beforeEnter,
            visible: await frequency.isVisible(),
          });
          await expect(frequency).toBeVisible();
          const patchGenerator = (patch: Record<string, number>, value?: number) => ({
            ...currentExpected,
            components: currentExpected.components.map((item) =>
              item.id === 'generator'
                ? {
                    ...item,
                    ...(value === undefined ? {} : { value }),
                    stateProperties: { ...item.stateProperties, ...patch },
                  }
                : item,
            ),
          });
          const admit = (document: SchematicDocument) => {
            currentExpected = document;
            activeExpected.push(structuredClone(document));
            acknowledge('independent-final-checkpoint', { expected: document });
          };
          admit(patchGenerator({ frequencyHz: 1000000 }, 1000000));
          await frequency.fill('1000000');
          admit(patchGenerator({ amplitudeVpp: 10 }));
          await page.getByLabel('Амплитуда генератора пик-пик', { exact: true }).fill('10');
          admit(patchGenerator({ dcOffsetVolt: -5 }));
          await page.getByLabel('Постоянное смещение генератора', { exact: true }).fill('-5');
          await expect(
            component(page, 'signal-generator').locator(
              '.workbench-signal-generator-readings text',
            ),
          ).toHaveText(['1.00 MHz', '10.00 Vpp', '-5.00 V']);
          await capture('generator', 270, 'long-supported-setpoint-stopped');
          const finalLocal = await local();
          expected = { ...currentExpected, viewport: finalLocal.viewport };
          activeExpected = [expected];
          checkpoint('intended-final-document', { finalLocal, expected });
          expect(finalLocal).toEqual(expected);
          expect(measured.filter((row) => row.state === 'active')).toHaveLength(16);
          await settleLedger();
          expect(puts.filter((put) => put.phase === 'final-edits')).toHaveLength(0);
          await expect(save).toBeEnabled();
          const beforeFinal = puts.length;
          const finalBase = revision;
          phase = 'final-save';
          acknowledge('final-save-before', { beforeFinal, finalBase, finalDirtyAt, expected });
          if (width < 500) await save.tap();
          else await save.click();
          await expect
            .poll(() => puts.filter((put) => put.phase === 'final-save' && put.response).length)
            .toBe(1);
          await settleLedger();
          const finalPut = puts[beforeFinal]!;
          await nativeFence();
          acknowledge('final-save-acknowledged', { finalPut, finalDirtyAt, revision });
          expect(puts.length).toBe(beforeFinal + 1);
          expect(finalPut.request).toMatchObject({ baseRevision: finalBase, document: expected });
          expect(finalPut.requestedAt).toBeLessThan(finalDirtyAt + 60000);
          expect(Date.now()).toBeLessThan(finalDirtyAt + 60000);
          expect(revision).toBe(finalBase + 1);
          const saved = await e01Server(page, projectId);
          checkpoint('saved', { saved, expected });
          expect(saved.draft.revision).toBe(finalBase + 1);
          expect(saved.draft.document).toEqual(expected);
          finalPutCount = puts.length;
          phase = 'reopen';
          reopenedContext = await browser.newContext({
            baseURL,
            viewport: { width, height: 1000 },
            hasTouch: width < 500,
          });
          await reopenedContext.addCookies(await context.cookies());
          journal['freshOrigins'] = (await reopenedContext.storageState()).origins;
          write();
          expect(journal['freshOrigins']).toEqual([]);
          await installStorageWitness(reopenedContext);
          const reopened = await reopenedContext.newPage();
          const reopenedFailures = collectBrowserFailures(reopened, {
            allowAdminAccessProbe: true,
          });
          await recordPuts(reopened, 'reopened');
          const freshGET = reopened.waitForResponse(
            (response) =>
              response.request().method() === 'GET' &&
              new URL(response.url()).pathname === `/api/projects/${projectId}`,
          );
          await reopened.goto(`/#/home/${projectId}`);
          await expect(reopened.getByTestId('schematic-component')).toHaveCount(
            expected.components.length,
          );
          const delivery = await freshGET;
          expect(delivery.status()).toBe(200);
          const delivered = (await delivery.json()) as { draft: unknown };
          checkpoint('reopened-server', {
            delivered,
            freshServer: await e01Server(reopened, projectId),
          });
          expect(delivered.draft).toEqual(saved.draft);
          expect((await e01Server(reopened, projectId)).draft).toEqual(saved.draft);
          await postLoadStorage(reopened, 'reopened-storage');
          const rendered = await reopened.getByTestId('schematic-component').evaluateAll((nodes) =>
            nodes.map((node) => ({
              id: node.getAttribute('data-component-id'),
              type: node.getAttribute('data-component-type'),
              transform: node.querySelector('.workbench-part')?.getAttribute('transform'),
              terminals: [...node.querySelectorAll('[data-terminal-id]')].map((terminal) =>
                terminal.getAttribute('data-terminal-id'),
              ),
            })),
          );
          const originalRendered = await page
            .getByTestId('schematic-component')
            .evaluateAll((nodes) =>
              nodes.map((node) => ({
                id: node.getAttribute('data-component-id'),
                type: node.getAttribute('data-component-type'),
                transform: node.querySelector('.workbench-part')?.getAttribute('transform'),
                terminals: [...node.querySelectorAll('[data-terminal-id]')].map((terminal) =>
                  terminal.getAttribute('data-terminal-id'),
                ),
              })),
            );
          checkpoint('rendered-equality', { rendered, originalRendered });
          expect(rendered).toEqual(originalRendered);
          expect(rendered.map((item) => item.id)).toEqual(
            expected.components.map((item) => item.id),
          );
          await settleLedger();
          expect(puts).toHaveLength(finalPutCount!);
          journal['nativeEvents'] = await page.evaluate(
            () => (window as unknown as { instrument525Events: unknown[] }).instrument525Events,
          );
          const nativeEvents = journal['nativeEvents'] as Array<{
            type: string;
            trusted: boolean;
            key?: string;
            label?: string;
            componentId?: string;
          }>;
          checkpoint('native-action-proof', nativeEvents);
          expect(
            nativeEvents.filter(
              (event) =>
                event.type === 'click' && event.trusted && event.label === 'Повернуть на 45° (R)',
            ),
          ).toHaveLength(6);
          expect(
            instrumentIds.every((id) =>
              nativeEvents.some(
                (event) =>
                  event.type === 'keydown' &&
                  event.trusted &&
                  event.key === 'Enter' &&
                  event.componentId === id,
              ),
            ),
          ).toBe(true);
          expect(
            nativeEvents.some(
              (event) =>
                event.type === 'pointerup' && event.trusted && event.label === 'Сохранить проект',
            ),
          ).toBe(true);
          await page.screenshot({ path: info.outputPath('instrument525-final.png') });
          await reopened.screenshot({ path: info.outputPath('instrument525-reopened.png') });
          checkpoint('browser-failures', {
            original: failures.counts,
            reopened: reopenedFailures.counts,
          });
          failures.assertEmpty();
          reopenedFailures.assertEmpty();
          acknowledge('reopened-context-close-before', { puts: puts.length });
          await reopenedContext.close();
          acknowledge('reopened-context-close-after', { puts: puts.length });
          reopenedContext = undefined;
          for (const row of measured)
            for (const reading of row.readings)
              orientation.push({
                label: `${row.id}/${row.rotation}/${row.state}/${mirror.name}`,
                axesError: reading.axesError,
                centerError: reading.centerError,
                windowAxesError: reading.windowAxesError,
                windowMatrixError: reading.windowMatrixError,
                windowPositionError: reading.windowPositionError,
              });
        } catch (error) {
          journal['primaryError'] =
            error instanceof Error
              ? { name: error.name, message: error.message, stack: error.stack }
              : String(error);
          write();
          throw error;
        } finally {
          try {
            journal['nativeEvents'] = await page.evaluate(
              () =>
                (window as unknown as { instrument525Events?: unknown[] }).instrument525Events ??
                [],
            );
          } catch (error) {
            journal['nativeEventHarvestError'] = String(error);
          }
          await Promise.allSettled([...pendingResponses]);
          acknowledge('failure-or-success-observer-drain', {
            pending: pendingResponses.size,
            ledgerErrors,
          });
          write();
          for (const target of [reopenedContext, context]) {
            if (!target) continue;
            try {
              acknowledge('context-close-before', {
                original: target === context,
                puts: puts.length,
              });
              await target.close();
              acknowledge('context-close-after', {
                original: target === context,
                puts: puts.length,
              });
            } catch (error) {
              rows.push({ name: 'cleanup-error', error: String(error) });
              write();
              if (!journal['primaryError']) cleanupError ??= error;
            }
          }
        }
        await settleLedger();
        acknowledge('both-contexts-closed', { puts: puts.length, finalPutCount, revision });
        expect(finalPutCount).toBeDefined();
        expect(puts).toHaveLength(finalPutCount!);
        if (cleanupError) throw cleanupError;
        journal['journeyComplete'] = true;
        checkpoint('complete');
        for (const reading of orientation) {
          expect
            .soft(reading.windowAxesError, `${reading.label} window R*M`)
            .toBeLessThan(0.000001);
          expect.soft(reading.axesError, `${reading.label} glyph R`).toBeLessThan(0.000001);
          expect
            .soft(reading.windowMatrixError, `${reading.label} declared window affine axes/scale`)
            .toBeLessThan(0.000001);
          expect
            .soft(reading.windowPositionError, `${reading.label} declared window placement`)
            .toBeLessThan(0.1);
          expect.soft(reading.centerError, `${reading.label} own window center`).toBeLessThan(0.1);
        }
      });
    }
  }
});

test('saving indicator: pending local copy is distinct from actual save and acknowledgement', async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Truthful saving indicator');
  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: true, resistorOhms: 220, reversedLed: false }),
  );
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  const indicator = page.locator('.workbench-save-state');
  const paintedIndicator = async () => {
    const paint = await indicator.evaluate((element) => {
      const ancestors: Array<{
        tag: string;
        opacity: number;
        visibility: string;
        display: string;
      }> = [];
      for (let current: Element | null = element; current; current = current.parentElement) {
        const style = getComputedStyle(current);
        ancestors.push({
          tag: current.tagName,
          opacity: Number(style.opacity),
          visibility: style.visibility,
          display: style.display,
        });
      }
      const box = element.getBoundingClientRect();
      return {
        ancestors,
        effectiveOpacity: ancestors.reduce((value, ancestor) => value * ancestor.opacity, 1),
        width: box.width,
        height: box.height,
      };
    });
    expect(paint.width).toBeGreaterThan(0);
    expect(paint.height).toBeGreaterThan(0);
    expect(paint.effectiveOpacity).toBe(1);
    for (const ancestor of paint.ancestors) {
      expect(ancestor.display).not.toBe('none');
      expect(ancestor.visibility).toBe('visible');
    }
    return paint;
  };
  const timeline: unknown[] = [];
  const layouts: unknown[] = [];
  const evidenceDir = `${ARTIFACT_DIR}/save-indicator`;
  mkdirSync(evidenceDir, { recursive: true });
  let puts = 0;
  let release: (() => void) | undefined;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  page.on('request', (request) => {
    if (
      request.method() === 'PUT' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
    ) {
      puts += 1;
      timeline.push({ event: 'PUT', at: Date.now(), document: request.postDataJSON() });
    }
  });
  await page.route(`**/api/projects/${projectId}/draft`, async (route) => {
    if (route.request().method() !== 'PUT') return route.continue();
    const response = await route.fetch();
    timeline.push({ event: 'server_response_held', at: Date.now(), status: response.status() });
    await held;
    await route.fulfill({ response });
  });
  try {
    const value = await e01Resistance(page);
    await value.fill('330');
    await expect(page.locator('.workbench-main')).toHaveAttribute(
      'data-project-save-status',
      'dirty',
    );
    await expect(indicator).toHaveAttribute('data-persistence-status', 'dirty');
    await expect(indicator).toHaveText('Ждёт отправки');
    await expect(indicator).toHaveAttribute(
      'title',
      'Последние изменения сохранены в этом браузере. Ожидается отправка на сервер.',
    );
    expect(puts).toBe(0);
    const local = await e01LocalDraft(page, projectId);
    expect(local).not.toBeNull();
    const stored = JSON.parse(local!) as { document: SchematicDocument };
    expect(stored.document.components.find((entry) => entry.kind === 'resistor')?.value).toBe(330);
    timeline.push({
      event: 'dirty_local_readback_no_PUT',
      at: Date.now(),
      puts,
      label: await indicator.textContent(),
      local: stored,
    });
    for (const width of [1440, 1024, 390, 320]) {
      await page.setViewportSize({ width, height: 900 });
      await expect(indicator).toBeVisible();
      const paint = await paintedIndicator();
      const layout = await indicator.evaluate((element) => {
        const bounds = element.getBoundingClientRect();
        const text = document.createRange();
        text.selectNodeContents(element);
        const caption = text.getBoundingClientRect();
        const style = getComputedStyle(element);
        return {
          width: innerWidth,
          pageWidth: document.documentElement.scrollWidth,
          left: bounds.left,
          right: bounds.right,
          textLeft: caption.left,
          textRight: caption.right,
          contentLeft: bounds.left + parseFloat(style.paddingLeft),
          contentRight: bounds.right - parseFloat(style.paddingRight),
        };
      });
      layouts.push({ ...layout, paint });
      expect(layout.pageWidth).toBeLessThanOrEqual(width);
      expect(layout.left).toBeGreaterThanOrEqual(0);
      expect(layout.right).toBeLessThanOrEqual(width);
      expect(layout.textLeft).toBeGreaterThanOrEqual(layout.contentLeft - 1);
      expect(layout.textRight).toBeLessThanOrEqual(layout.contentRight + 1);
      if (width === 1440 || width === 390)
        await page.screenshot({ path: `${evidenceDir}/pending-${width}.png`, fullPage: true });
    }
    expect(puts).toBe(0);
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
    await expect.poll(() => puts).toBe(1);
    await expect(indicator).toHaveAttribute('data-persistence-status', 'saving');
    await expect(indicator).toHaveText('Сохраняем…');
    const savingPaint = await paintedIndicator();
    timeline.push({
      event: 'actual_request_saving',
      at: Date.now(),
      puts,
      label: await indicator.textContent(),
      paint: savingPaint,
    });
    release!();
    await expect(page.locator('.workbench-main')).toHaveAttribute(
      'data-project-save-status',
      'saved',
    );
    await expect(indicator).toHaveAttribute('data-persistence-status', 'saved');
    await expect(indicator).toHaveText('✓Сохранено');
    const savedPaint = await paintedIndicator();
    await page.screenshot({ path: `${evidenceDir}/acknowledged-1440.png`, fullPage: true });
    timeline.push({
      event: 'acknowledged_saved',
      at: Date.now(),
      puts,
      label: await indicator.textContent(),
      paint: savedPaint,
    });
    expect(puts).toBe(1);
    const response = await page.context().request.get(`/api/projects/${projectId}`);
    expect(response.status()).toBe(200);
    const server = (await response.json()) as { draft: { document: SchematicDocument } };
    expect(server.draft.document.components.find((entry) => entry.kind === 'resistor')?.value).toBe(
      330,
    );
  } finally {
    release?.();
    writeFileSync(
      `${evidenceDir}/timeline.json`,
      JSON.stringify({ projectId, puts, timeline, layouts }, null, 2),
    );
  }
});

test('simulation fault semantics: unpowered supported circuit stays distinct from Worker failure', async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Simulation circuit state classification');
  await saveDocument(page, projectId, multimeterResistanceDocument(false));
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'running',
  );
  await expect(page.locator('.workbench-simulation-message')).toHaveAttribute(
    'data-simulation-category',
    'circuit-state',
  );
  await expect(page.locator('.workbench-simulation-message')).toHaveAttribute(
    'data-simulation-code',
    'no_source',
  );
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await expect(page.locator('.workbench-simulation-message')).toHaveCount(0);
});

test('simulation fault semantics: an unmodelled part stops without a false solved frame', async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Simulation unsupported classification');
  const base = circuitDocument({ switchClosed: true, resistorOhms: 330, reversedLed: false });
  await saveDocument(page, projectId, {
    ...base,
    components: [
      ...base.components,
      {
        id: 'unmodelled',
        kind: 'visual',
        componentTypeId: 'test-unmodelled-part',
        variantId: 'test-unmodelled-part',
        position: { x: 960, y: 250 },
        value: 0,
        pinIds: ['a', 'b'],
      },
    ],
  });
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  await expect(page.locator('.workbench-simulation-message')).toHaveAttribute(
    'data-simulation-category',
    'unsupported',
  );
  await expect(page.locator('.workbench-simulation-message')).toHaveAttribute(
    'data-simulation-code',
    'unsupported_component',
  );
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'stopped',
  );
  await expect(page.locator('.workbench-simulation-time')).toHaveCount(0);
  const saved = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin: new URL(page.url()).origin },
  });
  expect(saved.status()).toBe(200);
  expect(
    (
      (await saved.json()) as { draft: { document: SchematicDocument } }
    ).draft.document.components.map((entry) => entry.id),
  ).toContain('unmodelled');
});

test('simulation fault semantics: technical Worker error stops, then current document restarts', async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Simulation technical restart');
  await saveDocument(
    page,
    projectId,
    circuitDocument({
      switchClosed: true,
      resistorOhms: 330,
      reversedLed: false,
    }),
  );
  await page.addInitScript(() => {
    const NativeWorker = window.Worker;
    let failFirstPreflight = true;
    let firstWorker: Worker | null = null;
    Object.assign(window, {
      __dispatchOldSimulationReply: () => {
        firstWorker?.dispatchEvent(
          new MessageEvent('message', {
            data: { ok: false, requestId: 'old-generation', code: 'internal', message: 'stale' },
          }),
        );
      },
    });
    window.Worker = new Proxy(NativeWorker, {
      construct(target, args, newTarget) {
        const worker = Reflect.construct(target, args, newTarget) as Worker;
        if ((args[1] as WorkerOptions | undefined)?.name !== 'asa-electronics-simulation')
          return worker;
        const originalPost = worker.postMessage.bind(worker);
        worker.postMessage = ((message: { kind?: string }) => {
          if (failFirstPreflight && message.kind === 'preflight') {
            failFirstPreflight = false;
            firstWorker = worker;
            throw new Error('Injected Worker transport fault');
          }
          originalPost(message);
        }) as Worker['postMessage'];
        return worker;
      },
    });
  });
  await page.reload();
  expect(
    await page.evaluate(
      () =>
        typeof (window as Window & { __dispatchOldSimulationReply?: () => void })
          .__dispatchOldSimulationReply,
    ),
  ).toBe('function');
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await component(page, 'resistor-axial').locator('.workbench-part').click({ force: true });
  const unsavedName = page.getByLabel('Имя', { exact: true });
  await unsavedName.fill('R1 несохранённый');
  await expect(unsavedName).toHaveValue('R1 несохранённый');
  await expect(page.locator('.workbench-main')).not.toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const componentIds = await page
    .locator('[data-testid="schematic-component"]')
    .evaluateAll((entries) => entries.map((entry) => entry.getAttribute('data-component-id')));
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  await expect(page.locator('.workbench-simulation-message')).toHaveAttribute(
    'data-simulation-category',
    'technical',
  );
  await expect(page.locator('.workbench-simulation-message')).toHaveAttribute(
    'data-simulation-code',
    'worker-post',
  );
  await expect(page.locator('.workbench-simulation-message')).toContainText(
    'Не удалось отправить запрос вычислительному модулю. Запустите моделирование снова.',
  );
  await expect(page.locator('.workbench-simulation-message')).not.toContainText(
    'Injected Worker transport fault',
  );
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'stopped',
  );
  await expect(page.getByRole('button', { name: 'Начать моделирование' })).toBeVisible();
  await expect(unsavedName).toHaveValue('R1 несохранённый');
  expect(
    await page
      .locator('[data-testid="schematic-component"]')
      .evaluateAll((entries) => entries.map((entry) => entry.getAttribute('data-component-id'))),
  ).toEqual(componentIds);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.locator('.workbench-simulation-message')).toHaveCount(0);
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'running',
  );
  await expect(unsavedName).toHaveValue('R1 несохранённый');
  await page.evaluate(() =>
    (
      window as Window & { __dispatchOldSimulationReply?: () => void }
    ).__dispatchOldSimulationReply?.(),
  );
  await expect(page.locator('.workbench-pill.simulate')).toHaveAttribute(
    'data-simulation-status',
    'running',
  );
  expect(
    await page
      .locator('[data-testid="schematic-component"]')
      .evaluateAll((entries) => entries.map((entry) => entry.getAttribute('data-component-id'))),
  ).toEqual(componentIds);
});

test.afterEach(async ({ page }) => {
  // Every Playwright test gets an isolated browser context. End its server
  // session as well, otherwise the eleventh journey reaches the account's
  // active-session limit even though the ten earlier browser contexts are
  // already gone.
  const origin = new URL(page.url()).origin;
  await page.context().request.post('/api/auth/logout', { headers: { origin } });
});

// Each segment keeps the original default test budget and owns a complete real
// project/intent receipt. Splitting viewport observations does not change limits.
const compactControlSegments = [
  { mode: 'text', segment: 'desktop-wide', widths: [1440, 1374, 1373] },
  { mode: 'text', segment: 'desktop-compact', widths: [1181, 1180, 1024, 981] },
  { mode: 'text', segment: 'mobile', widths: [980, 390, 320] },
  {
    mode: 'blocks-text',
    segment: 'all-widths',
    widths: [1440, 1374, 1373, 1181, 1180, 1024, 981, 980, 390, 320],
  },
  {
    mode: 'blocks',
    segment: 'all-widths',
    widths: [1440, 1374, 1373, 1181, 1180, 1024, 981, 980, 390, 320],
  },
] as const;
for (const { mode, segment, widths } of compactControlSegments) {
  test(`compact controls retain full desktop captions and usable Code controls at actual drawer sizes — ${mode} — ${segment}`, async ({
    page,
  }, testInfo) => {
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    // Each registered segment owns its real saved project and Playwright output directory.
    const evidenceDir = testInfo.outputPath(
      'electronics-compact-controls-532',
      `${mode}-${segment}`,
    );
    mkdirSync(evidenceDir, { recursive: true });
    const observations: unknown[] = [];
    const blockSource =
      '// C++ code generated by ASA Lab\n// Arduino Uno R3\n\nvoid setup()\n{\n\n}\n\nvoid loop()\n{\n\n}\n';
    const workspace = JSON.stringify({
      blocks: {
        languageVersion: 0,
        blocks: [
          { type: 'asa_setup', id: 'setup-532', x: 400, y: 120 },
          { type: 'asa_loop', id: 'loop-532', x: 400, y: 280 },
        ],
      },
    });
    const baseFixture = arduinoInputDocument('button', '2');
    // These are the actual catalog defaults already proved by #533 receipts.
    // Save canonical fixture state before observing, rather than accepting a
    // load-induced default/Blockly-position publication as a layout change.
    const textFixture = {
      ...baseFixture,
      components: baseFixture.components.map((item) =>
        item.id === 'resistor'
          ? { ...item, stateProperties: { ...item.stateProperties, powerRatingWatt: 0.25 } }
          : item.id === 'button-0'
            ? { ...item, stateProperties: { ...item.stateProperties, contactState: 'released' } }
            : item,
      ),
    };
    const fixture =
      mode === 'text'
        ? textFixture
        : {
            ...textFixture,
            components: textFixture.components.map((item) =>
              item.id === 'uno'
                ? {
                    ...item,
                    stateProperties: {
                      ...item.stateProperties,
                      arduinoCodeMode: mode,
                      arduinoSource: blockSource,
                      arduinoWorkspace: workspace,
                      arduinoSerialOpen: false,
                      arduinoBaudRate: 9600,
                    },
                  }
                : item,
            ),
          };
    await page.setViewportSize({ width: 1440, height: 900 });
    await loginWithOrganization(page, teacher);
    const projectId = await createProject(
      page,
      `Compact controls preserve pupil intent ${mode} ${segment}`,
    );
    await saveDocument(page, projectId, fixture);
    const draftBefore = await page.context().request.get(`/api/projects/${projectId}`);
    expect(draftBefore.status()).toBe(200);
    const before = (await draftBefore.json()) as {
      draft: { document: SchematicDocument; revision: number };
    };
    // The API adds canonical electrical-model identity fields to saved components.
    // Check fixture intent here; retain the full normalized server snapshot below.
    expect(before.draft.document.connections).toEqual(fixture.connections);
    expect(before.draft.document.components.map((item) => item.id)).toEqual(
      fixture.components.map((item) => item.id),
    );
    expect(
      before.draft.document.components.find((item) => item.id === 'uno')?.stateProperties,
    ).toEqual(fixture.components.find((item) => item.id === 'uno')?.stateProperties);
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();
    await page.locator('.workbench-pill.code').click();
    const drawer = page.locator('.arduino-code-panel');
    await expect(drawer).toHaveCSS('transform', 'matrix(1, 0, 0, 1, 0, 0)');
    const run = page.locator('.workbench-pill.simulate');
    const font = page.getByRole('combobox', { name: 'Размер текста Arduino', exact: true });
    const editor = page.getByRole('textbox', { name: 'Код Arduino C++', exact: true });
    const source = String(
      fixture.components.find((item) => item.id === 'uno')?.stateProperties?.['arduinoSource'],
    );
    if (mode === 'text') {
      await expect(editor).toHaveValue(source);
    } else {
      const blockSvg = page
        .getByTestId('arduino-block-workspace')
        .locator(':scope > .injectionDiv > svg.blocklySvg');
      await expect(blockSvg).toBeVisible();
      await expect(blockSvg.locator('[data-id="setup-532"]')).toBeVisible();
      await expect(blockSvg.locator('[data-id="loop-532"]')).toBeVisible();
    }
    // Clean production load clears its dirty local draft. These raw before/after
    // receipts prove draft presence/absence; null is not a mounted document snapshot.
    const localBefore = await page.evaluate((id) => {
      const raw = localStorage.getItem(`asa-project-local-draft:${id}`);
      return raw ? (JSON.parse(raw) as { document: SchematicDocument }).document : null;
    }, projectId);

    async function record(
      phase: string,
      desktop: boolean,
      running: boolean,
      mode: 'text' | 'blocks-text' | 'blocks' = 'text',
      expectedSource = source,
    ) {
      const observation = await page.evaluate((phase) => {
        const bounds = (rect: DOMRect) => ({
          left: rect.left,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          width: rect.width,
          height: rect.height,
        });
        const nativeMenu = document.querySelector(
          '.workbench-wire-color[open] > .workbench-wire-color-menu[role="menu"][aria-label="Цвет провода"]',
        );
        function inspect(element: Element) {
          const rect = element.getBoundingClientRect();
          const style = getComputedStyle(element);
          const textRects: ReturnType<typeof bounds>[] = [];
          const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
          while (!(element instanceof HTMLSelectElement) && walker.nextNode()) {
            if (!walker.currentNode.textContent?.trim()) continue;
            const range = document.createRange();
            range.selectNodeContents(walker.currentNode);
            textRects.push(...Array.from(range.getClientRects(), bounds));
          }
          const clips = [];
          for (let parent = element.parentElement; parent; parent = parent.parentElement) {
            const css = getComputedStyle(parent);
            if (
              ['hidden', 'clip', 'auto', 'scroll'].includes(css.overflowX) ||
              ['hidden', 'clip', 'auto', 'scroll'].includes(css.overflowY)
            ) {
              const box = parent.getBoundingClientRect();
              clips.push({
                selector: `${parent.tagName}.${parent.className}`,
                overflowX: css.overflowX,
                overflowY: css.overflowY,
                left: box.left + parent.clientLeft,
                top: box.top + parent.clientTop,
                right: box.left + parent.clientLeft + parent.clientWidth,
                bottom: box.top + parent.clientTop + parent.clientHeight,
              });
            }
          }
          const points = [
            [rect.left + 3, rect.top + 3],
            [rect.right - 3, rect.top + 3],
            [rect.left + 3, rect.bottom - 3],
            [rect.right - 3, rect.bottom - 3],
            [rect.left + rect.width / 2, rect.top + rect.height / 2],
          ].map(([x, y]) => {
            const hit = document.elementFromPoint(x!, y!);
            const hitAncestry = [];
            for (let ancestor = hit; ancestor; ancestor = ancestor.parentElement) {
              hitAncestry.push({
                selector: `${ancestor.tagName}.${ancestor.className}`,
                role: ancestor.getAttribute('role'),
                ariaLabel: ancestor.getAttribute('aria-label'),
              });
            }
            return {
              x,
              y,
              owned: hit !== null && (hit === element || element.contains(hit)),
              hit: hit ? `${hit.tagName}.${hit.className}` : null,
              hitAncestry,
              ownedByOpenNativeMenu:
                nativeMenu !== null &&
                hit !== null &&
                hit.closest('.workbench-wire-color-menu') === nativeMenu,
            };
          });
          const selectedText =
            element instanceof HTMLSelectElement
              ? (element.selectedOptions[0]?.textContent ?? '')
              : null;
          const context = document.createElement('canvas').getContext('2d')!;
          context.font = style.font;
          return {
            selector: `${element.tagName}.${element.className}`,
            text: element.textContent?.trim(),
            ariaLabel: element.getAttribute('aria-label'),
            rect: bounds(rect),
            fontSize: style.fontSize,
            disabled: element instanceof HTMLButtonElement && element.disabled,
            iconRects: Array.from(element.querySelectorAll(':scope > svg'), (icon) =>
              bounds(icon.getBoundingClientRect()),
            ),
            textRects,
            clips,
            points,
            selectedText,
            selectedTextWidth:
              selectedText === null ? null : context.measureText(selectedText).width,
            contentWidth:
              element.clientWidth -
              Number.parseFloat(style.paddingLeft) -
              Number.parseFloat(style.paddingRight),
          };
        }
        const primary = document.querySelector('.workbench-pill.simulate')!;
        const panel = document.querySelector('.arduino-code-panel')!;
        const toolbar = document.querySelector('.workbench-toolbar')!;
        const codeToolbar = document.querySelector('.arduino-code-toolbar')!;
        return {
          phase,
          view: toolbar.className,
          viewport: {
            width: innerWidth,
            height: innerHeight,
            pageWidth: document.documentElement.scrollWidth,
            clientWidth: document.documentElement.clientWidth,
          },
          primary: inspect(primary),
          headerGroups: Array.from(
            toolbar.querySelectorAll('.workbench-toolbar-group'),
            (group) => {
              const style = getComputedStyle(group);
              return {
                selector: `${group.tagName}.${group.className}`,
                rect: bounds(group.getBoundingClientRect()),
                paddingLeft: style.paddingLeft,
                paddingRight: style.paddingRight,
                gap: style.gap,
              };
            },
          ),
          headerControls: Array.from(
            toolbar.querySelectorAll(
              '.workbench-toolbar-group > button, .workbench-toolbar-group > strong, .workbench-toolbar-group > details > summary',
            ),
          )
            .filter((control) => {
              const rect = control.getBoundingClientRect();
              return (
                rect.width > 0 &&
                rect.height > 0 &&
                getComputedStyle(control).visibility === 'visible'
              );
            })
            .map(inspect),
          fixtureBlockIds: Array.from(
            document.querySelectorAll(
              '[data-testid="arduino-block-workspace"] .injectionDiv > svg.blocklySvg [data-id="setup-532"], [data-testid="arduino-block-workspace"] .injectionDiv > svg.blocklySvg [data-id="loop-532"]',
            ),
            (block) => block.getAttribute('data-id'),
          ).sort(),
          codeControls: Array.from(
            codeToolbar.querySelectorAll(
              ':scope > details > summary, :scope > button, :scope > select, .arduino-font-size-select > select',
            ),
            inspect,
          ),
          clock: document.querySelector('.workbench-simulation-time')
            ? inspect(document.querySelector('.workbench-simulation-time')!)
            : null,
          toolbar: bounds(toolbar.getBoundingClientRect()),
          main: bounds(document.querySelector('.workbench-main')!.getBoundingClientRect()),
          drawer: bounds(panel.getBoundingClientRect()),
          codeToolbar: bounds(codeToolbar.getBoundingClientRect()),
          nativeWireMenu: document.querySelector('.workbench-wire-color-menu')
            ? {
                open: document.querySelector('.workbench-wire-color')!.hasAttribute('open'),
                toolbarZIndex: getComputedStyle(toolbar).zIndex,
                rect: bounds(
                  document.querySelector('.workbench-wire-color-menu')!.getBoundingClientRect(),
                ),
                purple: inspect(document.querySelector('[aria-label="Цвет провода: Фиолетовый"]')!),
              }
            : null,
          codeBody: bounds(document.querySelector('.arduino-code-body')!.getBoundingClientRect()),
          source:
            document.querySelector<HTMLTextAreaElement>(
              '[aria-label="Код Arduino C++"], [aria-label="Сгенерированный код Arduino"]',
            )?.value ?? null,
          codeMode: codeToolbar.className,
          componentCount: document.querySelectorAll('[data-testid="schematic-component"]').length,
        };
      }, phase);
      observations.push(observation);
      writeFileSync(
        resolve(evidenceDir, 'geometry.json'),
        JSON.stringify(observations, null, 2),
        'utf8',
      );
      await page.screenshot({ path: resolve(evidenceDir, `${phase}.png`) });
      expect(observation.viewport.pageWidth).toBeLessThanOrEqual(observation.viewport.clientWidth);
      expect(observation.source).toBe(mode === 'blocks' ? null : expectedSource);
      expect(observation.codeMode).toContain(`mode-${mode}`);
      expect(observation.componentCount).toBe(
        observation.view.includes('breadboard') ? fixture.components.length : 0,
      );
      expect(observation.main.top).toBeGreaterThanOrEqual(observation.toolbar.bottom - 1);
      expect(observation.drawer.top).toBeGreaterThanOrEqual(observation.toolbar.bottom - 1);
      expect(observation.codeBody.top).toBeGreaterThanOrEqual(observation.codeToolbar.bottom - 1);
      expect(observation.codeBody.height).toBeGreaterThan(0);
      const caption = running ? 'Остановить моделирование' : 'Начать моделирование';
      expect(observation.primary.ariaLabel).toBe(caption);
      expect(observation.primary.text).toBe(caption);
      function assertFits(control: typeof observation.primary, allowNativeMenuCorners = false) {
        expect(control.rect.left).toBeGreaterThanOrEqual(0);
        expect(control.rect.right).toBeLessThanOrEqual(observation.viewport.width + 1);
        expect(control.rect.top).toBeGreaterThanOrEqual(0);
        expect(control.rect.bottom).toBeLessThanOrEqual(observation.viewport.height + 1);
        expect(
          control.points.every((point, index) => {
            if (point.owned) return true;
            const menu = observation.nativeWireMenu;
            // An open popup owns its actual pixels. Only underlying Code corners
            // may belong to this concrete native menu; the centre stays usable.
            return (
              allowNativeMenuCorners &&
              phase === '981-native-open' &&
              observation.viewport.width === 981 &&
              menu?.open === true &&
              index < 4 &&
              point.ownedByOpenNativeMenu &&
              point.x! >= menu.rect.left &&
              point.x! <= menu.rect.right &&
              point.y! >= menu.rect.top &&
              point.y! <= menu.rect.bottom
            );
          }),
        ).toBe(true);
        for (const clip of control.clips) {
          if (['hidden', 'clip', 'auto', 'scroll'].includes(clip.overflowX)) {
            expect(control.rect.left).toBeGreaterThanOrEqual(clip.left - 1);
            expect(control.rect.right).toBeLessThanOrEqual(clip.right + 1);
          }
          if (['hidden', 'clip', 'auto', 'scroll'].includes(clip.overflowY)) {
            expect(control.rect.top).toBeGreaterThanOrEqual(clip.top - 1);
            expect(control.rect.bottom).toBeLessThanOrEqual(clip.bottom + 1);
          }
        }
        for (const text of control.textRects) {
          expect(text.left).toBeGreaterThanOrEqual(control.rect.left - 1);
          expect(text.right).toBeLessThanOrEqual(control.rect.right + 1);
          expect(text.top).toBeGreaterThanOrEqual(control.rect.top - 1);
          expect(text.bottom).toBeLessThanOrEqual(control.rect.bottom + 1);
        }
      }
      assertFits(observation.primary);
      if ([1180, 1181, 1373, 1374].includes(observation.viewport.width)) {
        expect(observation.toolbar.height).toBe(48);
        expect(observation.headerGroups).toHaveLength(2);
        for (const group of observation.headerGroups) {
          expect(group.rect.left).toBeGreaterThanOrEqual(0);
          expect(group.rect.right).toBeLessThanOrEqual(observation.viewport.width + 1);
          expect(group.rect.top).toBeGreaterThanOrEqual(observation.toolbar.top);
          expect(group.rect.bottom).toBeLessThanOrEqual(observation.toolbar.bottom);
        }
        expect(observation.headerControls).toHaveLength(
          observation.view.includes('breadboard')
            ? 16
            : observation.view.includes('schematic')
              ? 8
              : 6,
        );
        if (observation.view.includes('breadboard')) {
          expect(
            observation.headerControls.filter(
              (control) => control.ariaLabel === 'Добавить текст на схему',
            ),
          ).toHaveLength(1);
        }
        for (const control of observation.headerControls) {
          assertFits(control);
          expect(control.rect.width).toBeGreaterThan(0);
          expect(control.rect.height).toBeGreaterThan(0);
          for (const icon of control.iconRects) {
            expect(icon.left).toBeGreaterThanOrEqual(control.rect.left - 1);
            expect(icon.right).toBeLessThanOrEqual(control.rect.right + 1);
            expect(icon.top).toBeGreaterThanOrEqual(control.rect.top - 1);
            expect(icon.bottom).toBeLessThanOrEqual(control.rect.bottom + 1);
          }
        }
        if (running) {
          expect(observation.view).toContain('breadboard');
          expect(observation.clock!.text).toMatch(/^Время моделирования: \d{2}:\d{2}:\d{2}$/);
          expect(observation.clock!.textRects.some((rect) => rect.width > 0)).toBe(true);
        }
      }
      if (mode !== 'text') expect(observation.fixtureBlockIds).toEqual(['loop-532', 'setup-532']);
      if (desktop) {
        expect(Number.parseFloat(observation.primary.fontSize)).toBeGreaterThan(0);
        expect(observation.primary.textRects.some((rect) => rect.width > 0)).toBe(true);
        if (running) {
          expect(observation.clock).not.toBeNull();
          assertFits(observation.clock!);
          expect(observation.clock!.rect.right).toBeLessThanOrEqual(observation.primary.rect.left);
        }
      } else {
        // Preserve existing mobile icon presentation; full accessible caption is checked above.
        expect(observation.primary.fontSize).toBe('0px');
      }
      expect(observation.codeControls).toHaveLength(
        mode === 'text' ? 7 : mode === 'blocks-text' ? 6 : 3,
      );
      if (phase === '981-native-open') {
        expect(observation.nativeWireMenu?.open).toBe(true);
        const purple = observation.nativeWireMenu!.purple;
        assertFits(purple);
        expect(purple.points.every((point) => point.ownedByOpenNativeMenu)).toBe(true);
      }
      for (const control of observation.codeControls) assertFits(control, true);
      if (mode !== 'blocks') {
        const fontControl = observation.codeControls.find(
          (control) => control.ariaLabel === 'Размер текста Arduino',
        )!;
        expect(fontControl.selectedTextWidth).toBeLessThanOrEqual(fontControl.contentWidth);
      }
    }

    if (mode === 'text') {
      for (const width of widths) {
        const desktop = width > 980;
        await page.setViewportSize({ width, height: 900 });
        await record(`${width}-stopped`, desktop, false);
        if (width === 981) {
          const nativeMenu = page.locator('.workbench-wire-color');
          await nativeMenu.locator('summary').click();
          await expect(nativeMenu).toHaveAttribute('open', '');
          await record(`${width}-native-open`, desktop, false);
          await nativeMenu.locator('summary').click();
          await expect(nativeMenu).not.toHaveAttribute('open', '');
          await record(`${width}-native-closed`, desktop, false);
        }
        const size = (await font.inputValue()) === '14' ? '16' : '14';
        await font.click();
        await page.keyboard.press('Home');
        for (let step = 0; step < (size === '16' ? 4 : 2); step++) {
          await page.keyboard.press('ArrowDown');
        }
        await page.keyboard.press('Enter');
        await expect(font).toHaveValue(size);
        await expect(page.locator('.arduino-source-editor')).toHaveCSS('font-size', `${size}px`);
        await run.click();
        await expect(run).toHaveAttribute('aria-pressed', 'true');
        await expect(run).toHaveAttribute('data-simulation-status', 'running');
        await record(`${width}-running`, desktop, true);
        await run.click();
        await expect(run).toHaveAttribute('aria-pressed', 'false');

        const handle = page.getByRole('separator', {
          name: desktop ? 'Изменить ширину редактора кода' : 'Изменить высоту редактора кода',
          exact: true,
        });
        const beforeBox = await drawer.boundingBox();
        const handleBox = await handle.boundingBox();
        if (!beforeBox || !handleBox) throw new Error('Code drawer resize geometry is missing');
        const maximum = Math.max(460, width - 420);
        const minimum = Math.min(620, maximum);
        // Ordinary drag changes width whenever the canonical interval has room.
        // At the minimum, drag outward instead of pretending a clamped input failed.
        const horizontalDelta = beforeBox.width - minimum > 16 ? 32 : -32;
        const x = handleBox.x + handleBox.width / 2;
        const y = handleBox.y + handleBox.height / 2;
        await page.mouse.move(x, y);
        await page.mouse.down();
        await page.mouse.move(x + (desktop ? horizontalDelta : 0), y - (desktop ? 0 : 32), {
          steps: 4,
        });
        await page.mouse.up();
        await expect
          .poll(async () => {
            const afterBox = await drawer.boundingBox();
            if (!afterBox) return false;
            return desktop
              ? maximum > minimum
                ? horizontalDelta > 0
                  ? afterBox.width < beforeBox.width - 16
                  : afterBox.width > beforeBox.width + 16
                : Math.abs(afterBox.width - beforeBox.width) <= 1
              : afterBox.height > beforeBox.height + 16;
          })
          .toBe(true);
        await record(`${width}-resized`, desktop, false);
        if (desktop) {
          const actualWidth = (await drawer.boundingBox())!.width;
          if (maximum === minimum) {
            // The existing drawer minimum meets its viewport-minus-420px maximum.
            // Ordinary input is clamped at these widths, not a missing interaction.
            expect(actualWidth).toBe(width - 420);
          }
          expect(
            Math.abs(actualWidth - Number(await handle.getAttribute('aria-valuenow'))),
          ).toBeLessThanOrEqual(1);
          for (const view of ['Схемы', 'Компоненты', 'Цепи']) {
            await page.getByRole('button', { name: view, exact: true }).click();
            await record(`${width}-${view}`, desktop, false);
          }
        }
      }
      const draftAfter = await page.context().request.get(`/api/projects/${projectId}`);
      expect(draftAfter.status()).toBe(200);
      const after = (await draftAfter.json()) as typeof before;
      const localAfter = await page.evaluate((id) => {
        const raw = localStorage.getItem(`asa-project-local-draft:${id}`);
        return raw ? (JSON.parse(raw) as { document: SchematicDocument }).document : null;
      }, projectId);
      writeFileSync(
        resolve(evidenceDir, 'intent.json'),
        JSON.stringify(
          { mode, segment, widths, projectId, before, after, localBefore, localAfter },
          null,
          2,
        ),
        'utf8',
      );
      expect(after.draft.document).toEqual(before.draft.document);
      expect(after.draft.revision).toBe(before.draft.revision);
      await expect(editor).toHaveValue(source);

      expect(localAfter).toEqual(localBefore);
      if (localAfter) {
        expect(localAfter.connections).toEqual(fixture.connections);
        expect(
          localAfter.components.find((item) => item.id === 'uno')?.stateProperties?.[
            'arduinoSource'
          ],
        ).toBe(source);
      }
    } else {
      for (const width of [1440, 1374, 1373, 1181, 1180, 1024, 981, 980, 390, 320]) {
        await page.setViewportSize({ width, height: 900 });
        await record(`${width}-${mode}`, width > 980, false, mode, blockSource);
        if ([1180, 1181, 1373, 1374].includes(width)) {
          await run.click();
          await expect(run).toHaveAttribute('aria-pressed', 'true');
          await expect(run).toHaveAttribute('data-simulation-status', 'running');
          await record(`${width}-${mode}-running`, true, true, mode, blockSource);
          await run.click();
          await expect(run).toHaveAttribute('aria-pressed', 'false');
        }
        if ([1440, 1180, 1181, 1373, 1374].includes(width)) {
          const widthHandle = page.getByRole('separator', {
            name: 'Изменить ширину редактора кода',
            exact: true,
          });
          const start = (await widthHandle.boundingBox())!;
          const initialWidth = (await drawer.boundingBox())!.width;
          const maximum = Math.max(460, width - 420);
          const minimum = Math.min(620, maximum);
          const grow = width === 1440 || initialWidth - minimum <= 16;
          const delta = grow ? -24 : 24;
          await page.mouse.move(start.x + start.width / 2, start.y + start.height / 2);
          await page.mouse.down();
          await page.mouse.move(start.x + start.width / 2 + delta, start.y + start.height / 2, {
            steps: 4,
          });
          await page.mouse.up();
          await record(`${width}-${mode}-resized`, true, false, mode, blockSource);
          if (grow) {
            expect((await drawer.boundingBox())!.width).toBeGreaterThan(initialWidth + 16);
          } else {
            expect((await drawer.boundingBox())!.width).toBeLessThan(initialWidth - 16);
          }
          expect(
            Math.abs(
              (await drawer.boundingBox())!.width -
                Number(await widthHandle.getAttribute('aria-valuenow')),
            ),
          ).toBeLessThanOrEqual(1);
          if (mode === 'blocks-text') {
            await font.click();
            const size = [1181, 1374].includes(width) ? '14' : '20';
            if (size === '14') {
              await page.keyboard.press('Home');
              await page.keyboard.press('ArrowDown');
              await page.keyboard.press('ArrowDown');
            } else {
              await page.keyboard.press('End');
            }
            await page.keyboard.press('Enter');
            await expect(font).toHaveValue(size);
            await expect(page.locator('.arduino-source-editor')).toHaveCSS(
              'font-size',
              `${size}px`,
            );
            await record(`${width}-${mode}-font`, true, false, mode, blockSource);
          }
        }
      }
      const response = await page.context().request.get(`/api/projects/${projectId}`);
      expect(response.status()).toBe(200);
      const modeAfter = (await response.json()) as typeof before;
      const local = await page.evaluate((id) => {
        const raw = localStorage.getItem(`asa-project-local-draft:${id}`);
        return raw ? (JSON.parse(raw) as { document: SchematicDocument }).document : null;
      }, projectId);
      writeFileSync(
        resolve(evidenceDir, `intent-${mode}.json`),
        JSON.stringify(
          {
            mode,
            segment,
            widths,
            projectId,
            before,
            after: modeAfter,
            localBefore,
            localAfter: local,
          },
          null,
          2,
        ),
        'utf8',
      );
      expect(modeAfter.draft.document).toEqual(before.draft.document);
      expect(modeAfter.draft.revision).toBe(before.draft.revision);
      expect(local).toEqual(localBefore);
      if (local) {
        expect(local.connections).toEqual(fixture.connections);
        expect(
          local.components.find((item) => item.id === 'uno')?.stateProperties?.['arduinoSource'],
        ).toBe(blockSource);
      }
    }
    failures.assertEmpty();
  });
}

for (const mode of ['blocks-text', 'blocks'] as const) {
  test(`Arduino Blockly media uses pinned local bytes from first initialization — ${mode}`, async ({
    page,
  }, testInfo) => {
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    const evidenceDir = testInfo.outputPath('electronics-blockly-media-533');
    mkdirSync(evidenceDir, { recursive: true });
    const mediaNames = ['sprites.png', 'zoom-in.svg', 'zoom-out.svg', 'zoom-reset.svg'];
    const expectedHashes = Object.fromEntries(
      mediaNames.map((name) => [
        name,
        createHash('sha256')
          .update(
            readFileSync(
              resolve(process.cwd(), 'apps/web/node_modules/scratch-blocks/media', name),
            ),
          )
          .digest('hex'),
      ]),
    );
    type Validators = { etag?: string; lastModified?: string; location?: string };
    type MediaResponse = {
      url: string;
      status: number;
      at: number;
      request: { ifNoneMatch?: string; ifModifiedSince?: string };
      validators: Validators;
      sha256?: string;
      verified200At?: number;
      bodyRead: boolean;
    };
    const requests: { url: string; at: number; ifNoneMatch?: string; ifModifiedSince?: string }[] =
      [];
    const responses: MediaResponse[] = [];
    const observerErrors: { url: string; at: number; error: string }[] = [];
    const verified200 = new Map<string, Promise<MediaResponse>>();
    const responseBodies: Promise<void>[] = [];
    const isMedia = (url: string) =>
      /blockly-demo\.appspot\.com/.test(url) ||
      /\/(?:sprites\.png|zoom-(?:in|out|reset)\.svg)(?:[?#]|$)/.test(url);
    // Install before navigation: the Code panel can pre-mount while still hidden.
    page.on('request', (request) => {
      if (!isMedia(request.url())) return;
      requests.push({
        url: request.url(),
        at: Date.now(),
        ifNoneMatch: request.headers()['if-none-match'],
        ifModifiedSince: request.headers()['if-modified-since'],
      });
    });
    page.on('response', (response) => {
      if (!isMedia(response.url())) return;
      const entry: MediaResponse = {
        url: response.url(),
        status: response.status(),
        at: Date.now(),
        request: {},
        validators: {},
        bodyRead: false,
      };
      responses.push(entry);
      // Capture the earlier 200 now, never a later response for this URL.
      const previous200 = verified200.get(entry.url);
      const observed = (async () => {
        const [requestHeaders, responseHeaders] = await Promise.all([
          response.request().allHeaders(),
          response.allHeaders(),
        ]);
        entry.request = {
          ifNoneMatch: requestHeaders['if-none-match'],
          ifModifiedSince: requestHeaders['if-modified-since'],
        };
        entry.validators = {
          etag: responseHeaders.etag,
          lastModified: responseHeaders['last-modified'],
          location: responseHeaders.location,
        };
        expect(entry.validators.location).toBeUndefined();
        expect(response.request().redirectedFrom()).toBeNull();
        const name = new URL(entry.url).pathname.split('/').at(-1)!;
        expect(expectedHashes[name]).toBeDefined();
        if (entry.status === 200) {
          entry.bodyRead = true;
          entry.sha256 = createHash('sha256')
            .update(await response.body())
            .digest('hex');
          expect(entry.sha256).toBe(expectedHashes[name]);
        } else {
          expect(entry.status).toBe(304);
          expect(previous200, '304 must revalidate an earlier hash-verified 200').toBeDefined();
          const prior = await previous200!;
          expect(prior.url).toBe(entry.url);
          expect(prior.sha256).toBe(expectedHashes[name]);
          expect(prior.validators.etag).toBeTruthy();
          expect(entry.request.ifNoneMatch).toBe(prior.validators.etag);
          // Caddy may report the unencoded ETag on 304 while the real
          // conditional request carries the earlier gzip representation tag.
          // Link via that exact request validator; retain both response tags.
          if (entry.request.ifModifiedSince !== undefined) {
            expect(prior.validators.lastModified).toBeTruthy();
            expect(entry.request.ifModifiedSince).toBe(prior.validators.lastModified);
          }
          entry.sha256 = prior.sha256;
          entry.verified200At = prior.at;
        }
        return entry;
      })();
      if (entry.status === 200) verified200.set(entry.url, observed);
      // Attach immediately: preserve failures without an unhandled rejection
      // starting teardown before the final media/intent observations.
      responseBodies.push(
        observed.then(
          () => undefined,
          (error: unknown) => {
            observerErrors.push({ url: entry.url, at: Date.now(), error: String(error) });
          },
        ),
      );
    });
    const source =
      '// C++ code generated by ASA Lab\n// Arduino Uno R3\n\nvoid setup()\n{\n\n}\n\nvoid loop()\n{\n\n}\n';
    const workspace = JSON.stringify({
      blocks: {
        languageVersion: 0,
        blocks: [
          { type: 'asa_setup', id: 'setup-533', x: 400, y: 120 },
          { type: 'asa_loop', id: 'loop-533', x: 400, y: 280 },
        ],
      },
    });
    const base = arduinoInputDocument('button', '2');
    const fixture = {
      ...base,
      components: base.components.map((item) =>
        item.id === 'uno'
          ? {
              ...item,
              stateProperties: {
                ...item.stateProperties,
                arduinoCodeMode: mode,
                arduinoSource: source,
                arduinoWorkspace: workspace,
                arduinoSerialOpen: false,
                arduinoBaudRate: 9600,
              },
            }
          : item.id === 'resistor'
            ? {
                ...item,
                stateProperties: { ...item.stateProperties, powerRatingWatt: 0.25 },
              }
            : item.id === 'button-0'
              ? {
                  ...item,
                  stateProperties: { ...item.stateProperties, contactState: 'released' },
                }
              : item,
      ),
    };
    await page.setViewportSize({ width: 1440, height: 900 });
    await loginWithOrganization(page, teacher);
    const projectId = await createProject(page, `Blockly local media preserves intent ${mode}`);
    await saveDocument(page, projectId, fixture);
    const readServer = async () => {
      const response = await page.context().request.get(`/api/projects/${projectId}`);
      expect(response.status()).toBe(200);
      return (await response.json()) as {
        draft: { document: SchematicDocument; revision: number };
      };
    };
    const before = await readServer();
    expect(before.draft.document.connections).toEqual(fixture.connections);
    expect(
      before.draft.document.components.find((item) => item.id === 'uno')?.stateProperties,
    ).toEqual(fixture.components.find((item) => item.id === 'uno')?.stateProperties);
    const readLocal = () =>
      page.evaluate((id) => {
        const raw = localStorage.getItem(`asa-project-local-draft:${id}`);
        return raw ? (JSON.parse(raw) as { document: SchematicDocument }).document : null;
      }, projectId);
    const readLocalKey = () =>
      page.evaluate((id) => localStorage.getItem(`asa-project-local-draft:${id}`), projectId);
    const phases: unknown[] = [];
    const svg = page
      .getByTestId('arduino-block-workspace')
      .locator(':scope > .injectionDiv > svg.blocklySvg');
    const canvas = svg.locator(':scope > .blocklyWorkspace > .blocklyBlockCanvas');
    const scale = () =>
      canvas.evaluate((node) => (node as SVGGElement).transform.baseVal.consolidate()!.matrix.a);
    const readControls = () =>
      svg.evaluate((root) => {
        const rectValue = (rect: DOMRect) => ({
          left: rect.left,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          width: rect.width,
          height: rect.height,
        });
        return ['.blocklyZoomIn', '.blocklyZoomOut', '.blocklyZoomReset', '.blocklyTrash'].map(
          (selector) => {
            const control = root.querySelector<SVGGElement>(selector)!;
            let bounds = control.getBoundingClientRect();
            if (selector === '.blocklyTrash') {
              // The full spritesheet bbox is not the visible trash target.
              // Upstream clips its body and lid separately in SVG user space.
              const parts = Array.from(control.querySelectorAll<SVGImageElement>('image')).map(
                (image) => {
                  const clipId = image.getAttribute('clip-path')!.slice(5, -1);
                  const clip = document.getElementById(clipId)!.querySelector('rect')!;
                  const matrix = image.getScreenCTM()!;
                  const x = Number(clip.getAttribute('x') ?? 0);
                  const y = Number(clip.getAttribute('y') ?? 0);
                  const width = Number(clip.getAttribute('width'));
                  const height = Number(clip.getAttribute('height'));
                  const points = [
                    [x, y],
                    [x + width, y],
                    [x, y + height],
                    [x + width, y + height],
                  ].map(([px, py]) => new DOMPoint(px, py).matrixTransform(matrix));
                  const left = Math.min(...points.map((point) => point.x));
                  const top = Math.min(...points.map((point) => point.y));
                  return new DOMRect(
                    left,
                    top,
                    Math.max(...points.map((point) => point.x)) - left,
                    Math.max(...points.map((point) => point.y)) - top,
                  );
                },
              );
              const left = Math.min(...parts.map((part) => part.left));
              const top = Math.min(...parts.map((part) => part.top));
              bounds = new DOMRect(
                left,
                top,
                Math.max(...parts.map((part) => part.right)) - left,
                Math.max(...parts.map((part) => part.bottom)) - top,
              );
            }
            const clips = [{ left: 0, top: 0, right: innerWidth, bottom: innerHeight }];
            for (
              let ancestor = control.parentElement;
              ancestor;
              ancestor = ancestor.parentElement
            ) {
              const style = getComputedStyle(ancestor);
              const rect = ancestor.getBoundingClientRect();
              const clipsX = style.overflowX !== 'visible';
              const clipsY = style.overflowY !== 'visible';
              if (clipsX || clipsY)
                clips.push({
                  left: clipsX ? rect.left : 0,
                  right: clipsX ? rect.right : innerWidth,
                  top: clipsY ? rect.top : 0,
                  bottom: clipsY ? rect.bottom : innerHeight,
                });
            }
            const hits = [
              [0.5, 0.5],
              [0.2, 0.2],
              [0.8, 0.2],
              [0.2, 0.8],
              [0.8, 0.8],
            ].map(([x, y]) => {
              const px = bounds.left + bounds.width * x;
              const py = bounds.top + bounds.height * y;
              const hit = document.elementFromPoint(px, py);
              return {
                x: px,
                y: py,
                target: hit?.tagName ?? null,
                inside: !!hit && control.contains(hit),
              };
            });
            return {
              selector,
              bounds: rectValue(bounds),
              viewport: { width: innerWidth, height: innerHeight },
              clips,
              hits,
              usable:
                bounds.width > 0 &&
                bounds.height > 0 &&
                clips.every(
                  (clip) =>
                    bounds.left >= clip.left &&
                    bounds.right <= clip.right &&
                    bounds.top >= clip.top &&
                    bounds.bottom <= clip.bottom,
                ) &&
                hits.every((hit) => hit.inside),
            };
          },
        );
      });
    const record = async (phase: string) => {
      for (const selector of [
        '.blocklyZoomIn',
        '.blocklyZoomOut',
        '.blocklyZoomReset',
        '.blocklyTrash',
      ]) {
        await expect(svg.locator(selector)).toBeVisible();
      }
      const images = await svg
        .locator('.blocklyZoom image, .blocklyTrash image')
        .evaluateAll((nodes) =>
          nodes.map((node) => {
            const rect = node.getBoundingClientRect();
            return {
              href:
                node.getAttribute('href') ??
                node.getAttributeNS('http://www.w3.org/1999/xlink', 'href'),
              width: rect.width,
              height: rect.height,
            };
          }),
        );
      for (const image of images) {
        expect(image.width).toBeGreaterThan(0);
        expect(image.height).toBeGreaterThan(0);
        expect(new URL(image.href!, page.url()).origin).toBe(new URL(page.url()).origin);
      }
      expect(
        new Set(images.map((image) => new URL(image.href!, page.url()).pathname.split('/').at(-1))),
      ).toEqual(new Set(mediaNames));
      try {
        await expect
          .poll(async () => (await readControls()).every((control) => control.usable))
          .toBe(true);
      } catch (error) {
        writeFileSync(
          resolve(evidenceDir, 'media.json'),
          JSON.stringify(
            {
              mode,
              requests,
              responses,
              observerErrors,
              expectedHashes,
              phases,
              incompleteControlObservation: {
                phase,
                controls: await readControls(),
                at: Date.now(),
              },
            },
            null,
            2,
          ),
        );
        throw error;
      }
      const controls = await readControls();
      expect(controls.every((control) => control.usable)).toBe(true);
      phases.push({
        phase,
        images,
        controls,
        scale: await scale(),
        transform: await canvas.getAttribute('transform'),
        at: Date.now(),
      });
      writeFileSync(
        resolve(evidenceDir, 'media.json'),
        JSON.stringify(
          { mode, requests, responses, observerErrors, expectedHashes, phases },
          null,
          2,
        ),
      );
      await page.screenshot({ path: resolve(evidenceDir, `${phase}.png`) });
    };
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();
    await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(svg).toBeVisible();
    await expect(svg.locator('[data-id="setup-533"]')).toBeVisible();
    await expect(svg.locator('[data-id="loop-533"]')).toBeVisible();
    if (mode === 'blocks-text')
      await expect(
        page.getByRole('textbox', { name: 'Сгенерированный код Arduino', exact: true }),
      ).toHaveValue(source);
    await expect
      .poll(
        () =>
          new Set(
            responses
              .filter(
                (item) =>
                  item.status === 200 &&
                  item.sha256 === expectedHashes[new URL(item.url).pathname.split('/').at(-1)!],
              )
              .map((item) => new URL(item.url).pathname.split('/').at(-1)),
          ),
      )
      .toEqual(new Set(mediaNames));
    const localBefore = await readLocal();
    // A saved, unchanged program needs no dirty recovery record. Full document
    // preservation is checked against the pre-mount server draft below.
    expect(await readLocalKey()).toBeNull();
    expect(localBefore).toBeNull();
    const initialScale = await scale();
    await record('initial');
    await svg.locator('.blocklyZoomIn').click();
    await expect.poll(scale).toBeGreaterThan(initialScale);
    await record('zoom-in');
    const enlargedScale = await scale();
    await svg.locator('.blocklyZoomOut').click();
    await expect.poll(scale).toBeLessThan(enlargedScale);
    await record('zoom-out');
    await svg.locator('.blocklyZoomIn').click();
    await expect.poll(scale).toBeGreaterThan(initialScale);
    await svg.locator('.blocklyZoomReset').click();
    await expect.poll(scale).toBe(initialScale);
    await record('zoom-reset');
    const localAfterZoom = await readLocal();
    expect(await readLocalKey()).toBeNull();
    expect(localAfterZoom).toBeNull();
    expect(localAfterZoom).toEqual(localBefore);
    const afterZoom = await readServer();
    expect(afterZoom.draft).toEqual(before.draft);
    await page.reload();
    await expect(page.locator('.workbench-stage')).toBeVisible();
    await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(svg.locator('[data-id="setup-533"]')).toBeVisible();
    await expect(svg.locator('[data-id="loop-533"]')).toBeVisible();
    if (mode === 'blocks-text')
      await expect(
        page.getByRole('textbox', { name: 'Сгенерированный код Arduino', exact: true }),
      ).toHaveValue(source);
    const reopenedScale = await scale();
    await svg.locator('.blocklyZoomIn').click();
    await expect.poll(scale).toBeGreaterThan(reopenedScale);
    await record('reopened-zoom-in');
    const reopenedEnlargedScale = await scale();
    await svg.locator('.blocklyZoomOut').click();
    await expect.poll(scale).toBeLessThan(reopenedEnlargedScale);
    await record('reopened-zoom-out');
    await svg.locator('.blocklyZoomIn').click();
    await expect.poll(scale).toBeGreaterThan(reopenedScale);
    await svg.locator('.blocklyZoomReset').click();
    await expect.poll(scale).toBe(initialScale);
    await record('reopened');
    await Promise.all(responseBodies);
    expect(responses).toHaveLength(requests.length);
    for (const request of requests)
      expect(new URL(request.url).origin).toBe(new URL(page.url()).origin);
    for (const response of responses) {
      expect([200, 304]).toContain(response.status);
      const name = new URL(response.url).pathname.split('/').at(-1)!;
      expect(response.sha256).toBe(expectedHashes[name]);
    }
    const after = await readServer();
    const localAfter = await readLocal();
    expect(after.draft).toEqual(before.draft);
    expect(await readLocalKey()).toBeNull();
    expect(localAfter).toBeNull();
    expect(localAfter).toEqual(localBefore);
    writeFileSync(
      resolve(evidenceDir, 'intent.json'),
      JSON.stringify(
        { mode, projectId, before, afterZoom, after, localBefore, localAfterZoom, localAfter },
        null,
        2,
      ),
    );
    writeFileSync(
      resolve(evidenceDir, 'media.json'),
      JSON.stringify(
        { mode, requests, responses, observerErrors, expectedHashes, phases },
        null,
        2,
      ),
    );
    expect(observerErrors).toEqual([]);
    failures.assertEmpty();
  });
}

test('native wire colour menu accepts Purple beside Code across desktop and mobile layouts', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  const evidenceDir = 'reports/playwright/electronics-wire-menu-530';
  mkdirSync(evidenceDir, { recursive: true });
  const observations: unknown[] = [];
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Native wire menu beside Code');
  await saveDocument(page, projectId, arduinoInputDocument('button', '2'));
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  const code = page.locator('.workbench-pill.code');
  const drawer = page.locator('.arduino-code-panel');
  const details = page.locator('.workbench-wire-color');
  const summary = details.locator('summary');
  const purple = details.locator('[aria-label="Цвет провода: Фиолетовый"]');
  const blue = details.locator('[aria-label="Цвет провода: Синий"]');
  const widthHandle = page.getByRole('separator', { name: 'Изменить ширину редактора кода' });
  const heightHandle = page.getByRole('separator', { name: 'Изменить высоту редактора кода' });
  await code.click();
  await expect(drawer).toHaveClass(/open/);
  await expect(drawer).toHaveCSS('transform', 'matrix(1, 0, 0, 1, 0, 0)');

  async function record(phase: string) {
    const observation = await page.evaluate((phase) => {
      function inspect(selector: string) {
        const element = document.querySelector<HTMLElement>(selector);
        if (!element) throw new Error(`Missing wire menu consumer: ${selector}`);
        const bounds = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        const points = [
          [bounds.x + bounds.width / 2, bounds.y + bounds.height / 2],
          [bounds.left + 4, bounds.top + 4],
          [bounds.right - 4, bounds.top + 4],
          [bounds.left + 4, bounds.bottom - 4],
          [bounds.right - 4, bounds.bottom - 4],
        ].map(([x, y]) => {
          const top = document.elementFromPoint(x, y);
          return {
            x,
            y,
            owned: top === element || Boolean(top && element.contains(top)),
            target: top?.closest('button, summary, [role="separator"]')?.outerHTML ?? top?.tagName,
          };
        });
        return {
          bounds: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height },
          display: style.display,
          visibility: style.visibility,
          overflowX: style.overflowX,
          overflowY: style.overflowY,
          zIndex: style.zIndex,
          scrollWidth: element.scrollWidth,
          clientWidth: element.clientWidth,
          ariaValueNow: element.getAttribute('aria-valuenow'),
          checked: element.getAttribute('aria-checked'),
          pressed: element.getAttribute('aria-pressed'),
          points,
        };
      }
      return {
        phase,
        viewport: { width: innerWidth, height: innerHeight },
        pageWidth: document.documentElement.scrollWidth,
        clientWidth: document.documentElement.clientWidth,
        menuOpen: document.querySelector<HTMLDetailsElement>('.workbench-wire-color')?.open,
        toolbar: inspect('.workbench-toolbar'),
        tools: inspect('.workbench-breadboard-tools'),
        summary: inspect('.workbench-wire-color summary'),
        menu: inspect('.workbench-wire-color-menu'),
        purple: inspect('[aria-label="Цвет провода: Фиолетовый"]'),
        code: inspect('.workbench-pill.code'),
        drawer: inspect('.arduino-code-panel'),
        widthHandle: inspect('.arduino-drawer-resize-handle'),
        heightHandle: inspect('.arduino-mobile-panel-grip'),
      };
    }, phase);
    observations.push(observation);
    writeFileSync(`${evidenceDir}/geometry.json`, JSON.stringify(observations, null, 2));
    await page.screenshot({ path: `${evidenceDir}/${phase}.png`, fullPage: true });
    return observation;
  }

  function assertFits(bounds: { x: number; y: number; width: number; height: number }) {
    const viewport = page.viewportSize()!;
    expect(bounds.width).toBeGreaterThan(0);
    expect(bounds.height).toBeGreaterThan(0);
    expect(bounds.x).toBeGreaterThanOrEqual(0);
    expect(bounds.y).toBeGreaterThanOrEqual(0);
    expect(bounds.x + bounds.width).toBeLessThanOrEqual(viewport.width);
    expect(bounds.y + bounds.height).toBeLessThanOrEqual(viewport.height);
  }

  // At 1440 the drawer has room to change width; at 1024 its existing clamp
  // fixes it at 604px. Exercise real resizing where the control permits it.
  await summary.click();
  const openResize = await record('1440-open-before-resize');
  expect(openResize.menuOpen).toBe(true);
  expect(openResize.widthHandle.points[0].owned).toBe(true);
  const resizePoint = {
    x: openResize.widthHandle.bounds.x + openResize.widthHandle.bounds.width / 2,
    y: openResize.drawer.bounds.y + openResize.drawer.bounds.height / 2,
  };
  expect(resizePoint.y).toBeGreaterThan(openResize.menu.bounds.y + openResize.menu.bounds.height);
  await page.mouse.move(resizePoint.x, resizePoint.y);
  await page.mouse.down();
  await page.mouse.move(resizePoint.x + 32, resizePoint.y, { steps: 8 });
  await page.mouse.up();
  const resizedOpen = await record('1440-after-open-menu-resize');
  expect(Number(resizedOpen.widthHandle.ariaValueNow)).toBe(
    Number(openResize.widthHandle.ariaValueNow) - 32,
  );
  expect(resizedOpen.drawer.bounds.width).toBe(openResize.drawer.bounds.width - 32);
  if (await details.evaluate((element) => (element as HTMLDetailsElement).open)) {
    await summary.click();
  }
  const closedResize = await record('1440-closed-before-resize');
  expect(closedResize.menuOpen).toBe(false);
  expect(closedResize.widthHandle.points[0].owned).toBe(true);
  const closedPoint = {
    x: closedResize.widthHandle.bounds.x + closedResize.widthHandle.bounds.width / 2,
    y: resizePoint.y,
  };
  await page.mouse.move(closedPoint.x, closedPoint.y);
  await page.mouse.down();
  await page.mouse.move(closedPoint.x + 32, closedPoint.y, { steps: 8 });
  await page.mouse.up();
  const resizedClosed = await record('1440-after-closed-menu-resize');
  expect(Number(resizedClosed.widthHandle.ariaValueNow)).toBe(
    Number(closedResize.widthHandle.ariaValueNow) - 32,
  );
  expect(resizedClosed.drawer.bounds.width).toBe(closedResize.drawer.bounds.width - 32);

  for (const width of [1440, 1024, 981]) {
    await page.setViewportSize({ width, height: 900 });
    await summary.click();
    await blue.click();
    await summary.click();
    const before = await record(`${width}-before-purple`);
    expect(before.menuOpen).toBe(true);
    expect(before.code.pressed).toBe('true');
    expect(before.purple.checked).toBe('false');
    expect(before.pageWidth).toBeLessThanOrEqual(before.clientWidth);
    assertFits(before.menu.bounds);
    assertFits(before.purple.bounds);
    expect(before.menu.points.every((point) => point.owned)).toBe(true);
    expect(before.purple.points.every((point) => point.owned)).toBe(true);
    await purple.click({ trial: true });
    await purple.click();
    const after = await record(`${width}-after-purple`);
    expect(after.purple.checked).toBe('true');
    expect(after.menuOpen).toBe(false);
    await expect(purple).toHaveAttribute('aria-checked', 'true');
    await expect(summary.locator('span')).toHaveCSS('background-color', 'rgb(141, 69, 199)');
    await expect(code).toHaveAttribute('aria-pressed', 'true');
    await expect(widthHandle).toBeVisible();
  }

  // Native dropdown presentation is intentionally clipped on mobile. Check its
  // actual toolbar/Code consumers and the bottom panel's real height gesture.
  for (const width of [980, 390, 320]) {
    await page.setViewportSize({ width, height: 844 });
    const before = await record(`${width}-mobile-before-resize`);
    expect(before.menuOpen).toBe(false);
    expect(before.pageWidth).toBeLessThanOrEqual(before.clientWidth);
    expect(before.toolbar.overflowX).toBe('hidden');
    expect(before.tools.overflowX).toBe('auto');
    expect(before.widthHandle.display).toBe('none');
    expect(before.code.pressed).toBe('true');
    assertFits(before.toolbar.bounds);
    assertFits(before.code.bounds);
    assertFits(before.drawer.bounds);
    assertFits(before.heightHandle.bounds);
    expect(before.code.points.every((point) => point.owned)).toBe(true);
    expect(before.heightHandle.points[0].owned).toBe(true);
    await expect(heightHandle).toBeVisible();
    const point = before.heightHandle.points[0];
    await page.mouse.move(point.x, point.y);
    await page.mouse.down();
    await page.mouse.move(point.x, point.y - 32, { steps: 8 });
    await page.mouse.up();
    const after = await record(`${width}-mobile-after-resize`);
    expect(Number(after.heightHandle.ariaValueNow)).toBeGreaterThan(
      Number(before.heightHandle.ariaValueNow),
    );
    expect(after.drawer.bounds.height).toBeGreaterThan(before.drawer.bounds.height);
    assertFits(after.drawer.bounds);
    await expect(code).toHaveAttribute('aria-pressed', 'true');
    await expect(widthHandle).toBeHidden();
  }
  failures.assertEmpty();
});

test('component inspector separates compact settings, live state and educational help', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'R4-M1 component information');
  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: false, resistorOhms: 220, reversedLed: false }),
  );
  await page.goto(`/#/home/${projectId}`);

  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await expect(inspector).toBeVisible();
  await expect(inspector.getByTestId('component-compact-properties')).toContainText('Имя');
  await expect(inspector.getByTestId('component-compact-properties')).toContainText(
    'Сопротивление',
  );
  await expect(inspector).not.toContainText('Модель ожидает корректную цепь');

  await inspector.getByRole('button', { name: 'Техническое состояние Резистор' }).click();
  await expect(inspector.getByTestId('component-simulation-status')).toHaveCount(0);
  await expect(inspector.getByRole('combobox', { name: 'Допуск резистора' })).toBeVisible();
  await expect(inspector.getByRole('region', { name: 'Справка' })).toHaveCount(0);

  await inspector.getByRole('button', { name: 'Справка о компоненте Резистор' }).click();
  const help = inspector.getByRole('region', { name: 'Справка' });
  await expect(help).toBeVisible();
  await expect(help).toContainText('Описание');
  await expect(help).toContainText('Принцип работы');
  await expect(help).toContainText('Подключение');
  await expect(inspector.getByTestId('component-simulation-status')).toHaveCount(0);

  await inspector.getByRole('button', { name: 'Техническое состояние Резистор' }).click();
  await expect(inspector.getByRole('combobox', { name: 'Допуск резистора' })).toBeVisible();

  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: 'Свернуть библиотеку' }).click();
  await expect(inspector).toBeVisible();
  for (const buttonName of ['Техническое состояние Резистор', 'Справка о компоненте Резистор']) {
    const box = await inspector.getByRole('button', { name: buttonName }).boundingBox();
    expect(box?.width).toBeGreaterThanOrEqual(44);
    expect(box?.height).toBeGreaterThanOrEqual(44);
  }
  failures.assertEmpty();
});

test('capacitor and battery holder pass interaction through transparent owner pixels', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-4B1 capacitor body hit area');
  await saveDocument(page, projectId, capacitorInteractionDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();

  const capacitor = component(page, 'electrolytic-capacitor');
  const capacitorBody = capacitor.locator('.workbench-part');
  await expect(capacitorBody.locator('.workbench-component-body-hit')).toHaveAttribute(
    'data-hit-surface',
    'owner-alpha-mask',
  );
  await page.waitForTimeout(300);
  const beforeX = await capacitor.getAttribute('data-x');
  const transparentBounds = await capacitorBody.boundingBox();
  if (!transparentBounds) throw new Error('capacitor body has no rendered bounds');
  const transparentPoint = {
    x: transparentBounds.x + 3,
    y: transparentBounds.y + transparentBounds.height / 2,
  };
  const resistor = component(page, 'resistor-axial');
  const resistorBody = resistor.locator('.workbench-part');
  const resistorBounds = await resistorBody.boundingBox();
  if (!resistorBounds) throw new Error('resistor body has no rendered bounds');
  await page.mouse.move(
    resistorBounds.x + resistorBounds.width / 2,
    resistorBounds.y + resistorBounds.height / 2,
  );
  await page.mouse.down();
  await page.mouse.move(transparentPoint.x, transparentPoint.y, { steps: 5 });
  await page.mouse.up();
  const resistorUnderlayX = await resistor.getAttribute('data-x');

  await page.mouse.move(transparentPoint.x, transparentPoint.y);
  await page.mouse.down();
  await page.mouse.move(transparentPoint.x + 60, transparentPoint.y, { steps: 5 });
  await page.mouse.up();
  await expect(capacitor).toHaveAttribute('data-x', beforeX ?? '');
  await expect(resistor).not.toHaveAttribute('data-x', resistorUnderlayX ?? '');

  const visibleBounds = await capacitorBody.boundingBox();
  if (!visibleBounds) throw new Error('capacitor visible body has no rendered bounds');
  await page.mouse.move(
    visibleBounds.x + visibleBounds.width / 2,
    visibleBounds.y + visibleBounds.height / 2,
  );
  await page.mouse.down();
  await page.mouse.move(
    visibleBounds.x + visibleBounds.width / 2 + 50,
    visibleBounds.y + visibleBounds.height / 2,
    { steps: 5 },
  );
  await page.mouse.up();
  await expect(capacitor).not.toHaveAttribute('data-x', beforeX ?? '');

  const battery = component(page, 'battery-holder-aa-2');
  const batteryBody = battery.locator('.workbench-part');
  const batteryBeforeX = await battery.getAttribute('data-x');
  const batteryBounds = await batteryBody.boundingBox();
  if (!batteryBounds) throw new Error('battery holder has no rendered bounds');
  const batteryTransparentCorner = {
    x: batteryBounds.x + 1,
    y: batteryBounds.y + 1,
  };
  const currentResistorBounds = await resistorBody.boundingBox();
  if (!currentResistorBounds)
    throw new Error('resistor has no rendered bounds after capacitor test');
  await page.mouse.move(
    currentResistorBounds.x + currentResistorBounds.width / 2,
    currentResistorBounds.y + currentResistorBounds.height / 2,
  );
  await page.mouse.down();
  await page.mouse.move(batteryTransparentCorner.x, batteryTransparentCorner.y, { steps: 5 });
  await page.mouse.up();
  const resistorAtBatteryX = await resistor.getAttribute('data-x');
  await page.mouse.move(batteryTransparentCorner.x, batteryTransparentCorner.y);
  await page.mouse.down();
  await page.mouse.move(batteryTransparentCorner.x - 60, batteryTransparentCorner.y, { steps: 5 });
  await page.mouse.up();
  await expect(battery).toHaveAttribute('data-x', batteryBeforeX ?? '');
  await expect(resistor).not.toHaveAttribute('data-x', resistorAtBatteryX ?? '');

  const movedBounds = await capacitorBody.boundingBox();
  if (!movedBounds) throw new Error('moved capacitor has no rendered bounds');
  await page.mouse.click(
    movedBounds.x + movedBounds.width / 2,
    movedBounds.y + movedBounds.height / 2,
  );
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  const capacitorInformation = inspector.getByRole('button', {
    name: 'Техническое состояние Конденсатор',
  });
  await capacitorInformation.click();
  await expect(capacitorInformation).toHaveAttribute('aria-expanded', 'true');

  await component(page, 'resistor-axial').locator('.workbench-part').click();
  const resistorInformation = inspector.getByRole('button', {
    name: 'Техническое состояние Резистор',
  });
  await expect(resistorInformation).toHaveAttribute('aria-expanded', 'true');
  await expect(inspector.getByRole('combobox', { name: 'Допуск резистора' })).toBeVisible();
  failures.assertEmpty();
});

test('reverse-sign capacitor voltage stays inside I without a stage warning', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-4B2 capacitor polarity information');
  await saveDocument(page, projectId, reverseCapacitorDocument());
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const capacitor = component(page, 'electrolytic-capacitor');
  await expect(capacitor).toHaveAttribute('data-diagnostics', /capacitor_reverse_polarity/, {
    timeout: 10_000,
  });
  await expect(
    page.locator(
      '[data-testid="component-diagnostic"][data-component-type="electrolytic-capacitor"]',
    ),
  ).toHaveCount(0);
  await capacitor.locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: 'Техническое состояние Конденсатор' }).click();
  await expect(inspector.getByTestId('capacitor-polarity-state')).toContainText(
    'Напряжение обратного знака',
  );
  await expect(
    inspector.getByText(/напряжение на выводах сейчас имеет обратный знак/i),
  ).toBeVisible();
  failures.assertEmpty();
});

test('a safe PNP astable visibly alternates both LEDs', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-4B2 PNP multivibrator');
  await saveDocument(page, projectId, pnpAstableDocument(100));
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();

  const leftLed = page.locator(
    '[data-testid="schematic-component"][data-component-id="led1"] .workbench-production-visual',
  );
  const rightLed = page.locator(
    '[data-testid="schematic-component"][data-component-id="led2"] .workbench-production-visual',
  );
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const samples: Array<readonly [number, number]> = [];
  for (let index = 0; index < 80; index += 1) {
    await page.waitForTimeout(100);
    samples.push([
      Number((await leftLed.getAttribute('data-led-brightness')) ?? '0'),
      Number((await rightLed.getAttribute('data-led-brightness')) ?? '0'),
    ]);
  }

  expect(
    samples.some(([left, right]) => left > right + 1),
    JSON.stringify(samples),
  ).toBe(true);
  expect(
    samples.some(([left, right]) => right > left + 1),
    JSON.stringify(samples),
  ).toBe(true);
  await expect(
    page.locator('[data-testid="component-diagnostic"][data-component-id="led1"]'),
  ).toHaveCount(0);
  await expect(
    page.locator('[data-testid="component-diagnostic"][data-component-id="led2"]'),
  ).toHaveCount(0);
  failures.assertEmpty();
});

test('DO-35 exposes calculated current and fixed profile limits through I', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-2 DO-35 inspector');
  await saveDocument(page, projectId, diodeProfileDocument('diode-do35'));
  await page.goto(`/#/home/${projectId}`);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await component(page, 'diode-do35').locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: 'Техническое состояние Диод' }).click();
  await expect(inspector.getByText('Длительный ток', { exact: true })).toBeVisible();
  await expect(inspector.getByText('200 мА', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Обратный предел', { exact: true })).toBeVisible();
  await expect(inspector.getByText('100 В', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Ток', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Прямое падение', { exact: true })).toHaveCount(0);
  failures.assertEmpty();
});

test('NPN key exposes its calculated operating point through I', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-3 NPN key inspector');
  await saveDocument(page, projectId, npnKeyDocument());
  await page.goto(`/#/home/${projectId}`);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await component(page, 'transistor-npn').locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: /Техническое состояние/ }).click();
  await expect(inspector.getByText('Регулирует ток', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Ток управления (база)', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Ток нагрузки (коллектор)', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Общий ток (эмиттер)', { exact: true })).toBeVisible();

  const variant = inspector.getByLabel('Вариант Транзистор в проекте');
  await expect(page.locator('[data-testid="schematic-wire"]')).toHaveCount(5);
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await variant.selectOption('transistor-fet');
  await expect(component(page, 'transistor-fet')).toBeVisible();
  await expect(page.locator('[data-testid="schematic-wire"]')).toHaveCount(5);
  await variant.selectOption('transistor-pnp');
  await expect(component(page, 'transistor-pnp')).toBeVisible();
  await expect(page.locator('[data-testid="schematic-wire"]')).toHaveCount(5);
  failures.assertEmpty();
});

test('photoresistor converts runtime light to resistance without saving the project', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-6B photoresistor runtime');
  await saveDocument(page, projectId, photoresistorDocument());
  await page.goto(`/#/home/${projectId}`);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const ldr = component(page, 'photoresistor');
  await ldr.locator('.workbench-part').click({ force: true });
  const lightControl = page.getByTestId('photoresistor-light-control');
  await expect(lightControl.locator('output')).toHaveText('32 лк');

  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: /Техническое состояние/ }).click();
  const profile = inspector.getByTestId('photoresistor-reference-profile');
  await expect(profile).toContainText('GL5528-class 5 mm CdS LDR');
  await expect(profile).toContainText('6.72 кОм');

  const origin = new URL(page.url()).origin;
  await page.waitForTimeout(1_200);
  const revisionBeforeResponse = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin },
  });
  const revisionBefore = ((await revisionBeforeResponse.json()) as { draft: { revision: number } })
    .draft.revision;

  const slider = lightControl.getByRole('slider', { name: 'Освещённость фоторезистора' });
  await slider.fill('100');
  await expect(lightControl.locator('output')).toHaveText('10 тыс. лк');
  await expect(profile).toContainText('119 Ом');
  await slider.fill('0');
  await expect(lightControl.locator('output')).toHaveText('0 лк');
  await expect(profile).toContainText('1.00 МОм');

  await inspector.getByRole('button', { name: /Справка/ }).click();
  await expect(page.getByText('Как свет меняет сопротивление', { exact: true })).toBeVisible();
  await expect(page.getByText(/делитель напряжения/)).toBeVisible();

  await page.waitForTimeout(1_200);
  const revisionAfterResponse = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin },
  });
  const revisionAfter = ((await revisionAfterResponse.json()) as { draft: { revision: number } })
    .draft.revision;
  expect(revisionAfter).toBe(revisionBefore);

  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-photoresistor-runtime.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('6 V incandescent lamp warms into the owner glow and explains its fixed profile', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-6D incandescent lamp electrothermal runtime');
  await saveDocument(page, projectId, incandescentLampDocument());
  await page.goto(`/#/home/${projectId}`);

  const lamp = component(page, 'incandescent-lamp');
  const lampAsset = lamp.locator('image').last();
  await expect(lampAsset).toHaveAttribute('href', /lamp\/off\.svg$/);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect
    .poll(async () => lampAsset.getAttribute('href'), { timeout: 10_000 })
    .toMatch(/lamp\/(on|max)\.svg$/);

  await lamp.locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: /Техническое состояние/ }).click();
  const profile = inspector.getByTestId('lamp-reference-profile');
  await expect(profile).toContainText('T-1, два штырька');
  await expect(profile).toContainText('6 В');
  await expect(profile).toContainText('250 мА');
  await expect(profile).toContainText('1.5 Вт');
  await expect(profile).toContainText(/Сопротивление нити сейчас2[0-4]\.\d{2} Ом/);
  await expect(inspector.getByText('Светит', { exact: true })).toBeVisible();
  await expect(lamp).not.toHaveAttribute('data-presentation-state', 'destructive');

  await inspector.getByRole('button', { name: /Справка/ }).click();
  await expect(page.getByText('Что имитируется', { exact: true })).toBeVisible();
  await expect(
    page.getByText('Почему яркость меняется не мгновенно', { exact: true }),
  ).toBeVisible();
  await expect(page.getByText('Перенапряжение и перегорание', { exact: true })).toBeVisible();

  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-incandescent-lamp-runtime.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('direct DC motor shows calculated signed RPM and calm visual direction', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  const workerUrls: string[] = [];
  page.on('worker', (worker) => workerUrls.push(worker.url()));
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-5C DC motor runtime');
  await saveDocument(page, projectId, dcMotorDocument());
  await page.goto(`/#/home/${projectId}`);

  const motor = component(page, 'dc-motor');
  const readout = page.locator('[data-testid="dc-motor-rpm"][data-component-id="motor"]');
  await expect(readout).toHaveText('0 об/мин');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect
    .poll(() => workerUrls.some((url) => url.includes('simulation.worker')), { timeout: 10_000 })
    .toBe(true);
  await expect
    .poll(async () => (await readout.textContent())?.trim(), { timeout: 10_000 })
    .not.toBe('0 об/мин');

  const phaseVisual = motor.getByTestId('dc-motor-phase');
  await expect(phaseVisual).toBeVisible();
  await expect(phaseVisual).toHaveAttribute('data-motor-visual-direction', 'clockwise');
  await expect(phaseVisual).toHaveAttribute('data-motor-visual-period-seconds', '1.95');
  const gear = phaseVisual.locator('.workbench-dc-motor-gear');
  const firstPhase = await gear.evaluate((element) => getComputedStyle(element).transform);
  await page.waitForTimeout(250);
  const secondPhase = await gear.evaluate((element) => getComputedStyle(element).transform);
  expect(secondPhase).not.toBe(firstPhase);

  await motor.locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: /Техническое состояние/ }).click();
  await expect(inspector.getByText('Скорость', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Направление', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Электромагнитный момент', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Нагрузка на валу', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Рабочий диапазон', { exact: true })).toBeVisible();
  await expect(inspector.getByText('В рабочем диапазоне', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Нагрев обмотки I²R', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Температура', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Обмотка', { exact: true })).toBeVisible();
  const shaftLock = inspector.getByLabel('Заблокировать вал двигателя');
  await shaftLock.check();
  await expect(inspector.getByText('Вал заблокирован', { exact: true })).toBeVisible();
  await expect
    .poll(async () => (await readout.textContent())?.trim(), { timeout: 5_000 })
    .toBe('0 об/мин');
  await shaftLock.uncheck();
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-dc-motor-runtime.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('1:48 gearmotor exposes real settings, output RPM and runtime shaft control', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-5F gearmotor runtime');
  await saveDocument(page, projectId, gearmotorDocument());
  await page.goto(`/#/home/${projectId}`);

  const motor = component(page, 'gearmotor');
  const readout = page.locator('[data-testid="gearmotor-output-rpm"][data-component-id="motor"]');
  await expect(readout).toHaveText('0 об/мин');
  await motor.locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: /Техническое состояние/ }).click();
  await expect(inspector.getByText('Настройки мотор-редуктора', { exact: true })).toBeVisible();
  await expect(inspector.getByText('1:48 · TT · 3–6 В', { exact: true })).toBeVisible();
  await expect(
    inspector.getByText('Сейчас доступна одна подтверждённая версия.', { exact: true }),
  ).toBeVisible();
  await expect(inspector.getByLabel('Нагрузка на выходном валу мотор-редуктора')).toHaveValue('0');

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect
    .poll(async () => Number.parseInt((await readout.textContent()) ?? '0', 10), {
      timeout: 10_000,
    })
    .toBeGreaterThan(0);
  await expect(readout).toHaveAttribute('data-placement', 'primary-body');
  const phaseVisual = motor.getByTestId('gearmotor-phase');
  await expect(phaseVisual).toHaveAttribute('data-output-visual-direction', 'clockwise');
  const visualBox = await phaseVisual.boundingBox();
  const readoutBox = await readout.boundingBox();
  expect(visualBox).not.toBeNull();
  expect(readoutBox).not.toBeNull();
  if (!visualBox || !readoutBox) throw new Error('gearmotor RPM placement is unavailable');
  const readoutCenterX = readoutBox.x + readoutBox.width / 2;
  const readoutCenterY = readoutBox.y + readoutBox.height / 2;
  expect((readoutCenterX - visualBox.x) / visualBox.width).toBeGreaterThan(0.4);
  expect((readoutCenterX - visualBox.x) / visualBox.width).toBeLessThan(0.52);
  expect((readoutCenterY - visualBox.y) / visualBox.height).toBeGreaterThan(0.18);
  expect((readoutCenterY - visualBox.y) / visualBox.height).toBeLessThan(0.32);
  const outputShaft = phaseVisual.locator('.workbench-gearmotor-output-bar');
  const outputShaftMarker = phaseVisual.locator('.workbench-gearmotor-output-bar-highlight');
  await expect(outputShaftMarker).toHaveCSS('fill', 'rgb(102, 114, 123)');
  await expect(phaseVisual.locator('.workbench-gearmotor-output-axle-highlight')).toHaveCount(0);
  const motorShaftMarker = phaseVisual.locator('.workbench-gearmotor-motor-shaft-highlight');
  await expect(motorShaftMarker).toHaveCSS('fill', 'rgb(70, 81, 90)');
  const initialMarkerTransform = await outputShaftMarker.evaluate(
    (element) => getComputedStyle(element).transform,
  );
  const initialMarkerOpacity = await outputShaftMarker.evaluate(
    (element) => getComputedStyle(element).opacity,
  );
  const initialShaftTransform = await outputShaft.evaluate(
    (element) => getComputedStyle(element).transform,
  );
  const initialMotorMarkerTransform = await motorShaftMarker.evaluate(
    (element) => getComputedStyle(element).transform,
  );
  await expect
    .poll(
      async () => outputShaftMarker.evaluate((element) => getComputedStyle(element).transform),
      { timeout: 5_000 },
    )
    .not.toBe(initialMarkerTransform);
  await expect
    .poll(async () => outputShaftMarker.evaluate((element) => getComputedStyle(element).opacity), {
      timeout: 5_000,
    })
    .not.toBe(initialMarkerOpacity);
  await expect
    .poll(async () => outputShaft.evaluate((element) => getComputedStyle(element).transform), {
      timeout: 5_000,
    })
    .not.toBe(initialShaftTransform);
  await expect
    .poll(async () => motorShaftMarker.evaluate((element) => getComputedStyle(element).transform), {
      timeout: 5_000,
    })
    .not.toBe(initialMotorMarkerTransform);
  await expect(inspector.getByText('Выходной вал', { exact: true })).toBeVisible();
  const advancedParameters = inspector.getByText('Подробные параметры', { exact: true });
  await advancedParameters.click();
  await expect(inspector.getByText('Двигатель внутри', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Передаточное отношение', { exact: true })).toBeVisible();
  await expect(inspector.getByText('КПД редуктора', { exact: true })).toBeVisible();
  await expect(inspector.getByText('Момент выходного вала', { exact: true })).toBeVisible();
  await advancedParameters.click();
  await expect(inspector.getByText('Двигатель внутри', { exact: true })).toBeHidden();

  const shaftLock = inspector.getByLabel('Заблокировать выходной вал мотор-редуктора');
  await shaftLock.check();
  await expect(inspector.getByText('Вал заблокирован', { exact: true })).toBeVisible();
  await expect
    .poll(async () => (await readout.textContent())?.trim(), { timeout: 5_000 })
    .toBe('0 об/мин');
  await shaftLock.uncheck();
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-gearmotor-runtime.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('gearmotor warning stays on the primary yellow housing instead of a shaft tip', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-5F gearmotor diagnostic anchor');
  await saveDocument(page, projectId, gearmotorOvervoltageDocument());
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const motor = component(page, 'gearmotor');
  const visual = motor.getByTestId('gearmotor-phase');
  const diagnosticGroup = page.locator(
    '[data-testid="component-diagnostic"][data-component-type="gearmotor"]',
  );
  await expect(diagnosticGroup).toHaveAttribute('data-anchor', 'primary-body-top-right');
  const visualBox = await visual.boundingBox();
  const diagnosticBox = await diagnosticGroup.boundingBox();
  expect(visualBox).not.toBeNull();
  expect(diagnosticBox).not.toBeNull();
  if (!visualBox || !diagnosticBox) throw new Error('gearmotor visual geometry is unavailable');
  const relativeCenterX =
    (diagnosticBox.x + diagnosticBox.width / 2 - visualBox.x) / visualBox.width;
  const relativeCenterY =
    (diagnosticBox.y + diagnosticBox.height / 2 - visualBox.y) / visualBox.height;
  expect(relativeCenterX).toBeGreaterThan(0.55);
  expect(relativeCenterX).toBeLessThan(0.8);
  expect(relativeCenterY).toBeGreaterThan(0.05);
  expect(relativeCenterY).toBeLessThan(0.25);

  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-gearmotor-warning-anchor.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('23 V motor shows local overvoltage, accumulated damage and open failure', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'MATH-5C DC motor overvoltage damage');
  await saveDocument(page, projectId, dcMotorOvervoltageDocument());
  await page.goto(`/#/home/${projectId}`);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const motor = component(page, 'dc-motor');
  await motor.locator('.workbench-part').click({ force: true });
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByRole('button', { name: /Техническое состояние/ }).click();

  await expect(inspector.getByText('Выше рабочего диапазона', { exact: true })).toBeVisible();
  const overvoltageBadge = diagnostic(page, 'dc-motor', 'component-diagnostic-indicator');
  await expect(overvoltageBadge).toBeVisible();
  await expect(motor).toHaveAttribute('data-presentation-state', 'destructive');
  await expect(inspector.getByText('Накопленный износ', { exact: true })).toBeVisible({
    timeout: 8_000,
  });
  await expect(inspector.getByText('Перегорела — цепь разомкнута', { exact: true })).toBeVisible({
    timeout: 20_000,
  });
  await expect(motor).toHaveAttribute('data-presentation-state', 'failed');
  const failedMotorReadout = page.locator(
    '[data-testid="dc-motor-rpm"][data-component-id="motor"]',
  );
  await expect
    .poll(async () => Number.parseInt((await failedMotorReadout.textContent()) ?? '', 10), {
      timeout: 8_000,
    })
    .toBeLessThan(500);
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-dc-motor-overvoltage-failed.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('catalog placement is one hold-drag-release gesture and snaps on the first drop', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'R4-M1 catalog drag and first snap');
  await saveDocument(page, projectId, breadboardDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();

  const j8 = await holeCenter(page, 'J8');
  const j9 = await holeCenter(page, 'J9');
  const pitch = j9.x - j8.x;
  await dragCatalogComponent(page, 'Потенциометр', {
    x: j8.x + pitch,
    y: j8.y - (pitch * 6.858) / 2.54,
  });
  const potentiometer = component(page, 'potentiometer');
  await expect(potentiometer).toHaveAttribute('data-hole-bindings', '3');
  await expect(potentiometer).toHaveAttribute(
    'data-hole-ids',
    /terminal-1:J8,terminal-2:J10,wiper:J9/,
  );

  const j20 = await holeCenter(page, 'J20');
  await dragCatalogComponent(page, 'Батарейный отсек AA', {
    x: j20.x + (pitch * 1.2721) / 2.54,
    y: j20.y + (pitch * 28.9396) / 2.54,
  });
  const battery = component(page, 'battery-holder-aa-2');
  await expect(battery).toHaveAttribute('data-hole-bindings', '2');
  await expect(battery).toHaveAttribute('data-hole-ids', /BAT-:J20,BAT\+:J21/);
  const batteryPosition = {
    x: await battery.getAttribute('data-x'),
    y: await battery.getAttribute('data-y'),
  };
  const negativeLead = page.locator('[data-mounted-terminal="BAT-"]');
  const leadBefore = {
    x: await negativeLead.getAttribute('x2'),
    y: await negativeLead.getAttribute('y2'),
  };

  const board = component(page, 'breadboard-medium');
  const boardPosition = {
    x: await board.getAttribute('data-x'),
    y: await board.getAttribute('data-y'),
  };
  const boardGrab = await unobstructedComponentPoint(page, 'breadboard-medium');
  await page.mouse.move(boardGrab.x, boardGrab.y);
  await page.mouse.down();
  await page.mouse.move(boardGrab.x + 60, boardGrab.y + 30, { steps: 10 });
  await page.mouse.up();
  await expect(board).not.toHaveAttribute('data-x', boardPosition.x ?? '');
  await expect(battery).toHaveAttribute('data-x', batteryPosition.x ?? '');
  await expect(battery).toHaveAttribute('data-y', batteryPosition.y ?? '');
  await expect
    .poll(async () => ({
      x: await negativeLead.getAttribute('x2'),
      y: await negativeLead.getAttribute('y2'),
    }))
    .not.toEqual(leadBefore);
  failures.assertEmpty();
});

persistenceVideoTest.describe('R1-R4 real API persistence evidence', () => {
  persistenceVideoTest(
    'real API wire workflow saves endpoints colour and vertices across reload',
    async ({ page }) => {
      test.setTimeout(120_000);
      const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
      await page.setViewportSize({ width: 1920, height: 1080 });
      await loginWithOrganization(page, teacher);
      const projectId = await createProject(page, 'R1-R4 wire persistence acceptance');
      const base = circuitDocument({ switchClosed: false, resistorOhms: 220, reversedLed: false });
      const persistenceDocument: SchematicDocument = {
        ...base,
        components: base.components.filter((item) => item.id === 'source' || item.id === 'led'),
        connections: [],
        viewport: { x: 0, y: 0, zoom: 1 },
        simulation: { running: false, maxIterations: 24 },
      };
      await saveDocument(page, projectId, persistenceDocument);
      await page.goto(`/#/home/${projectId}`);
      await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
      await expect(page.locator('[data-testid="schematic-component"]')).toHaveCount(2);

      const stageBox = await page.locator('.workbench-stage').boundingBox();
      if (!stageBox) throw new Error('workbench stage is not rendered');
      await dragCatalogComponent(page, 'Резистор', {
        x: stageBox.x + stageBox.width * 0.26,
        y: stageBox.y + stageBox.height * 0.72,
      });
      await expect(component(page, 'resistor-axial')).toHaveCount(1);

      const source = page.locator(
        '.workbench-terminal-hit[data-terminal-component-id="source"][data-terminal-id="BAT+"]',
      );
      const target = page.locator(
        '.workbench-terminal-hit[data-terminal-component-id="led"][data-terminal-id="anode"]',
      );
      const sourceBox = await source.boundingBox();
      const targetBox = await target.boundingBox();
      if (!sourceBox || !targetBox) throw new Error('wire acceptance terminals are not rendered');
      const sourcePoint = {
        x: sourceBox.x + sourceBox.width / 2,
        y: sourceBox.y + sourceBox.height / 2,
      };
      const targetPoint = {
        x: targetBox.x + targetBox.width / 2,
        y: targetBox.y + targetBox.height / 2,
      };
      const bendPoint = {
        x: stageBox.x + stageBox.width * 0.46,
        y: stageBox.y + stageBox.height * 0.48,
      };

      await page.mouse.click(sourcePoint.x, sourcePoint.y);
      const pendingPreview = page.locator('.workbench-wire-preview');
      await expect(pendingPreview).toHaveCount(1);
      await page.mouse.move(bendPoint.x, bendPoint.y);
      await expect
        .poll(() =>
          pendingPreview.evaluate((element) => (element as SVGPathElement).getTotalLength()),
        )
        .toBeGreaterThan(1);
      await page.mouse.click(bendPoint.x, bendPoint.y);
      await page.mouse.click(targetPoint.x, targetPoint.y);
      const wire = page.getByTestId('schematic-wire');
      await expect(wire).toHaveCount(1);
      const stableWireId = await wire.getAttribute('data-wire-id');
      if (!stableWireId) throw new Error('created wire has no stable ID');
      await expect(page.getByTestId('wire-vertex')).toHaveCount(1);

      const wirePanel = page.getByTestId('wire-inspector-compact');
      await expect(wirePanel).toBeVisible();
      const colourButtons = wirePanel.locator('.workbench-wire-swatches button');
      await expect(colourButtons).toHaveCount(6);
      const originalColour = await wire.getAttribute('stroke');
      await wirePanel.locator('.workbench-wire-swatches button:not(.active)').first().click();
      await expect.poll(() => wire.getAttribute('stroke')).not.toBe(originalColour);

      const vertex = page.getByTestId('wire-vertex').first();
      const vertexBox = await vertex.boundingBox();
      if (!vertexBox) throw new Error('wire bend is not rendered');
      const originalPath = await wire.getAttribute('d');
      const originalVertex = await vertex.evaluate((node) => ({
        x: Number(node.getAttribute('cx')),
        y: Number(node.getAttribute('cy')),
      }));
      const terminalWorld = async (terminal: Locator) =>
        terminal.evaluate((node) => {
          const transform = node.parentElement?.getAttribute('transform') ?? '';
          const match = /^translate\(([-+0-9.eE]+)[ ,]+([-+0-9.eE]+)\)$/.exec(transform);
          if (!match) throw new Error('terminal overlay has no canonical translate()');
          return { x: Number(match[1]), y: Number(match[2]) };
        });
      const sourceWorld = await terminalWorld(source);
      const targetWorld = await terminalWorld(target);
      const softCanonical = { x: sourceWorld.x, y: targetWorld.y };
      const softCanonicalClient = await page
        .locator('.workbench-canvas')
        .evaluate((node, point) => {
          const svg = node as SVGSVGElement;
          const local = svg.createSVGPoint();
          local.x = point.x;
          local.y = point.y;
          const screen = local.matrixTransform(svg.getScreenCTM()!);
          return { x: screen.x, y: screen.y };
        }, softCanonical);

      await page.mouse.move(vertexBox.x + vertexBox.width / 2, vertexBox.y + vertexBox.height / 2);
      await page.mouse.down();
      await page.mouse.move(softCanonicalClient.x + 4, softCanonicalClient.y + 3, { steps: 12 });
      await expect(page.getByTestId('wire-alignment-guide')).toHaveCount(2);
      await page.mouse.up();
      await expect
        .poll(() =>
          page
            .getByTestId('wire-vertex')
            .first()
            .evaluate((node) => ({
              x: Number(node.getAttribute('cx')),
              y: Number(node.getAttribute('cy')),
            })),
        )
        .toEqual(softCanonical);
      await expect.poll(() => wire.getAttribute('d')).not.toBe(originalPath);

      await page
        .getByRole('button', {
          name: '\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c (Ctrl+Z)',
          exact: true,
        })
        .click();
      await expect
        .poll(() =>
          page
            .getByTestId('wire-vertex')
            .first()
            .evaluate((node) => ({
              x: Number(node.getAttribute('cx')),
              y: Number(node.getAttribute('cy')),
            })),
        )
        .toEqual(originalVertex);

      await page
        .getByRole('button', {
          name: '\u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u044c (Ctrl+Shift+Z)',
          exact: true,
        })
        .click();
      await expect
        .poll(() =>
          page
            .getByTestId('wire-vertex')
            .first()
            .evaluate((node) => ({
              x: Number(node.getAttribute('cx')),
              y: Number(node.getAttribute('cy')),
            })),
        )
        .toEqual(softCanonical);

      await page.evaluate((wireId) => {
        const times: number[] = [];
        (window as unknown as { persistenceWireClickTimes: number[] }).persistenceWireClickTimes =
          times;
        document.addEventListener(
          'pointerdown',
          (event) => {
            const target = event.target instanceof Element ? event.target : null;
            if (target?.closest('[data-wire-id]')?.getAttribute('data-wire-id') === wireId)
              times.push(event.timeStamp);
          },
          { capture: true },
        );
      }, stableWireId);
      const selectWire = async () => {
        const point = await page
          .getByTestId('wire-hit')
          .first()
          .evaluate((element) => {
            const path = element as SVGPathElement;
            const screen = path
              .getPointAtLength(path.getTotalLength() * 0.25)
              .matrixTransform(path.getScreenCTM()!);
            return { x: screen.x, y: screen.y };
          });
        await page.mouse.click(point.x, point.y);
        await expect(wirePanel).toBeVisible();
      };
      const editorVertices = () =>
        page.getByTestId('wire-vertex').evaluateAll((nodes) =>
          nodes.map((node) => ({
            x: Number(node.getAttribute('cx')),
            y: Number(node.getAttribute('cy')),
          })),
        );

      await selectWire();
      const verticesBeforeStraighten = await editorVertices();
      expect(verticesBeforeStraighten).toHaveLength(1);
      await wirePanel.getByRole('button', { name: 'Выпрямить провод', exact: true }).click();
      await expect(page.getByTestId('wire-vertex')).toHaveCount(0);
      await page.getByRole('button', { name: /Отменить/ }).click();

      // This assertion happens before the second select. It catches a broken
      // straighten/Undo independently from the double-click recognizer.
      await expect(page.getByTestId('wire-vertex')).toHaveCount(1);
      const verticesAfterStraightenUndo = await editorVertices();
      expect(verticesAfterStraightenUndo).toEqual(verticesBeforeStraighten);

      // Keep the original rapid select → straighten → Undo → select sequence.
      // The second select itself must not add a vertex.
      await selectWire();
      await expect(page.getByTestId('wire-vertex')).toHaveCount(1);
      expect(await editorVertices()).toEqual(verticesAfterStraightenUndo);
      const quickSelectTimes = await page.evaluate(
        () =>
          (window as unknown as { persistenceWireClickTimes: number[] }).persistenceWireClickTimes,
      );
      expect(quickSelectTimes).toHaveLength(2);
      const quickReselectGapMs = quickSelectTimes[1]! - quickSelectTimes[0]!;
      // Persist the observed interval as evidence without coupling this real-API
      // acceptance to host speed. The focused interaction regression separately
      // proves the interrupted pair inside the 420 ms double-click window.
      await wirePanel.getByRole('button', { name: 'Удалить провод', exact: true }).click();
      await expect(wire).toHaveCount(0);
      await page.getByRole('button', { name: /Отменить/ }).click();
      await expect(wire).toHaveCount(1);
      await expect(wire).toHaveAttribute('data-wire-id', stableWireId);
      // Wire vertices are edit handles and are rendered only for a selected wire.
      // Select it first, then prove that delete -> Undo restored the exact route.
      await selectWire();
      await expect(page.getByTestId('wire-vertex')).toHaveCount(1);
      expect(await editorVertices()).toEqual(verticesAfterStraightenUndo);
      for (const [end, componentId, terminal] of [
        ['from', 'source', 'BAT-'],
        ['to', 'led', 'cathode'],
      ] as const) {
        const handle = page.locator(`[data-testid="wire-endpoint"][data-wire-endpoint="${end}"]`);
        const destination = page.locator(
          `[data-terminal-component-id="${componentId}"][data-terminal-id="${terminal}"]`,
        );
        const before = await handle.boundingBox();
        const target = await destination.boundingBox();
        if (!before || !target) throw new Error('Missing visible reconnect geometry');
        await page.mouse.move(before.x + before.width / 2, before.y + before.height / 2);
        await page.mouse.down();
        await page.mouse.move(target.x + target.width / 2, target.y + target.height / 2, {
          steps: 12,
        });
        await expect(destination.locator('..')).toHaveClass(/drop-target/);
        await page.mouse.up();
        const after = await handle.boundingBox();
        if (!after) throw new Error('Missing reconnected endpoint');
        expect(
          Math.hypot(
            after.x + after.width / 2 - target.x - target.width / 2,
            after.y + after.height / 2 - target.y - target.height / 2,
          ),
        ).toBeLessThanOrEqual(0.5);
        await expect(page.getByTestId('wire-vertex')).toHaveCount(1);
        expect(await editorVertices()).toEqual(verticesAfterStraightenUndo);
      }

      await saveEditorNow(page);
      const readSavedWire = async () => {
        const response = await page.context().request.get(`/api/projects/${projectId}`, {
          headers: { origin: new URL(page.url()).origin },
        });
        expect(response.status()).toBe(200);
        const payload = (await response.json()) as { draft: { document: SchematicDocument } };
        const savedWire = payload.draft.document.connections[0];
        if (!savedWire) throw new Error('saved real-API document has no acceptance wire');
        return savedWire;
      };
      const beforeReload = await readSavedWire();
      expect(beforeReload.id).toBe(stableWireId);
      expect(beforeReload.from).toEqual({ componentId: 'source', terminal: 'BAT-' });
      expect(beforeReload.to).toEqual({ componentId: 'led', terminal: 'cathode' });
      expect(beforeReload.vertices).toEqual(await editorVertices());
      expect(beforeReload.vertices).toHaveLength(1);
      expect(beforeReload.color).toBe(await wire.getAttribute('stroke'));
      await page.screenshot({
        path: `${ARTIFACT_DIR}/r1-r4-wire-persistence-before-reload.png`,
        fullPage: true,
      });

      await page.reload();
      await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
      await expect(page.getByTestId('schematic-wire')).toHaveCount(1);
      await expect(page.getByTestId('schematic-wire')).toHaveAttribute(
        'data-wire-id',
        stableWireId,
      );
      const afterReload = await readSavedWire();
      expect(afterReload.id).toBe(stableWireId);
      expect(afterReload.from).toEqual(beforeReload.from);
      expect(afterReload.to).toEqual(beforeReload.to);
      expect(afterReload.color).toBe(beforeReload.color);
      expect(afterReload.vertices).toEqual(beforeReload.vertices);

      const hit = page.getByTestId('wire-hit').first();
      const hitPoint = await hit.evaluate((element) => {
        const path = element as SVGPathElement;
        const point = path
          .getPointAtLength(path.getTotalLength() * 0.5)
          .matrixTransform(path.getScreenCTM()!);
        return { x: point.x, y: point.y };
      });
      await page.mouse.click(hitPoint.x, hitPoint.y);
      await expect(page.getByTestId('wire-vertex')).toHaveCount(beforeReload.vertices?.length ?? 0);
      expect(await editorVertices()).toEqual(beforeReload.vertices ?? []);
      await expect(page.getByTestId('schematic-wire')).toHaveAttribute(
        'data-wire-id',
        stableWireId,
      );
      await expect(page.getByTestId('schematic-wire')).toHaveAttribute(
        'stroke',
        beforeReload.color!,
      );
      await page.screenshot({
        path: `${ARTIFACT_DIR}/r1-r4-wire-persistence-after-reload.png`,
        fullPage: true,
      });

      failures.assertEmpty();
      const metadataResponse = await page.context().request.get('/build-metadata.json');
      expect(metadataResponse.ok()).toBe(true);
      const build = (await metadataResponse.json()) as { revision: string; builtAt: string };
      const exactHead = build.revision;
      expect(exactHead).toMatch(/^[0-9a-f]{40}$/);
      const requestedHead = process.env['ASA_BUILD_REVISION'] ?? process.env['GITHUB_SHA'];
      if (requestedHead && /^[0-9a-f]{40}$/.test(requestedHead)) {
        expect(exactHead).toBe(requestedHead);
      }
      mkdirSync('reports', { recursive: true });
      writeFileSync(
        'reports/electronics-ux-repair-evidence.json',
        JSON.stringify(
          {
            task: 'TASK-ELECTRONICS-UX-REPAIR-001',
            issue: 377,
            pr: 378,
            exactHead,
            build,
            persistenceStatus: 'passed',
            quickReselectGapMs,
            f3SoftCanonical: softCanonical,
            wireBeforeReload: beforeReload,
            wireAfterReload: afterReload,
            persistenceViewport: page.viewportSize(),
            aggregateStatusSource: 'Complete Playwright run; image paths alone are not acceptance',
            browser: 'chromium',
            browserVersion: page.context().browser()?.version(),
            os: process.platform,
            evidence: {
              R1: [
                'reports/interactions/r1-soft-wire-guide.png',
                'reports/interactions/r1-click-click-connected.png',
                'reports/interactions/r1-shift-orthogonal.png',
                'reports/interactions/r1-mode90-orthogonal.png',
              ],
              R2: [
                'reports/interactions/r2-terminal-scale-4x.png',
                'reports/interactions/r2-dense-terminal-resolver.png',
              ],
              R3: [
                'reports/interactions/r3-touch-drag-preview.png',
                'reports/interactions/r3-touch-direct-placement.png',
                'reports/playwright/**/video.webm',
              ],
              R4: [
                'reports/interactions/r4-wire-panel-desktop.png',
                'reports/interactions/r4-wire-panel-mobile.png',
              ],
              persistence: [
                `${ARTIFACT_DIR}/r1-r4-wire-persistence-before-reload.png`,
                `${ARTIFACT_DIR}/r1-r4-wire-persistence-after-reload.png`,
              ],
              ownerFeedback: {
                F1: [
                  'reports/interactions/f1-marker-zoom-1x.png',
                  'reports/interactions/f1-marker-zoom-2x.png',
                  'reports/interactions/f1-marker-zoom-4x.png',
                  'reports/interactions/r2-dense-terminal-resolver.png',
                ],
                F2: ['reports/interactions/f2-scene-layering.png'],
                F3: [
                  'reports/interactions/f3-bend-soft-lock.png',
                  'reports/playwright/**/video.webm',
                ],
                F4: [
                  'reports/interactions/r4-wire-panel-desktop.png',
                  'reports/interactions/r4-wire-panel-mobile.png',
                ],
              },
            },
            viewports: [
              '320x568',
              '390x844',
              '430x932',
              '768x1024',
              '568x320',
              '844x390',
              '932x430',
              '1024x768',
              '1440x1000',
              '1920x1080',
            ],
            pointerTypes: ['mouse', 'native-cdp-touch'],
          },
          null,
          2,
        ),
        'utf8',
      );
      failures.assertEmpty();
    },
  );
});

async function saveEditorNow(page: Page): Promise<void> {
  // Exercise the mounted editor's immediate safety flush without unloading the
  // test page, so the save response and server document remain observable.
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
    { timeout: 15_000 },
  );
}

async function leaveSavedWorkbench(page: Page, projectId: string): Promise<void> {
  // Do not race pagehide's legitimate autosave with the next API fixture PUT.
  // This is the controller's actual state, not the delayed/transient indicator.
  // Waiting is only between fixture phases, never before local-simulation checks.
  await saveEditorNow(page);
  expect(
    await page.evaluate((id) => localStorage.getItem(`asa-project-local-draft:${id}`), projectId),
  ).toBeNull();
  expect(await e01PendingLocalDraft(page, projectId)).toBeNull();
  await page.goto('/#/projects');
}

const E01_SKETCH = '// E01 pupil original\nvoid setup() {}\nvoid loop() {}';
const E01_CHANGED_SKETCH = '// E01 pupil changed\nvoid setup() {}\nvoid loop() {}';

function e01Document(): SchematicDocument {
  const base = circuitDocument({ switchClosed: false, resistorOhms: 50, reversedLed: false });
  const board = arduinoInputDocument('button').components.find((c) => c.id === 'uno')!;
  return {
    ...base,
    components: [
      ...base.components,
      {
        ...board,
        position: { x: 1100, y: 550 },
        stateProperties: { ...board.stateProperties, arduinoSource: E01_SKETCH },
      },
    ],
  };
}

async function e01LocalDraft(page: Page, projectId: string): Promise<string | null> {
  const me = await page.context().request.get('/api/auth/me');
  const session = (await me.json()) as { authenticated: boolean; user?: { id: string } };
  expect(session.authenticated).toBe(true);
  const key = `asa-project-local-draft:user:account:${encodeURIComponent(session.user!.id)}:${encodeURIComponent(projectId)}`;
  return page.evaluate((key) => localStorage.getItem(key), key);
}

function pendingElectronicsLocalDraft(
  entries: ReadonlyArray<readonly [string, string]>,
  projectId: string,
  userId: string,
): string | null {
  const snapshot = new Map(entries);
  const baseKey = localProjectDraftKey(projectId, userId, 'account');
  const writerPrefix = baseKey + ':electronics-editor:';
  const storage = (withoutAckFor?: string) => ({
    getItem: (key: string) => (key === `${withoutAckFor}:ack` ? null : (snapshot.get(key) ?? null)),
    setItem: () => {
      throw new Error('Recovery evidence is read-only');
    },
    removeItem: () => {
      throw new Error('Recovery evidence is read-only');
    },
  });
  let pending: string | null = null;
  for (const [key, raw] of snapshot) {
    if (key !== baseKey && (!key.startsWith(writerPrefix) || key.endsWith(':ack'))) continue;
    // Validate the actual bytes without their ACK first. Malformed recovery
    // must never be mistaken for a successful acknowledgement.
    expect(
      readLocalProjectDraftEntry(storage(key), projectId, 'electronics', userId, 'account', key)
        ?.raw,
    ).toBe(raw);
    const entry = readLocalProjectDraftEntry(
      storage(),
      projectId,
      'electronics',
      userId,
      'account',
      key,
    );
    if (entry) pending ??= entry.raw;
    else expect(snapshot.get(`${key}:ack`)).toBe(localProjectDraftFingerprint(raw));
  }
  return pending;
}

async function e01PendingLocalDraft(
  page: Page,
  projectId: string,
  userId?: string,
): Promise<string | null> {
  if (userId === undefined) {
    const me = await page.context().request.get('/api/auth/me');
    const session = (await me.json()) as { authenticated: boolean; user?: { id: string } };
    expect(session.authenticated).toBe(true);
    userId = session.user!.id;
  }
  const baseKey = localProjectDraftKey(projectId, userId, 'account');
  const entries = await page.evaluate((baseKey) => {
    const entries: Array<[string, string]> = [];
    for (let index = 0; index < localStorage.length; index++) {
      const key = localStorage.key(index);
      if (
        key !== null &&
        (key === baseKey ||
          key === `${baseKey}:ack` ||
          key.startsWith(`${baseKey}:electronics-editor:`))
      ) {
        const raw = localStorage.getItem(key);
        if (raw !== null) entries.push([key, raw]);
      }
    }
    return entries;
  }, baseKey);
  return pendingElectronicsLocalDraft(entries, projectId, userId);
}

async function e01Server(page: Page, projectId: string) {
  const response = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin: new URL(page.url()).origin },
  });
  expect(response.status()).toBe(200);
  return response.json() as Promise<{ draft: { revision: number; document: SchematicDocument } }>;
}

test('project refresh: no idle polling and focus never overwrites pupil edits', async ({
  page,
}) => {
  const evidenceDir = 'reports/playwright/electronics-project-refresh';
  mkdirSync(evidenceDir, { recursive: true });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Electronics owner point 2 refresh');
  const original = circuitDocument({ switchClosed: false, resistorOhms: 50, reversedLed: false });
  await saveDocument(page, projectId, original);
  const reads: { at: number; method: string }[] = [];
  page.on('request', (request) => {
    if (
      request.method() === 'GET' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}`
    )
      reads.push({ at: Date.now(), method: request.method() });
  });
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await saveEditorNow(page);
  const initialReads = reads.length;
  expect(initialReads).toBeGreaterThanOrEqual(1);
  const audit: Record<string, unknown> = { projectId, initialReads, reads };
  let release: (() => void) | undefined;
  try {
    // Observe three old polling deadlines in real browser time, without changing clocks or timeouts.
    await page.waitForTimeout(10_000);
    audit['idleReads'] = reads.length - initialReads;
    expect(audit['idleReads']).toBe(0);
    const remote = {
      ...original,
      components: original.components.map((part) =>
        part.id === 'resistor' ? { ...part, value: 100 } : part,
      ),
    };
    await saveDocument(page, projectId, remote);
    const cleanResponse = page.waitForResponse(
      (response) =>
        response.request().method() === 'GET' &&
        new URL(response.url()).pathname === `/api/projects/${projectId}`,
    );
    await page.evaluate(() => window.dispatchEvent(new Event('focus')));
    expect((await cleanResponse).status()).toBe(200);
    const value = await e01Resistance(page);
    await expect(value).toHaveValue('100');
    expect(reads.length).toBe(initialReads + 1);
    audit['cleanFocusReads'] = reads.length - initialReads;

    const lateRemote = {
      ...remote,
      components: remote.components.map((part) =>
        part.id === 'resistor' ? { ...part, value: 200 } : part,
      ),
    };
    await saveDocument(page, projectId, lateRemote);
    let captured: (() => void) | undefined;
    const capturedResponse = new Promise<void>((resolve) => {
      captured = resolve;
    });
    const heldResponse = new Promise<void>((resolve) => {
      release = resolve;
    });
    await page.route(`**/api/projects/${projectId}`, async (route) => {
      const response = await route.fetch();
      captured!();
      await heldResponse;
      await route.fulfill({ response });
    });
    await page.evaluate(() => window.dispatchEvent(new Event('focus')));
    await capturedResponse;
    await value.fill('166.7');
    await expect(value).toHaveValue('166.7');
    const localBefore = await e01LocalDraft(page, projectId);
    expect(localBefore).not.toBeNull();
    expect(
      JSON.parse(localBefore!).document.components.find(
        (part: { id: string }) => part.id === 'resistor',
      ).value,
    ).toBe(166.7);
    const lateResponse = page.waitForResponse(
      (response) =>
        response.request().method() === 'GET' &&
        new URL(response.url()).pathname === `/api/projects/${projectId}`,
    );
    release!();
    expect((await lateResponse).status()).toBe(200);
    // Allow the fulfilled fetch and React update to settle before checking preservation.
    await page.waitForTimeout(100);
    await expect(value).toHaveValue('166.7');
    expect(await e01LocalDraft(page, projectId)).toBe(localBefore);
    const beforeDirtyFocus = reads.length;
    await page.evaluate(() => window.dispatchEvent(new Event('focus')));
    await page.waitForTimeout(100);
    expect(reads.length).toBe(beforeDirtyFocus);
    audit['lateAndDirtyFocusReads'] = reads.length - initialReads - 1;
    audit['localBeforeAndAfterEqual'] = (await e01LocalDraft(page, projectId)) === localBefore;
    audit['pupilResistance'] = await value.inputValue();
    await page.screenshot({ path: `${evidenceDir}/pupil-edit-preserved.png`, fullPage: true });
  } finally {
    release?.();
    writeFileSync(`${evidenceDir}/timeline.json`, JSON.stringify(audit, null, 2));
  }
});

async function e01Resistance(page: Page) {
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  return page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]');
}

async function e01EditSketch(page: Page, source: string) {
  await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
  await page.getByLabel('Код Arduino C++', { exact: true }).fill(source);
  await expect(page.getByLabel('Код Arduino C++', { exact: true })).toHaveValue(source);
  await page.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
}

async function e01AffectedToolbarLayouts(
  page: Page,
  evidenceDir: string,
  state: {
    persistenceStatus: 'dirty' | 'error';
    emergencyCopy: boolean;
    running: boolean;
    name: string;
  },
  widths = [1440, 1024, 390, 320, 980, 981, 1280, 1281, 1536, 1537],
) {
  const indicator = page.locator('.workbench-save-state');
  const emergency = page.getByRole('button', { name: 'Получить аварийную копию проекта' });
  const code = page.getByRole('button', { name: 'Закрыть редактор кода', exact: true });
  const save = page.getByRole('button', { name: 'Сохранить проект', exact: true });
  const simulationLabel = state.running ? 'Остановить моделирование' : 'Начать моделирование';
  const simulation = page.getByRole('button', { name: simulationLabel, exact: true });
  const anchor = state.emergencyCopy ? emergency : save;
  const layouts: unknown[] = [];
  // Include both sides of the desktop/mobile and conditional desktop row boundaries.
  for (const width of widths) {
    await page.setViewportSize({ width, height: 900 });
    await anchor.scrollIntoViewIfNeeded();
    const layout = await anchor.evaluate((button) => {
      const box = button.getBoundingClientRect();
      const style = getComputedStyle(button);
      const label = document.createRange();
      label.selectNodeContents(button);
      const labelBox = label.getBoundingClientRect();
      const toolbarButtons = Array.from(button.parentElement!.querySelectorAll('button'))
        .filter((entry) => entry.getClientRects().length > 0)
        .map((entry) => {
          const bounds = entry.getBoundingClientRect();
          const entryStyle = getComputedStyle(entry);
          const caption = document.createRange();
          caption.selectNodeContents(entry);
          const captionBox = caption.getBoundingClientRect();
          const hit = document.elementFromPoint(
            bounds.x + bounds.width / 2,
            bounds.y + bounds.height / 2,
          );
          return {
            label: entry.getAttribute('aria-label'),
            text: entry.textContent?.trim(),
            disabled: entry.disabled,
            pressed: entry.getAttribute('aria-pressed'),
            x: bounds.x,
            y: bounds.y,
            right: bounds.right,
            bottom: bounds.bottom,
            width: bounds.width,
            height: bounds.height,
            unobstructed: hit !== null && entry.contains(hit),
            captionVisible: parseFloat(entryStyle.fontSize) > 0,
            caption: { x: captionBox.x, right: captionBox.right },
            contentLeft:
              bounds.left +
              parseFloat(entryStyle.borderLeftWidth) +
              parseFloat(entryStyle.paddingLeft),
            contentRight:
              bounds.right -
              parseFloat(entryStyle.borderRightWidth) -
              parseFloat(entryStyle.paddingRight),
          };
        });
      const indicator = document.querySelector('.workbench-save-state')!;
      const indicatorBox = indicator.getBoundingClientRect();
      const indicatorStyle = getComputedStyle(indicator);
      const toolbarBox = button.closest('[role="toolbar"]')!.getBoundingClientRect();
      const mainBox = document.querySelector('.workbench-main')!.getBoundingClientRect();
      const hit = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
      return {
        viewport: innerWidth,
        pageWidth: document.documentElement.scrollWidth,
        persistence: {
          controllerStatus: document
            .querySelector('.workbench-main')!
            .getAttribute('data-project-save-status'),
          emergencyCopyPresent: toolbarButtons.some(
            (entry) => entry.label === 'Получить аварийную копию проекта',
          ),
          saveDisabled: toolbarButtons.find((entry) => entry.label === 'Сохранить проект')
            ?.disabled,
          indicator: {
            status: indicator.getAttribute('data-persistence-status'),
            label: indicator.textContent,
            detail: indicator.getAttribute('title'),
            ariaHidden: indicator.getAttribute('aria-hidden'),
            visibility: indicatorStyle.visibility,
            display: indicatorStyle.display,
            box: {
              x: indicatorBox.x,
              y: indicatorBox.y,
              width: indicatorBox.width,
              height: indicatorBox.height,
            },
          },
        },
        box: { x: box.x, y: box.y, width: box.width, height: box.height },
        label: {
          text: button.textContent?.trim(),
          x: labelBox.x,
          right: labelBox.right,
          contentLeft: box.left + parseFloat(style.borderLeftWidth) + parseFloat(style.paddingLeft),
          contentRight:
            box.right - parseFloat(style.borderRightWidth) - parseFloat(style.paddingRight),
        },
        toolbarButtons,
        scene: { top: mainBox.top, bottom: mainBox.bottom, toolbarBottom: toolbarBox.bottom },
        unobstructed: hit !== null && button.contains(hit),
        indicatorOverlap:
          Math.min(box.right, indicatorBox.right) > Math.max(box.left, indicatorBox.left) &&
          Math.min(box.bottom, indicatorBox.bottom) > Math.max(box.top, indicatorBox.top),
      };
    });
    layouts.push({ width, state: state.name, ...layout });
    writeFileSync(
      `${evidenceDir}/after-toolbar-${state.name}.json`,
      JSON.stringify(layouts, null, 2),
    );
    if ([1440, 1024, 390, 320].includes(width))
      await page.screenshot({
        path: `${evidenceDir}/after-local-denial-${state.name === 'error-run' ? '' : `${state.name}-`}${width}.png`,
        fullPage: true,
      });
    // JSON absence means the current document has a local copy, not server confirmation.
    // Capture the real controller/presentation/geometry before any state or layout assertion.
    expect(layout.persistence.controllerStatus).toBe(state.persistenceStatus);
    expect(layout.persistence.emergencyCopyPresent).toBe(state.emergencyCopy);
    expect(layout.persistence.saveDisabled).toBe(false);
    await expect(code).toHaveAttribute('aria-pressed', 'true');
    await expect(simulation).toHaveAttribute('aria-pressed', String(state.running));
    await expect(save).toBeEnabled();
    if (state.emergencyCopy) {
      await expect(emergency).toBeVisible();
      expect(layout.persistence.indicator.status).toBe('error');
      await expect(indicator).toBeVisible();
      expect(layout.persistence.indicator.detail).toMatch(
        /Последние изменения только в открытом редакторе/,
      );
    } else {
      await expect(emergency).toHaveCount(0);
      expect(['quiet', 'dirty']).toContain(layout.persistence.indicator.status);
    }
    const presentation = layout.persistence.indicator;
    if (presentation.status === 'quiet') {
      expect(presentation.visibility).toBe('hidden');
      expect(presentation.ariaHidden).toBe('true');
      expect(presentation.label).toBe('');
      expect(presentation.detail).toBeNull();
    } else {
      expect(presentation.visibility).toBe('visible');
      expect(presentation.display).not.toBe('none');
      expect(presentation.box.width).toBeGreaterThan(0);
      expect(presentation.box.height).toBeGreaterThan(0);
      expect(presentation.ariaHidden).toBeNull();
      if (presentation.status === 'dirty') {
        expect(presentation.label).toBe('Ждёт отправки');
        expect(presentation.detail).toBe(
          'Последние изменения сохранены в этом браузере. Ожидается отправка на сервер.',
        );
      }
    }
    await expect(anchor).toBeVisible();
    expect(layout.box.width).toBeGreaterThan(0);
    expect(layout.box.height).toBeGreaterThan(0);
    expect(layout.box.x).toBeGreaterThanOrEqual(0);
    expect(layout.box.x + layout.box.width).toBeLessThanOrEqual(layout.viewport);
    expect(layout.pageWidth).toBeLessThanOrEqual(layout.viewport);
    expect(layout.unobstructed).toBe(true);
    expect(layout.indicatorOverlap).toBe(false);
    expect(layout.scene.top).toBeGreaterThanOrEqual(layout.scene.toolbarBottom);
    expect(layout.scene.top).toBeLessThanOrEqual(layout.scene.toolbarBottom + 1);
    expect(layout.scene.bottom).toBeLessThanOrEqual(902);
    expect(layout.label.text).toBe(state.emergencyCopy ? 'Копия JSON' : 'Сохранить');
    if (state.emergencyCopy || width > 980) {
      expect(layout.label.x).toBeGreaterThanOrEqual(layout.label.contentLeft - 0.5);
      expect(layout.label.right).toBeLessThanOrEqual(layout.label.contentRight + 0.5);
    }
    for (const [index, button] of layout.toolbarButtons.entries()) {
      expect(button.width).toBeGreaterThan(0);
      if (index > 0)
        expect(button.x).toBeGreaterThanOrEqual(layout.toolbarButtons[index - 1]!.right);
    }
    for (const [label, caption] of [
      ['Закрыть редактор кода', 'Код'],
      ['Сохранить проект', 'Сохранить'],
      [simulationLabel, simulationLabel],
      ...(state.emergencyCopy ? [['Получить аварийную копию проекта', 'Копия JSON']] : []),
    ]) {
      const action = layout.toolbarButtons.find((button) => button.label === label);
      expect(action, `${label} at ${width} in ${state.name}`).toBeDefined();
      expect(action!.text).toBe(caption);
      expect(action!.x).toBeGreaterThanOrEqual(0);
      expect(action!.right).toBeLessThanOrEqual(layout.viewport);
      expect(action!.y).toBeGreaterThanOrEqual(0);
      expect(action!.height).toBeGreaterThan(0);
      expect(action!.bottom).toBeLessThanOrEqual(900);
      expect(action!.unobstructed).toBe(true);
      // Existing mobile actions intentionally show icons and retain full accessible names.
      if (width > 980 || label === 'Получить аварийную копию проекта') {
        expect(action!.captionVisible).toBe(true);
        expect(action!.caption.x).toBeGreaterThanOrEqual(action!.contentLeft - 0.5);
        expect(action!.caption.right).toBeLessThanOrEqual(action!.contentRight + 0.5);
      }
      if (!action!.disabled)
        await page.getByRole('button', { name: label, exact: true }).click({ trial: true });
    }
    const wireSummary = page.locator('summary[aria-label="Цвет провода"]');
    if (width > 980 && (await wireSummary.count()) > 0) {
      const swatch = page.getByRole('menuitemradio', { name: 'Цвет провода: Фиолетовый' });
      await wireSummary.click();
      await expect(page.getByRole('menu').filter({ has: swatch })).toBeVisible();
      await swatch.click({ trial: true });
      await wireSummary.click();
    }
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  return layouts;
}

test('ELECTRONICS-E01 AFTER denied local storage never claims a durable local copy', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const evidenceDir = 'reports/playwright/electronics-e01';
  mkdirSync(evidenceDir, { recursive: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'E01 denied local copy');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  const value = page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]');
  await expect(value).toHaveValue('50');
  const beforeDenialLocal = await e01LocalDraft(page, projectId);
  expect(beforeDenialLocal).not.toBeNull();
  const olderCopy = JSON.parse(beforeDenialLocal!) as {
    schemaVersion: number;
    identityKind: string;
    projectId: string;
    moduleKey: string;
    document: SchematicDocument;
  };
  expect(olderCopy).toMatchObject({
    schemaVersion: 3,
    identityKind: 'account',
    projectId,
    moduleKey: 'electronics',
  });
  expect(olderCopy.document.components.find((c) => c.id === 'resistor')?.value).toBe(50);
  expect(
    olderCopy.document.components.find((c) => c.id === 'uno')?.stateProperties?.['arduinoSource'],
  ).toBe(E01_SKETCH);
  await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
  const localDraftRunLayouts = await e01AffectedToolbarLayouts(page, evidenceDir, {
    persistenceStatus: 'dirty',
    emergencyCopy: false,
    running: false,
    name: 'local-draft-run',
  });
  const localDraftAffectedViewLayouts: unknown[] = [];
  for (const view of ['Схемы', 'Компоненты']) {
    await page.getByRole('button', { name: view, exact: true }).click();
    localDraftAffectedViewLayouts.push(
      ...(await e01AffectedToolbarLayouts(
        page,
        evidenceDir,
        {
          persistenceStatus: 'dirty',
          emergencyCopy: false,
          running: false,
          name: `local-draft-${view}-run`,
        },
        [1440, 1024, 390, 320],
      )),
    );
  }
  await page.getByRole('button', { name: 'Цепи', exact: true }).click();
  await page.getByRole('button', { name: 'Начать моделирование', exact: true }).click();
  const localDraftStopLayouts = await e01AffectedToolbarLayouts(page, evidenceDir, {
    persistenceStatus: 'dirty',
    emergencyCopy: false,
    running: true,
    name: 'local-draft-stop',
  });
  await page.getByRole('button', { name: 'Остановить моделирование', exact: true }).click();
  await page.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
  expect(await e01LocalDraft(page, projectId)).toBe(beforeDenialLocal);
  await page.evaluate(() => {
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = function (key, value) {
      if (key.startsWith('asa-project-local-draft:'))
        throw new DOMException('E01 controlled local storage denial', 'QuotaExceededError');
      original.call(this, key, value);
    };
  });
  const requests: unknown[] = [];
  page.on('requestfailed', (request) => {
    if (new URL(request.url()).pathname === `/api/projects/${projectId}/draft`)
      requests.push({
        at: Date.now(),
        method: request.method(),
        body: request.postDataJSON(),
        failure: request.failure(),
      });
  });
  await page.route(`**/api/projects/${projectId}/draft`, (route) =>
    route.abort('internetdisconnected'),
  );
  await e01EditSketch(page, E01_CHANGED_SKETCH);
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  await value.fill('166.7');
  await expect(value).toHaveValue('166.7');
  await expect(
    page.getByRole('button', { name: 'Получить аварийную копию проекта' }),
  ).toBeVisible();
  const beforeSaveDownload = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Получить аварийную копию проекта' }).click();
  await (await beforeSaveDownload).saveAs(`${evidenceDir}/after-before-server-attempt.json`);
  const beforeAttemptCopy = JSON.parse(
    readFileSync(`${evidenceDir}/after-before-server-attempt.json`, 'utf8'),
  ) as SchematicDocument;
  expect(beforeAttemptCopy.components.find((c) => c.id === 'resistor')?.value).toBe(166.7);
  expect(
    beforeAttemptCopy.components.find((c) => c.id === 'uno')?.stateProperties?.['arduinoSource'],
  ).toBe(E01_CHANGED_SKETCH);
  expect(beforeAttemptCopy).not.toEqual(olderCopy.document);
  expect(requests).toEqual([]);
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'error',
  );
  await expect.poll(() => requests.length).toBe(1);
  const indicator = page.locator('.workbench-save-state');
  await expect(indicator).toHaveAttribute('data-persistence-status', 'error');
  const server = await page
    .context()
    .request.get(`/api/projects/${projectId}`, { headers: { origin: new URL(page.url()).origin } });
  expect(server.ok()).toBe(true);
  const serverPayload = (await server.json()) as { draft: { document: SchematicDocument } };
  expect(serverPayload.draft.document.components.find((c) => c.id === 'resistor')?.value).toBe(50);
  expect(
    serverPayload.draft.document.components.find((c) => c.id === 'uno')?.stateProperties?.[
      'arduinoSource'
    ],
  ).toBe(E01_SKETCH);
  const local = await e01LocalDraft(page, projectId);
  writeFileSync(
    `${evidenceDir}/after-local-denial.json`,
    JSON.stringify(
      {
        projectId,
        requests,
        beforeDenialLocal,
        beforeAttemptCopy,
        local,
        server: serverPayload,
        dom: {
          status: await page.locator('.workbench-main').getAttribute('data-project-save-status'),
          label: await indicator.textContent(),
          detail: await indicator.getAttribute('title'),
          resistor: await value.inputValue(),
        },
      },
      null,
      2,
    ),
  );
  await page.screenshot({ path: `${evidenceDir}/after-local-denial-1440.png`, fullPage: true });
  expect(local).toBe(beforeDenialLocal);
  await expect(indicator).toHaveAttribute(
    'title',
    /Последние изменения только в открытом редакторе/,
  );
  const download = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Получить аварийную копию проекта' }).click();
  const downloaded = await download;
  const copyPath = `${evidenceDir}/after-emergency-document.json`;
  await downloaded.saveAs(copyPath);
  const copy = JSON.parse(readFileSync(copyPath, 'utf8')) as SchematicDocument;
  expect(copy.components.find((c) => c.id === 'resistor')?.value).toBe(166.7);
  expect(copy.components.find((c) => c.id === 'uno')?.stateProperties?.['arduinoSource']).toBe(
    E01_CHANGED_SKETCH,
  );
  expect(copy.connections).toEqual(e01Document().connections);
  expect(copy).toEqual(beforeAttemptCopy);
  await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
  const layouts = await e01AffectedToolbarLayouts(page, evidenceDir, {
    persistenceStatus: 'error',
    emergencyCopy: true,
    running: false,
    name: 'error-run',
  });
  const errorAffectedViewLayouts: unknown[] = [];
  for (const view of ['Схемы', 'Компоненты']) {
    await page.getByRole('button', { name: view, exact: true }).click();
    errorAffectedViewLayouts.push(
      ...(await e01AffectedToolbarLayouts(
        page,
        evidenceDir,
        {
          persistenceStatus: 'error',
          emergencyCopy: true,
          running: false,
          name: `error-${view}-run`,
        },
        [1440, 1024, 390, 320],
      )),
    );
  }
  await page.getByRole('button', { name: 'Цепи', exact: true }).click();
  await page.getByRole('button', { name: 'Начать моделирование', exact: true }).click();
  const errorStopLayouts = await e01AffectedToolbarLayouts(page, evidenceDir, {
    persistenceStatus: 'error',
    emergencyCopy: true,
    running: true,
    name: 'error-stop',
  });
  await page.getByRole('button', { name: 'Остановить моделирование', exact: true }).click();
  await page.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
  await expect(value).toHaveValue('166.7');
  await expect(indicator).not.toHaveAttribute(
    'title',
    /сохранена на этом устройстве|сохранены в браузере/,
  );
  const receipt = JSON.parse(
    readFileSync(`${evidenceDir}/after-local-denial.json`, 'utf8'),
  ) as Record<string, unknown>;
  writeFileSync(
    `${evidenceDir}/after-local-denial.json`,
    JSON.stringify(
      {
        ...receipt,
        requests,
        emergencyCopy: copy,
        layouts,
        localDraftRunLayouts,
        localDraftStopLayouts,
        errorStopLayouts,
        localDraftAffectedViewLayouts,
        errorAffectedViewLayouts,
      },
      null,
      2,
    ),
  );
});

test('ELECTRONICS-E01 AFTER latest failed save recovers quietly without another edit', async ({
  page,
  browser,
}) => {
  test.setTimeout(120_000);
  const evidenceDir = 'reports/playwright/electronics-e01';
  mkdirSync(evidenceDir, { recursive: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'E01 quiet network recovery');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  const value = page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]');
  await expect(value).toHaveValue('50');
  const requests: unknown[] = [];
  const replies: unknown[] = [];
  page.on('request', (request) => {
    if (
      request.method() === 'PUT' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
    )
      requests.push({ at: Date.now(), body: request.postDataJSON() });
  });
  page.on('response', (response) => {
    if (
      response.request().method() === 'PUT' &&
      new URL(response.url()).pathname === `/api/projects/${projectId}/draft`
    )
      replies.push({ at: Date.now(), status: response.status() });
  });
  await page.route(`**/api/projects/${projectId}/draft`, (route) =>
    route.abort('internetdisconnected'),
  );
  await e01EditSketch(page, E01_CHANGED_SKETCH);
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  await value.fill('166.7');
  await expect(value).toHaveValue('166.7');
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'error',
  );
  expect(requests).toHaveLength(1);
  await page.unroute(`**/api/projects/${projectId}/draft`);
  const transportRestoredAt = Date.now();
  try {
    // Real browser time, no focus/online event, page reload, clock injection or new edit.
    await expect
      .poll(() => replies.filter((reply) => (reply as { status: number }).status === 200).length, {
        timeout: 70_000,
        intervals: [1_000],
      })
      .toBe(1);
  } finally {
    const server = await page.context().request.get(`/api/projects/${projectId}`, {
      headers: { origin: new URL(page.url()).origin },
    });
    expect(server.ok()).toBe(true);
    writeFileSync(
      `${evidenceDir}/after-quiet-recovery.json`,
      JSON.stringify(
        {
          projectId,
          transportRestoredAt,
          capturedAt: Date.now(),
          requests,
          replies,
          local: await e01LocalDraft(page, projectId),
          server: await server.json(),
          dom: {
            status: await page.locator('.workbench-main').getAttribute('data-project-save-status'),
            detail: await page.locator('.workbench-save-state').getAttribute('title'),
            resistor: await value.inputValue(),
          },
        },
        null,
        2,
      ),
    );
    await page.screenshot({
      path: `${evidenceDir}/after-quiet-recovery-1440.png`,
      fullPage: true,
    });
  }
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const confirmed = await e01Server(page, projectId);
  expect(confirmed.draft.document.components.find((c) => c.id === 'resistor')?.value).toBe(166.7);
  expect(
    confirmed.draft.document.components.find((c) => c.id === 'uno')?.stateProperties?.[
      'arduinoSource'
    ],
  ).toBe(E01_CHANGED_SKETCH);
  expect(confirmed.draft.revision).toBeGreaterThan(1);
  const profile = await browser.newContext({ baseURL: new URL(page.url()).origin });
  try {
    const independent = await profile.newPage();
    await loginWithOrganization(independent, teacher);
    expect(await e01LocalDraft(independent, projectId)).toBeNull();
    await independent.goto(`/#/home/${projectId}`);
    await expect(await e01Resistance(independent)).toHaveValue('166.7');
    await independent.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(independent.getByLabel('Код Arduino C++', { exact: true })).toHaveValue(
      E01_CHANGED_SKETCH,
    );
    writeFileSync(
      `${evidenceDir}/after-second-profile.json`,
      JSON.stringify(
        {
          projectId,
          server: await e01Server(independent, projectId),
          local: await e01LocalDraft(independent, projectId),
          sketch: await independent.getByLabel('Код Arduino C++', { exact: true }).inputValue(),
        },
        null,
        2,
      ),
    );
  } finally {
    try {
      await profile.request.post('/api/auth/logout', {
        headers: { origin: new URL(page.url()).origin },
      });
    } finally {
      await profile.close();
    }
  }
});

test('ELECTRONICS-E01 SAV02/08 restores the attributed schema and sketch after a renderer crash', async ({
  page,
  browser,
}) => {
  test.setTimeout(120_000);
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'E01 crash recovery');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  const safetySubmissions: unknown[] = [];
  page.on('request', (request) => {
    if (
      request.method() === 'PUT' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
    )
      safetySubmissions.push({ at: Date.now(), body: request.postDataJSON() });
  });
  await e01EditSketch(page, E01_CHANGED_SKETCH);
  await (await e01Resistance(page)).fill('177.7');
  const local = JSON.parse((await e01LocalDraft(page, projectId))!);
  expect(local.document.components.find((c: { id: string }) => c.id === 'resistor').value).toBe(
    177.7,
  );
  expect(
    local.document.components.find((c: { id: string }) => c.id === 'uno').stateProperties
      .arduinoSource,
  ).toBe(E01_CHANGED_SKETCH);
  expect(
    (await e01Server(page, projectId)).draft.document.components.find((c) => c.id === 'resistor')
      ?.value,
  ).toBe(50);
  const lifecycle: string[] = [];
  page.on('console', (message) => {
    if (message.text() === 'E01 pagehide') lifecycle.push('pagehide');
  });
  await page.evaluate(() => window.addEventListener('pagehide', () => console.log('E01 pagehide')));
  // The pinned Linux runner's fatal/debug-URL path stalled before termination.
  // Bind this editor's unique timing mark to its own renderer, then terminate
  // only that verified process. A signal alone still does not prove a crash.
  const browserCdp = await browser.newBrowserCDPSession();
  const version = await browserCdp.send('Browser.getVersion');
  const marker = `e01-current-editor-${Date.now()}-${process.pid}`;
  const traceEvents: Array<Record<string, string>> = [];
  let markerEvents: Array<Record<string, string>> = [];
  let mappedPids: number[] = [];
  let traceDataLoss: boolean | null = null;
  let browserPid: number | undefined;
  let observedCrashAt: number | null = null;
  const freshAncestry: Array<{ pid: number; parentPid: number; namespacePids: string }> = [];
  const injectionOutcome: {
    status: string;
    method: string;
    signal: string;
    rendererPid?: number;
    at?: number;
    signalAccepted?: boolean;
    error?: string;
  } = { status: 'not-attempted', method: 'own-page-renderer-signal', signal: 'SIGKILL' };
  const writeInjectionEvidence = () => {
    mkdirSync('reports/playwright/electronics-e01', { recursive: true });
    writeFileSync(
      'reports/playwright/electronics-e01/renderer-crash-injection.json',
      JSON.stringify(
        {
          version,
          marker,
          markerEvents,
          mappedPids,
          traceDataLoss,
          browserPid,
          freshAncestry,
          observedCrashAt,
          injectionOutcome,
          lifecycle,
          safetySubmissions,
        },
        null,
        2,
      ),
    );
  };
  writeInjectionEvidence();
  try {
    browserCdp.on('Tracing.dataCollected', (event) => traceEvents.push(...event.value));
    const traceComplete = new Promise<{ dataLossOccurred: boolean }>((resolve) =>
      browserCdp.once('Tracing.tracingComplete', resolve),
    );
    await browserCdp.send('Tracing.start', {
      categories: 'blink.user_timing',
      transferMode: 'ReportEvents',
    });
    await page.evaluate((name) => performance.mark(name), marker);
    await browserCdp.send('Tracing.end');
    traceDataLoss = (await traceComplete).dataLossOccurred;
    markerEvents = traceEvents.filter(
      (event) => event.name === marker && event.cat?.split(',').includes('blink.user_timing'),
    );
    mappedPids = [...new Set(markerEvents.map((event) => Number(event.pid)))];
    writeInjectionEvidence();
    expect(traceDataLoss).toBe(false);
    expect(mappedPids).toHaveLength(1);
    const rendererPid = mappedPids[0]!;
    expect(process.platform).toBe('linux');
    expect(Number.isSafeInteger(rendererPid) && rendererPid > 1).toBe(true);
    expect(rendererPid).not.toBe(process.pid);
    const { processInfo } = await browserCdp.send('SystemInfo.getProcessInfo');
    browserPid = processInfo.find((entry) => entry.type === 'browser')?.id;
    expect(Number.isSafeInteger(browserPid) && browserPid! > 1).toBe(true);
    expect(rendererPid).not.toBe(browserPid);
    expect(processInfo.some((entry) => entry.type === 'renderer' && entry.id === rendererPid)).toBe(
      true,
    );
    writeInjectionEvidence();
    // Read only the identified renderer's fresh ancestry, never a global scan.
    // No await follows this guard before the single signal.
    let owned = false;
    for (let ancestor = rendererPid, depth = 0; depth < 12; depth += 1) {
      const status = readFileSync(`/proc/${ancestor}/status`, 'utf8');
      const parentPid = Number(/^PPid:\s*(\d+)$/m.exec(status)?.[1]);
      const namespacePids = /^NSpid:\s*(.+)$/m.exec(status)?.[1]?.trim() ?? '';
      freshAncestry.push({ pid: ancestor, parentPid, namespacePids });
      expect(namespacePids).toBe(String(ancestor));
      if (ancestor === browserPid) {
        owned = true;
        break;
      }
      expect(Number.isSafeInteger(parentPid) && parentPid > 1 && parentPid !== ancestor).toBe(true);
      ancestor = parentPid;
    }
    expect(owned).toBe(true);
    const crash = page.waitForEvent('crash');
    void crash.catch(() => undefined); // Do not orphan the waiter if the signal fails.
    injectionOutcome.rendererPid = rendererPid;
    injectionOutcome.at = Date.now();
    injectionOutcome.status = 'attempting';
    injectionOutcome.signalAccepted = process.kill(rendererPid, 'SIGKILL');
    injectionOutcome.status = 'signal-sent';
    expect(await crash).toBe(page);
    observedCrashAt = Date.now();
  } catch (error) {
    injectionOutcome.error = String(error);
    throw error;
  } finally {
    writeInjectionEvidence();
  }
  await expect(page.evaluate(() => document.title)).rejects.toThrow(/crash/i);
  expect(lifecycle).toEqual([]);
  expect(safetySubmissions).toEqual([]);
  const reopened = await page.context().newPage();
  await reopened.goto(`/#/home/${projectId}`);
  await expect(await e01Resistance(reopened)).toHaveValue('177.7');
  const recoveredLocal = JSON.parse((await e01LocalDraft(reopened, projectId))!);
  expect(recoveredLocal.document).toEqual(local.document);
  await reopened.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
  await expect(reopened.getByLabel('Код Arduino C++', { exact: true })).toHaveValue(
    E01_CHANGED_SKETCH,
  );
  await reopened.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
  await reopened.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(reopened.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const server = await e01Server(reopened, projectId);
  expect(server.draft.document.components.find((c) => c.id === 'resistor')?.value).toBe(177.7);
  expect(
    server.draft.document.components.find((c) => c.id === 'uno')?.stateProperties?.[
      'arduinoSource'
    ],
  ).toBe(E01_CHANGED_SKETCH);
  expect(server.draft.document).toEqual(local.document);
  mkdirSync('reports/playwright/electronics-e01', { recursive: true });
  writeFileSync(
    'reports/playwright/electronics-e01/after-renderer-crash.json',
    JSON.stringify(
      {
        projectId,
        local,
        recoveredLocal,
        lifecycle,
        injectionOutcome,
        safetySubmissions,
        crash: true,
        server,
      },
      null,
      2,
    ),
  );
  await reopened.close();
});

test('ELECTRONICS-E01 SAV04 reauthenticates the same actor and restores only its attributed work', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'E01 expired session');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  await e01EditSketch(page, E01_CHANGED_SKETCH);
  await (await e01Resistance(page)).fill('188.8');
  const before = await e01LocalDraft(page, projectId);
  await page.context().clearCookies();
  const puts: string[] = [];
  page.on('request', (request) => {
    if (
      request.method() === 'PUT' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
    )
      puts.push(request.url());
  });
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-save-state')).toHaveText('Нужно войти');
  expect(puts).toEqual([]);
  await loginWithOrganization(page, teacher);
  await page.goto(`/#/home/${projectId}`);
  await expect(await e01Resistance(page)).toHaveValue('188.8');
  await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
  await expect(page.getByLabel('Код Arduino C++', { exact: true })).toHaveValue(E01_CHANGED_SKETCH);
  await page.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const server = await e01Server(page, projectId);
  expect(server.draft.document.components.find((c) => c.id === 'resistor')?.value).toBe(188.8);
  expect(
    server.draft.document.components.find((c) => c.id === 'uno')?.stateProperties?.[
      'arduinoSource'
    ],
  ).toBe(E01_CHANGED_SKETCH);
  mkdirSync('reports/playwright/electronics-e01', { recursive: true });
  writeFileSync(
    'reports/playwright/electronics-e01/after-reauth.json',
    JSON.stringify({ projectId, before, puts, server }, null, 2),
  );
});

test('ELECTRONICS-E01 SAV05/09 keeps the latest edit local after a late reply and serializes departure', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'E01 late response and leave');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  const input = await e01Resistance(page);
  let release!: () => void;
  let received!: () => void;
  let gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  let reached = new Promise<void>((resolve) => {
    received = resolve;
  });
  const requests: unknown[] = [];
  let held = false;
  await page.route(`**/api/projects/${projectId}/draft`, async (route) => {
    requests.push(route.request().postDataJSON());
    const response = await route.fetch();
    if (!held) {
      held = true;
      received();
      await gate;
    }
    await route.fulfill({ response });
  });
  await input.fill('111.1');
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await reached;
  await input.fill('222.2');
  release();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'dirty',
  );
  expect(
    JSON.parse((await e01LocalDraft(page, projectId))!).document.components.find(
      (c: { id: string }) => c.id === 'resistor',
    ).value,
  ).toBe(222.2);
  expect(
    (await e01Server(page, projectId)).draft.document.components.find((c) => c.id === 'resistor')
      ?.value,
  ).toBe(111.1);
  held = false;
  gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  reached = new Promise<void>((resolve) => {
    received = resolve;
  });
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await reached;
  await e01EditSketch(page, E01_CHANGED_SKETCH);
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  await input.fill('333.3');
  await page.getByRole('button', { name: 'ASA Lab', exact: true }).click();
  release();
  await expect(page).toHaveURL(/\/#\/home$/);
  const server = await e01Server(page, projectId);
  expect(server.draft.document.components.find((c) => c.id === 'resistor')?.value).toBe(333.3);
  expect(
    server.draft.document.components.find((c) => c.id === 'uno')?.stateProperties?.[
      'arduinoSource'
    ],
  ).toBe(E01_CHANGED_SKETCH);
  expect(requests).toHaveLength(3);
  mkdirSync('reports/playwright/electronics-e01', { recursive: true });
  writeFileSync(
    'reports/playwright/electronics-e01/after-late-reply-departure.json',
    JSON.stringify({ projectId, requests, server }, null, 2),
  );
});

test('ELECTRONICS-E01 SAV10 isolates real projects and accounts while old save replies are pending', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const evidenceDir = 'reports/playwright/electronics-e01';
  mkdirSync(evidenceDir, { recursive: true });
  await loginWithOrganization(page, teacher);
  const actor = async () => {
    const response = await page.context().request.get('/api/auth/me');
    expect(response.status()).toBe(200);
    const session = (await response.json()) as {
      authenticated: boolean;
      user: { id: string; email: string; displayName: string };
    };
    expect(session.authenticated).toBe(true);
    return session.user;
  };
  const actorA = await actor();
  expect(actorA.email).toBe(teacher.email);
  const firstProject = await createProject(page, 'E01 SAV10 A first');
  const secondProject = await createProject(page, 'E01 SAV10 A second');
  await saveDocument(page, firstProject, e01Document());
  const secondDocument = e01Document();
  secondDocument.components = secondDocument.components.map((c) =>
    c.id === 'resistor' ? { ...c, value: 70 } : c,
  );
  await saveDocument(page, secondProject, secondDocument);
  const localKey = (userId: string, projectId: string) =>
    `asa-project-local-draft:user:account:${encodeURIComponent(userId)}:${encodeURIComponent(projectId)}`;
  const local = async (userId: string, projectId: string) => {
    const key = localKey(userId, projectId);
    const raw = await page.evaluate((key) => localStorage.getItem(key), key);
    if (raw === null) return { key, raw, record: null };
    const record = JSON.parse(raw) as {
      schemaVersion: number;
      identityKind: string;
      userId: string;
      projectId: string;
      moduleKey: string;
      document: SchematicDocument;
    };
    expect(record).toMatchObject({
      schemaVersion: 3,
      identityKind: 'account',
      userId,
      projectId,
      moduleKey: 'electronics',
    });
    return { key, raw, record };
  };
  const assertContent = (document: SchematicDocument, resistance: number, sketch: string) => {
    expect(document.components.find((c) => c.id === 'resistor')?.value).toBe(resistance);
    expect(
      document.components.find((c) => c.id === 'uno')?.stateProperties?.['arduinoSource'],
    ).toBe(sketch);
    expect(document.connections).toEqual(e01Document().connections);
    expect(document.components.map((c) => c.id)).toEqual(e01Document().components.map((c) => c.id));
  };
  const ui = async (target: Page, resistance: string, sketch: string, expectedActor = actorA) => {
    await expect(target.locator('.workbench-avatar')).toHaveAttribute(
      'title',
      expectedActor.displayName,
    );
    await expect(await e01Resistance(target)).toHaveValue(resistance);
    await target.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(target.getByLabel('Код Arduino C++', { exact: true })).toHaveValue(sketch);
    await target.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
    return {
      url: target.url(),
      resistance,
      sketch,
      principalLabel: await target.locator('.workbench-avatar').getAttribute('aria-label'),
      status: await target.locator('.workbench-main').getAttribute('data-project-save-status'),
    };
  };
  let phase = 'actor-A';
  const requests: unknown[] = [];
  const heldReplies: unknown[] = [];
  const holdReply = async (projectId: string) => {
    let release!: () => void;
    let received!: () => void;
    let delivered!: () => void;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    const reached = new Promise<void>((resolve) => {
      received = resolve;
    });
    const finished = new Promise<void>((resolve) => {
      delivered = resolve;
    });
    let first = true;
    await page.route(`**/api/projects/${projectId}/draft`, async (route) => {
      const identity = await actor();
      const request = {
        phase,
        at: Date.now(),
        projectId,
        actor: identity,
        body: route.request().postDataJSON(),
      };
      requests.push(request);
      const response = await route.fetch();
      expect(response.status()).toBe(200);
      if (first) {
        first = false;
        const serverResponse: unknown = await response.json();
        received();
        await gate;
        await route.fulfill({ response });
        heldReplies.push({
          request,
          serverResponse,
          deliveryPhase: phase,
          deliveredAt: Date.now(),
          outcome: 'delivered',
        });
        delivered();
      } else await route.fulfill({ response });
    });
    return { reached, release, finished };
  };
  const oldBrowserPuts: Array<{ phase: string; projectId: string; body: unknown }> = [];
  page.on('request', (request) => {
    const path = new URL(request.url()).pathname;
    if (request.method() === 'PUT' && path.endsWith('/draft'))
      oldBrowserPuts.push({ phase, projectId: path.split('/')[3]!, body: request.postDataJSON() });
  });
  await page.goto(`/#/home/${firstProject}`);
  await expect(page).toHaveURL(
    new RegExp(`/projects/${firstProject}/electronics/edit\\?returnTo=%23%2Fhome$`),
  );
  await expect(page.getByLabel('Название проекта', { exact: true })).toHaveValue(
    'E01 SAV10 A first',
  );
  const firstEditorUrl = page.url();
  const sameRendererTimeOrigin = await page.evaluate(() => performance.timeOrigin);
  // Prepare a real same-document Forward entry before any pending save.
  // A hash alone cannot override the first editor's canonical pathname.
  await page.evaluate((id) => {
    const index = Number(window.history.state?.asaRouteIndex ?? 0);
    window.history.pushState(
      { ...window.history.state, asaRouteIndex: index + 1 },
      '',
      `/projects/${encodeURIComponent(id)}/electronics/edit?returnTo=%23%2Fhome`,
    );
    window.history.back();
  }, secondProject);
  await expect(page).toHaveURL(firstEditorUrl);
  await expect(page.getByLabel('Название проекта', { exact: true })).toHaveValue(
    'E01 SAV10 A first',
  );
  const projectReply = await holdReply(firstProject);
  const firstSketch = `${E01_CHANGED_SKETCH}\n// first project sent`;
  const latestFirstSketch = `${E01_CHANGED_SKETCH}\n// first project latest`;
  await e01EditSketch(page, firstSketch);
  await (await e01Resistance(page)).fill('111.1');
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await projectReply.reached;
  const committedFirst = await e01Server(page, firstProject);
  assertContent(committedFirst.draft.document, 111.1, firstSketch);
  await e01EditSketch(page, latestFirstSketch);
  await (await e01Resistance(page)).fill('222.2');
  const beforeProjectSwitch = await local(actorA.id, firstProject);
  assertContent(beforeProjectSwitch.record!.document, 222.2, latestFirstSketch);
  // Native history traversal delivers the canonical route without a reload,
  // synthetic route event, or abandoning the held first-project response.
  await page.evaluate(() => window.history.forward());
  await expect(page).toHaveURL(
    new RegExp(`/projects/${secondProject}/electronics/edit\\?returnTo=%23%2Fhome$`),
  );
  await expect(page.getByLabel('Название проекта', { exact: true })).toHaveValue(
    'E01 SAV10 A second',
  );
  const afterSwitchTimeOrigin = await page.evaluate(() => performance.timeOrigin);
  expect(afterSwitchTimeOrigin).toBe(sameRendererTimeOrigin);
  expect(heldReplies).toEqual([]);
  const secondBeforeReply = await ui(page, '70', E01_SKETCH);
  const secondServerBeforeReply = await e01Server(page, secondProject);
  phase = 'actor-A-second-project';
  projectReply.release();
  await projectReply.finished;
  const secondAfterReply = await ui(page, '70', E01_SKETCH);
  expect(secondAfterReply).toEqual(secondBeforeReply);
  expect(await e01Server(page, secondProject)).toEqual(secondServerBeforeReply);
  const afterProjectSwitch = await local(actorA.id, firstProject);
  expect(afterProjectSwitch.raw).toBe(beforeProjectSwitch.raw);

  const accountReply = await holdReply(secondProject);
  const sentSecondSketch = `${E01_CHANGED_SKETCH}\n// second project sent`;
  const latestSecondSketch = `${E01_CHANGED_SKETCH}\n// second project latest`;
  await e01EditSketch(page, sentSecondSketch);
  await (await e01Resistance(page)).fill('333.3');
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await accountReply.reached;
  const committedSecond = await e01Server(page, secondProject);
  assertContent(committedSecond.draft.document, 333.3, sentSecondSketch);
  await e01EditSketch(page, latestSecondSketch);
  await (await e01Resistance(page)).fill('444.4');
  const beforeAccountSwitch = await local(actorA.id, secondProject);
  assertContent(beforeAccountSwitch.record!.document, 444.4, latestSecondSketch);
  const otherTeacher = await seedTeacher(admin, 'e2e-electronics-sav10-other-actor');
  const other = await page.context().newPage();
  try {
    // Real logout revokes the old page through the existing session channel;
    // its editor must stay unmounted while its old reply is delivered later.
    await other.goto('/#/home');
    await other
      .getByRole('banner')
      .getByLabel(/^Меню аккаунта /)
      .click();
    await other.getByRole('button', { name: 'Выход', exact: true }).click();
    await expect(
      other.getByRole('banner').getByRole('button', { name: 'Войти', exact: true }),
    ).toBeVisible();
    const revokedUi = async () => {
      await expect(
        page.getByRole('banner').getByRole('button', { name: 'Войти', exact: true }),
      ).toBeVisible();
      await expect(page.locator('.workbench-main')).toHaveCount(0);
      await expect(page.getByLabel('Код Arduino C++', { exact: true })).toHaveCount(0);
      await expect(page.getByRole('button', { name: 'Сохранить проект', exact: true })).toHaveCount(
        0,
      );
      return { url: page.url(), loginVisible: true, editorCount: 0, codeCount: 0, saveCount: 0 };
    };
    const oldUiAfterLogout = await revokedUi();
    const oldLocalAfterLogout = await local(actorA.id, secondProject);
    expect(oldLocalAfterLogout.raw).toBe(beforeAccountSwitch.raw);
    assertContent(oldLocalAfterLogout.record!.document, 444.4, latestSecondSketch);
    await loginWithOrganization(other, otherTeacher);
    const actorB = await actor();
    expect(actorB.email).toBe(otherTeacher.email);
    expect(actorB.id).not.toBe(actorA.id);
    phase = 'actor-B';
    const newProject = await createProject(other, 'E01 SAV10 B project');
    await saveDocument(other, newProject, e01Document());
    await other.goto(`/#/home/${newProject}`);
    const newSketch = `${E01_CHANGED_SKETCH}\n// different account`;
    await e01EditSketch(other, newSketch);
    await (await e01Resistance(other)).fill('888.8');
    const newLocalBefore = await local(actorB.id, newProject);
    assertContent(newLocalBefore.record!.document, 888.8, newSketch);
    await other.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
    await expect(other.locator('.workbench-main')).toHaveAttribute(
      'data-project-save-status',
      'saved',
    );
    const newServerBeforeReply = await e01Server(other, newProject);
    assertContent(newServerBeforeReply.draft.document, 888.8, newSketch);
    expect(newServerBeforeReply.draft.document).toEqual(newLocalBefore.record!.document);
    const newUiBeforeReply = await ui(other, '888.8', newSketch, actorB);
    const oldPutCountAtB = oldBrowserPuts.length;
    accountReply.release();
    await accountReply.finished;
    const oldUiAfterReply = await revokedUi();
    expect(oldUiAfterReply).toEqual(oldUiAfterLogout);
    expect(await ui(other, '888.8', newSketch, actorB)).toEqual(newUiBeforeReply);
    expect(await e01Server(other, newProject)).toEqual(newServerBeforeReply);
    expect(oldBrowserPuts).toHaveLength(oldPutCountAtB);
    expect(oldBrowserPuts.filter((request) => request.phase === 'actor-B')).toEqual([]);
    const oldLocalAfterReply = await local(actorA.id, secondProject);
    expect(oldLocalAfterReply.raw).toBe(beforeAccountSwitch.raw);
    assertContent(oldLocalAfterReply.record!.document, 444.4, latestSecondSketch);
    expect(await local(actorB.id, secondProject)).toMatchObject({ raw: null, record: null });
    const deniedProjects: unknown[] = [];
    for (const projectId of [firstProject, secondProject]) {
      const response = await other.context().request.get(`/api/projects/${projectId}`);
      expect([403, 404]).toContain(response.status());
      deniedProjects.push({ projectId, status: response.status() });
    }
    // A normal bootstrap now renders B in the old page; no fake principal/event.
    await page.goto(`/#/home/${newProject}`);
    const bootstrappedActorB = await actor();
    expect(bootstrappedActorB).toEqual(actorB);
    const bootstrappedUi = await ui(page, '888.8', newSketch, actorB);
    expect(bootstrappedUi.status).toBe('saved');
    const oldLocalAfterBootstrap = await local(actorA.id, secondProject);
    expect(oldLocalAfterBootstrap.raw).toBe(beforeAccountSwitch.raw);
    assertContent(oldLocalAfterBootstrap.record!.document, 444.4, latestSecondSketch);
    expect(oldBrowserPuts.filter((request) => request.phase === 'actor-B')).toEqual([]);
    writeFileSync(
      `${evidenceDir}/after-project-account-isolation.json`,
      JSON.stringify(
        {
          actorA,
          actorB,
          firstProject,
          secondProject,
          newProject,
          firstEditorUrl,
          sameRendererTimeOrigin,
          afterSwitchTimeOrigin,
          requests,
          oldBrowserPuts,
          heldReplies,
          committedFirst,
          committedSecond,
          beforeProjectSwitch,
          afterProjectSwitch,
          secondBeforeReply,
          secondAfterReply,
          secondServerBeforeReply,
          beforeAccountSwitch,
          oldUiAfterLogout,
          oldLocalAfterLogout,
          oldUiAfterReply,
          oldLocalAfterReply,
          oldLocalAfterBootstrap,
          newLocalBefore,
          newServerBeforeReply,
          newUiBeforeReply,
          deniedProjects,
          bootstrappedActorB,
          bootstrappedUi,
        },
        null,
        2,
      ),
    );
  } finally {
    projectReply.release();
    accountReply.release();
    await other.close();
  }
});

test('ELECTRONICS-E01 SAV06 does not clear a real two-tab conflict by editing again', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'E01 two tabs conflict');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  const first = await e01Resistance(page);
  await first.fill('444.4');
  const other = await page.context().newPage();
  await other.goto(`/#/home/${projectId}`);
  await (await e01Resistance(other)).fill('555.5');
  await other.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(other.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'error',
  );
  await expect(page.locator('.workbench-save-state')).toHaveAttribute(
    'title',
    /другую версию.*отправка остановлена/,
  );
  await first.fill('666.6');
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'error',
  );
  const local = JSON.parse((await e01LocalDraft(page, projectId))!);
  expect(local.document.components.find((c: { id: string }) => c.id === 'resistor').value).toBe(
    666.6,
  );
  const server = await e01Server(page, projectId);
  expect(server.draft.document.components.find((c) => c.id === 'resistor')?.value).toBe(555.5);
  mkdirSync('reports/playwright/electronics-e01', { recursive: true });
  writeFileSync(
    'reports/playwright/electronics-e01/after-two-tabs-conflict.json',
    JSON.stringify({ projectId, local, server }, null, 2),
  );
  await other.close();
});

for (const action of ['manual Save', 'genuine departure'] as const) {
  test(`Arduino sketch durability: fast input followed by ${action}`, async ({ page }) => {
    test.setTimeout(90_000);
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    await page.setViewportSize({ width: 1600, height: 1000 });
    await loginWithOrganization(page, teacher);
    const sessionResponse = await page.context().request.get('/api/auth/me');
    expect(sessionResponse.status()).toBe(200);
    const session = (await sessionResponse.json()) as {
      authenticated: boolean;
      user: { id: string };
    };
    expect(session.authenticated).toBe(true);
    const userId = session.user.id;
    const projectId = await createProject(page, `Sketch durability ${action}`);
    const localKey = `asa-project-local-draft:user:account:${encodeURIComponent(userId)}:${encodeURIComponent(projectId)}`;
    const fixture = arduinoInputDocument('button', '2');
    await saveDocument(page, projectId, fixture);
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();

    const puts: SchematicDocument[] = [];
    page.on('request', (request) => {
      if (
        request.method() === 'PUT' &&
        new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
      ) {
        puts.push((request.postDataJSON() as { document: SchematicDocument }).document);
      }
    });
    // Make Save enabled before the source edit. Otherwise Playwright could
    // wait for the old 260ms commit and conceal the input-to-document defect.
    await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
    const resistance = page
      .locator('.workbench-inspector label')
      .filter({ hasText: 'Сопротивление' })
      .locator('input[type="number"]');
    await resistance.fill('333.3');
    await expect(resistance).toHaveValue('333.3');
    const base = await page.evaluate(
      ({ key, id, userId }) => {
        const raw = localStorage.getItem(key);
        if (!raw) throw new Error('The preparatory resistor edit has no local document');
        const record = JSON.parse(raw) as {
          schemaVersion: number;
          identityKind: string;
          userId: string;
          projectId: string;
          moduleKey: string;
          document: SchematicDocument;
        };
        if (
          record.schemaVersion !== 3 ||
          record.identityKind !== 'account' ||
          record.userId !== userId ||
          record.projectId !== id ||
          record.moduleKey !== 'electronics'
        )
          throw new Error('The preparatory local document belongs to another identity or scope');
        return record.document;
      },
      { key: localKey, id: projectId, userId },
    );
    expect(base.components.find((entry) => entry.id === 'resistor')?.value).toBe(333.3);
    const changedSource = `// latest sketch before ${action}\nvoid setup(){pinMode(13,OUTPUT);}\nvoid loop(){digitalWrite(13,HIGH);delay(10);}\n`;
    const expected = {
      ...base,
      components: base.components.map((entry) =>
        entry.id === 'uno'
          ? {
              ...entry,
              stateProperties: {
                ...entry.stateProperties,
                arduinoCodeMode: 'text',
                arduinoWorkspace: '',
                arduinoSource: changedSource,
                arduinoSerialOpen: false,
                arduinoBaudRate: 9600,
              },
            }
          : entry,
      ),
    };
    await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    const editor = page.getByRole('textbox', { name: 'Код Arduino C++', exact: true });
    await expect(editor).toHaveValue(
      String(
        fixture.components.find((entry) => entry.id === 'uno')?.stateProperties?.['arduinoSource'],
      ),
    );
    const actionLabel = action === 'manual Save' ? 'Сохранить проект' : 'ASA Lab';
    await expect(page.getByRole('button', { name: actionLabel, exact: true })).toBeEnabled();
    expect(puts).toHaveLength(0);
    await page.evaluate(
      ({ key, id, userId, label }) => {
        const receipt = {
          inputAt: null as number | null,
          actionAt: null as number | null,
          inputLocal: null as { document: SchematicDocument } | null,
          actionLocal: null as { document: SchematicDocument } | null,
        };
        const local = () => {
          const raw = localStorage.getItem(key);
          if (!raw) return null;
          const record = JSON.parse(raw) as {
            schemaVersion: number;
            identityKind: string;
            userId: string;
            projectId: string;
            moduleKey: string;
            document: SchematicDocument;
          };
          if (
            record.schemaVersion !== 3 ||
            record.identityKind !== 'account' ||
            record.userId !== userId ||
            record.projectId !== id ||
            record.moduleKey !== 'electronics'
          )
            throw new Error('The input/action local document belongs to another identity or scope');
          return record;
        };
        Object.assign(window, { __sketchDurability529: receipt });
        document.addEventListener('input', (event) => {
          if (!(event.target instanceof HTMLTextAreaElement)) return;
          if (event.target.getAttribute('aria-label') !== 'Код Arduino C++') return;
          // At document bubble phase React has handled the real text input.
          receipt.inputAt = performance.now();
          receipt.inputLocal = local();
        });
        document.addEventListener(
          'click',
          (event) => {
            const button = event.target instanceof Element ? event.target.closest('button') : null;
            if (button?.getAttribute('aria-label') !== label) return;
            receipt.actionAt = performance.now();
            receipt.actionLocal = local();
          },
          true,
        );
      },
      { key: localKey, id: projectId, userId, label: actionLabel },
    );
    const saved = page.waitForResponse(
      (response) =>
        response.request().method() === 'PUT' &&
        new URL(response.url()).pathname === `/api/projects/${projectId}/draft`,
    );
    // No sketch-readiness poll, sleep, panel close or extra edit before action.
    await editor.fill(changedSource);
    await page.getByRole('button', { name: actionLabel, exact: true }).click();
    const response = await saved;
    expect(response.status()).toBe(200);
    const receipt = await page.evaluate(() => {
      return Reflect.get(window, '__sketchDurability529') as {
        inputAt: number | null;
        actionAt: number | null;
        inputLocal: { document: SchematicDocument } | null;
        actionLocal: { document: SchematicDocument } | null;
      };
    });
    expect(receipt.inputAt).not.toBeNull();
    expect(receipt.actionAt).not.toBeNull();
    const elapsedMs = receipt.actionAt! - receipt.inputAt!;
    expect(
      elapsedMs,
      'The fast-input scenario must act inside the inherited 260ms window',
    ).toBeLessThan(260);
    expect(elapsedMs).toBeGreaterThanOrEqual(0);
    expect(receipt.inputLocal?.document).toEqual(expected);
    expect(receipt.actionLocal?.document).toEqual(expected);
    expect(puts).toEqual([expected]);
    const opened = await page.context().request.get(`/api/projects/${projectId}`, {
      headers: { origin: new URL(page.url()).origin },
    });
    expect(opened.status()).toBe(200);
    const server = (await opened.json()) as {
      draft: { document: SchematicDocument; revision: number };
    };
    expect(server.draft.document).toEqual(expected);
    if (action === 'manual Save') {
      await expect(page.locator('.workbench-main')).toHaveAttribute(
        'data-project-save-status',
        'saved',
      );
      await page.getByRole('button', { name: 'ASA Lab', exact: true }).click();
    }
    await expect(page.locator('.workbench-main')).toHaveCount(0);
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();
    await page.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
    await expect(page.getByRole('textbox', { name: 'Код Arduino C++', exact: true })).toHaveValue(
      changedSource,
    );
    await page.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
    await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
    await expect(resistance).toHaveValue('333.3');
    expect(await e01PendingLocalDraft(page, projectId, userId)).toBeNull();
    const report = { projectId, action, elapsedMs, receipt, expected, puts, server };
    await test.info().attach(`sketch-529-${action.replaceAll(' ', '-')}.json`, {
      body: Buffer.from(JSON.stringify(report, null, 2)),
      contentType: 'application/json',
    });
    failures.assertEmpty();
    const reportDirectory = 'reports/playwright/sketch-529';
    mkdirSync(reportDirectory, { recursive: true });
    writeFileSync(
      `${reportDirectory}/after-${action === 'manual Save' ? 'manual-Save' : 'genuine-departure'}.json`,
      JSON.stringify(report, null, 2),
    );
  });
}

test('real API autosave sends the edited draft after one minute', async ({ page }) => {
  test.setTimeout(120_000);
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'R4-M1 minute autosave');
  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: false, resistorOhms: 50, reversedLed: false }),
  );
  await page.clock.install();
  await page.goto(`/#/home/${projectId}`);
  const resistor = component(page, 'resistor-axial');
  await resistor.locator('.workbench-part').press('Enter');
  const value = page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]');
  await expect(value).toHaveValue('50');

  const draftPuts: string[] = [];
  page.on('request', (request) => {
    if (
      request.method() === 'PUT' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
    )
      draftPuts.push(request.url());
  });
  await value.fill('166.7');
  await expect(value).toHaveValue('166.7');
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'dirty',
  );
  await page.clock.fastForward(58_000);
  expect(draftPuts).toHaveLength(0);
  await page.clock.fastForward(3_000);
  await expect.poll(() => draftPuts.length).toBe(1);
  await expect
    .poll(async () => {
      const response = await page.context().request.get(`/api/projects/${projectId}`, {
        headers: { origin: new URL(page.url()).origin },
      });
      expect(response.ok()).toBe(true);
      const payload = (await response.json()) as { draft: { document: SchematicDocument } };
      return payload.draft.document.components.find((item) => item.id === 'resistor')?.value;
    })
    .toBe(166.7);
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
});

test('real editor recalculates SPDT, resistor and LED without waiting for persistence', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await observeSimulationWorkerClock(page);
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'R4-M1 live simulation');
  await openProject(page, projectId);
  await expect(page.getByText('Рабочее поле пустое')).toBeVisible();
  await page.screenshot({ path: `${ARTIFACT_DIR}/electronics-empty.png`, fullPage: true });

  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: false, resistorOhms: 50, reversedLed: false }),
  );
  await page.reload();

  const led = component(page, 'led-5mm');
  const switchComponent = component(page, 'switch-spdt');
  const resistor = component(page, 'resistor-axial');
  await expect(component(page, 'breadboard-medium')).toBeVisible();
  await expect(page.locator('[data-testid="schematic-wire"]')).toHaveCount(5);
  await page.screenshot({ path: `${ARTIFACT_DIR}/electronics-wired.png`, fullPage: true });

  const sourceComponentId = await component(page, 'battery-holder-aa-2').getAttribute(
    'data-component-id',
  );
  if (!sourceComponentId) throw new Error('battery source has no component identity');
  const sourcePositive = page.locator(
    '.workbench-terminal-hit[data-terminal-component-id="' +
      sourceComponentId +
      '"][data-terminal-id="BAT+"]',
  );
  await sourcePositive.click();
  const previewWire = page.locator('.workbench-wire-preview');
  const stageBox = await page.locator('svg.workbench-canvas').boundingBox();
  if (!stageBox) throw new Error('workbench canvas has no visual bounding box');
  await page.mouse.move(stageBox.x + stageBox.width * 0.46, stageBox.y + stageBox.height * 0.38);
  await expect(previewWire).toBeVisible();
  const initialPreviewPath = await previewWire.getAttribute('d');
  await page.mouse.move(stageBox.x + stageBox.width * 0.52, stageBox.y + stageBox.height * 0.42);
  await expect.poll(() => previewWire.getAttribute('d')).not.toBe(initialPreviewPath);
  await page.keyboard.press('Escape');
  await expect(previewWire).toHaveCount(0);

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toHaveAttribute(
    'data-simulation-status',
    'running',
  );

  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);
  await expect(led.locator('.workbench-production-visual')).toHaveAttribute(
    'data-led-runtime-state',
    'off',
  );
  await expect(diagnostic(page, 'led-5mm', 'led-diagnostic-badge')).toHaveCount(0);
  await expect(led.locator('image:not([filter])').first()).toHaveAttribute(
    'href',
    /led_red_i000\.svg$/,
  );
  await switchComponent.getByTestId('spdt-actuator').click();
  await expect(switchComponent).toHaveClass(/workbench-component-actuator-active/);
  const colourBrightness = new Map<string, number>();
  for (const colour of ['red', 'orange', 'yellow', 'green', 'blue', 'white']) {
    await page.getByRole('button', { name: 'Остановить моделирование' }).click();
    await selectLed(page);
    await page.getByRole('combobox', { name: /^Цвет(?: светодиода)?$/ }).selectOption(colour);
    await expect(led.locator('.workbench-production-visual')).toHaveAttribute(
      'data-led-colour',
      colour,
    );
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    await switchComponent.getByTestId('spdt-actuator').click();
    await selectLed(page);
    await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
    await expect(led.locator('image:not([filter])').first()).toHaveAttribute(
      'href',
      new RegExp(`led_${colour}_i(?!000)\\d{3}\\.svg$`),
    );
    colourBrightness.set(colour, await brightnessValue(page));
  }
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await selectLed(page);
  await page.getByRole('combobox', { name: /^Цвет(?: светодиода)?$/ }).selectOption('red');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await switchComponent.getByTestId('spdt-actuator').click();
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(colourBrightness.get('red'));
  const brightAt50Ohms = await brightnessValue(page);
  await expect(led.locator('.workbench-production-visual')).toHaveAttribute(
    'data-led-runtime-state',
    'lit',
  );
  await expect(diagnostic(page, 'led-5mm', 'led-diagnostic-badge')).toHaveCount(0);
  await expect(led.locator('image:not([filter])').first()).not.toHaveAttribute(
    'href',
    /led_red_i000\.svg$/,
  );
  const ledInspector = page.locator('.workbench-inspector');
  await expect(ledInspector.getByText('Имя', { exact: true })).toBeVisible();
  await expect(ledInspector.getByText('цвет', { exact: true })).toBeVisible();
  await expect(ledInspector.getByText(/Яркость|Ток|Напряжение/)).toHaveCount(0);
  await page.screenshot({ path: `${ARTIFACT_DIR}/electronics-running.png`, fullPage: true });

  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await resistor.locator('.workbench-part').press('Enter');
  const resistanceInput = page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]');
  await resistanceInput.fill('1');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await switchComponent.getByTestId('spdt-actuator').click();
  await selectLed(page);
  const warningBadge = diagnostic(page, 'led-5mm', 'led-diagnostic-badge');
  await expect(warningBadge).toBeVisible();
  await expect(warningBadge).toHaveAttribute(
    'aria-label',
    'Сила тока в светодиоде равна 114 mA (максимальное рекомендуемое значение — 20.0 mA). Это может привести к сокращению срока службы светодиода.',
  );
  await expect(warningBadge.locator('.workbench-component-diagnostic-tooltip')).toHaveCount(0);
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-led-warning.png`,
    fullPage: true,
  });

  // Runtime damage is intentionally persistent until Stop/new Start. Move the
  // resistor back into a safe range, restart the simulation and prove that the
  // fresh run uses the edited circuit rather than carrying the failed LED.
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await resistor.locator('.workbench-part').press('Enter');
  await page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]')
    .fill('100');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  // Runtime actuator overrides reset with a new run as well as thermal
  // damage, so close the SPDT again before checking the safe resistor value.
  await switchComponent.getByTestId('spdt-actuator').click();
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBeLessThan(brightAt50Ohms);
  await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);

  let previousBrightness = await brightnessValue(page);
  let persistedArbitraryBrightness = previousBrightness;
  for (const resistance of [166.7]) {
    await page.getByRole('button', { name: 'Остановить моделирование' }).click();
    await resistor.locator('.workbench-part').press('Enter');
    const arbitraryResistanceInput = page
      .locator('.workbench-inspector label')
      .filter({ hasText: 'Сопротивление' })
      .locator('input[type="number"]');
    await arbitraryResistanceInput.fill(String(resistance));
    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    await switchComponent.getByTestId('spdt-actuator').click();
    await selectLed(page);
    await expect.poll(() => brightnessValue(page)).toBeLessThan(previousBrightness);
    await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
    persistedArbitraryBrightness = await brightnessValue(page);
    previousBrightness = persistedArbitraryBrightness;
  }
  await resistor.locator('.workbench-part').press('Enter');
  await expect(page.getByRole('combobox', { name: 'Единица сопротивления' })).toHaveValue('Ω');
  await expect(
    page
      .locator('.workbench-inspector label')
      .filter({ hasText: 'Сопротивление' })
      .locator('input[type="number"]'),
  ).toHaveValue('166.7');
  await selectLed(page);
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-resistance-changed.png`,
    fullPage: true,
  });

  await saveEditorNow(page);
  await expect
    .poll(
      async () => {
        const saved = await page.context().request.get(`/api/projects/${projectId}`, {
          headers: { origin: new URL(page.url()).origin },
        });
        if (saved.status() !== 200) return null;
        const payload = (await saved.json()) as {
          draft: { document: SchematicDocument };
        };
        return payload.draft.document.components.find((item) => item.id === 'resistor')?.value;
      },
      { timeout: 15_000 },
    )
    .toBe(166.7);
  const checkpoint = await page.context().request.post(`/api/projects/${projectId}/checkpoints`, {
    headers: { origin: new URL(page.url()).origin },
    data: { label: 'Electronics M1 release candidate' },
  });
  expect(checkpoint.status()).toBe(201);
  expect((await checkpoint.json()) as { version: { versionNo: number } }).toMatchObject({
    version: { versionNo: 1 },
  });
  await page.reload();
  await expect(page.getByRole('button', { name: 'Начать моделирование' })).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  await expect(switchComponent).not.toHaveClass(/workbench-component-actuator-active/);
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);
  await switchComponent.getByTestId('spdt-actuator').click();
  await expect(switchComponent).toHaveClass(/workbench-component-actuator-active/);
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(persistedArbitraryBrightness);
  await page.screenshot({ path: `${ARTIFACT_DIR}/electronics-reload.png`, fullPage: true });

  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Начать моделирование' })).toBeVisible();
  await leaveSavedWorkbench(page, projectId);
  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: true, resistorOhms: 1000, reversedLed: true }),
  );
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);
  await expect(led).not.toHaveAttribute('data-diagnostics', /reverse_polarity/);
  const reverseAsset = led.locator('image:not([filter])').first();
  await expect(reverseAsset).toHaveAttribute('href', /\/led\/red\/led_red_i000\.svg$/);
  await expect
    .poll(() => reverseAsset.evaluate((image) => getComputedStyle(image).filter))
    .toBe('none');
  await expect(led.locator('.workbench-production-visual')).toHaveClass(/is-reverse/);
  await expect(diagnostic(page, 'led-5mm', 'led-diagnostic-badge')).toHaveCount(0);
  await expect(diagnostic(page, 'led-5mm', 'led-burnout-explosion')).toHaveCount(0);
  await page.getByRole('button', { name: /Техническое состояние.*Светодиод/i }).click();
  await expect(ledInspector.getByText('Закрыт — обратное включение')).toBeVisible();
  await expect(ledInspector.getByText('Номинальный ток')).toBeVisible();
  await expect(ledInspector.getByText('20 мА', { exact: true })).toBeVisible();
  await expect(ledInspector.getByText('Разрушительный ток')).toBeVisible();
  await expect(ledInspector.getByText('120 мА', { exact: true })).toBeVisible();
  await expect(ledInspector.getByText('Обратный предел')).toBeVisible();
  await expect(ledInspector.getByText('5 В', { exact: true })).toBeVisible();
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-reverse-polarity.png`,
    fullPage: true,
  });

  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await expect(led.locator('.workbench-production-visual')).toHaveAttribute(
    'data-led-runtime-state',
    'stopped',
  );
  await expect(led.locator('image:not([filter])').first()).not.toHaveAttribute(
    'href',
    /special\/led_red_burned\.svg$/,
  );
  await expect(diagnostic(page, 'led-5mm', 'led-burnout-explosion')).toHaveCount(0);
  await leaveSavedWorkbench(page, projectId);
  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: true, resistorOhms: 0, reversedLed: false }),
  );
  await page.goto(`/#/home/${projectId}`);
  const priorWorkerCount = await page.evaluate(
    () => (window as Window & { __simulationWorkerCount?: number }).__simulationWorkerCount ?? 0,
  );
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await selectLed(page);
  // A requested toolbar time is not proof that the worker completed the thermal model.
  // Every Start creates a new worker, so only use replies from this run.
  try {
    await expect
      .poll(
        () =>
          page.evaluate((beforeWorkerId) => {
            const clockWindow = window as Window & {
              __simulationWorkerCount?: number;
              __simulationClockSamples?: Array<{
                workerId: number;
                committedMicroseconds: number;
                status: string;
              }>;
            };
            const currentWorkerId = clockWindow.__simulationWorkerCount ?? 0;
            if (currentWorkerId <= beforeWorkerId) return 0;
            const latestReady = clockWindow.__simulationClockSamples
              ?.filter((sample) => sample.workerId === currentWorkerId && sample.status === 'ready')
              .at(-1);
            return latestReady?.committedMicroseconds ?? 0;
          }, priorWorkerCount),
        { timeout: 25_000 },
      )
      .toBeGreaterThanOrEqual(4_500_000);
  } catch (error) {
    const observation = await simulationWorkerObservation(page);
    throw new Error(
      `LED thermal worker did not confirm 4_500_000 us after Start (priorWorkerCount=${priorWorkerCount}): ${JSON.stringify(observation)}`,
      { cause: error },
    );
  }
  try {
    await expect(led).toHaveAttribute('data-diagnostics', /led_burnout/);
    await expect(led.locator('image:not([filter])').first()).toHaveAttribute(
      'href',
      /special\/led_red_burned\.svg$/,
    );
    await expect(diagnostic(page, 'led-5mm', 'led-diagnostic-badge')).toHaveCount(0);
    await expect(diagnostic(page, 'led-5mm', 'led-burnout-explosion')).toBeVisible();
    await expect(diagnostic(page, 'led-5mm', 'led-burnout-explosion')).toHaveAttribute(
      'aria-label',
      /компонент вышел из строя/i,
    );
  } catch (error) {
    throw new Error(
      `LED thermal worker crossed 4_500_000 us but burnout presentation failed: ${JSON.stringify(await simulationWorkerObservation(page))}`,
      { cause: error },
    );
  }
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-led-burnout.png`,
    fullPage: true,
  });

  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await leaveSavedWorkbench(page, projectId);
  await saveDocument(page, projectId, shortCircuitDocument());
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  await expect(page.getByText(/Время моделирования:/)).toBeVisible();
  const source = page.locator('[data-testid="schematic-component"][data-kind="source"]');
  await expect(source).toHaveAttribute('data-diagnostics', /short_circuit/);
  const sourceDiagnostic = page.locator(
    '[data-testid="component-diagnostic"][data-component-type="battery-holder-aa-2"]',
  );
  await expect(sourceDiagnostic).toHaveAttribute('data-anchor', 'owner-alpha-top-right');
  await expect(sourceDiagnostic.getByTestId('component-diagnostic-indicator')).toBeVisible();
  const sourceBounds = await source.locator('.workbench-part').boundingBox();
  const sourceDiagnosticBounds = await sourceDiagnostic.boundingBox();
  if (!sourceBounds || !sourceDiagnosticBounds) {
    throw new Error('source diagnostic anchor has no rendered bounds');
  }
  const diagnosticCenter = {
    x: sourceDiagnosticBounds.x + sourceDiagnosticBounds.width / 2,
    y: sourceDiagnosticBounds.y + sourceDiagnosticBounds.height / 2,
  };
  expect(diagnosticCenter.x).toBeGreaterThan(sourceBounds.x + sourceBounds.width / 2);
  expect(diagnosticCenter.x).toBeLessThanOrEqual(sourceBounds.x + sourceBounds.width);
  expect(diagnosticCenter.y).toBeGreaterThanOrEqual(sourceBounds.y);
  expect(diagnosticCenter.y).toBeLessThan(sourceBounds.y + sourceBounds.height / 2);
  await expect(source).toHaveAttribute('data-presentation-state', 'failed');
  await expect(source).toHaveAttribute('data-diagnostics', /component_failed/);
  await expect(page.locator('.workbench-results')).toHaveCount(0);
  await expect(page.locator('.workbench-toast')).toHaveCount(0);

  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await leaveSavedWorkbench(page, projectId);
  await saveDocument(page, projectId, resistorOverloadDocument());
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const overloadedSource = component(page, 'battery-holder-aa-2');
  const overloadedResistor = component(page, 'resistor-axial');
  await expect(overloadedSource).toHaveAttribute('data-presentation-state', 'destructive');
  await expect(overloadedResistor).toHaveAttribute('data-presentation-state', 'failed');
  await expect(overloadedResistor).toHaveAttribute('data-diagnostics', /component_failed/);
  expect(failures.counts).toMatchObject({
    consoleErrors: 0,
    pageErrors: 0,
    failedRequests: 0,
    httpServerErrors: 0,
  });
  failures.assertEmpty();
});

test('four-pin button is a momentary bridge for an arbitrary decimal LED load', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'R4-M1 momentary button arbitrary resistance');
  await saveDocument(page, projectId, buttonCircuitDocument(683.7));
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const button = component(page, 'button-tactile-6mm');
  const buttonBody = button.locator('.workbench-part');
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);

  const buttonBox = await buttonBody.boundingBox();
  if (!buttonBox) throw new Error('button actuator has no visual bounding box');
  await page.mouse.move(buttonBox.x + buttonBox.width / 2, buttonBox.y + buttonBox.height / 2);
  await page.mouse.down();
  await expect(button).toHaveClass(/workbench-component-actuator-active/);
  await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);

  await page.mouse.up();
  await expect(button).not.toHaveClass(/workbench-component-actuator-active/);
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);

  await buttonBody.click();
  const buttonInspector = page.locator('.workbench-inspector');
  await buttonInspector.getByRole('button', { name: 'Техническое состояние Кнопка' }).click();
  await expect(buttonInspector.getByTestId('button-contact-summary')).toContainText('Отпущена');
  await expect(buttonInspector.getByRole('checkbox')).toHaveCount(0);

  const holdButton = buttonInspector.getByRole('button', { name: 'Удерживать кнопку' });
  const holdBox = await holdButton.boundingBox();
  if (!holdBox) throw new Error('button inspector control has no visual bounding box');
  await page.mouse.move(holdBox.x + holdBox.width / 2, holdBox.y + holdBox.height / 2);
  await page.mouse.down();
  await expect(buttonInspector.getByTestId('button-contact-summary')).toContainText('Нажата');
  await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);
  await page.mouse.up();
  await expect(buttonInspector.getByTestId('button-contact-summary')).toContainText('Отпущена');
  await expect.poll(() => brightnessValue(page)).toBe(0);

  await buttonInspector.getByRole('button', { name: 'Справка о компоненте Кнопка' }).click();
  await expect(
    page.getByText('После отпускания цепь снова размыкается.', { exact: false }),
  ).toBeVisible();
  failures.assertEmpty();
});

test('SPDT selects exactly one throw and keeps the runtime position out of autosave', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'MATH-6C deterministic SPDT');
  await saveDocument(
    page,
    projectId,
    circuitDocument({ switchClosed: false, resistorOhms: 330, reversedLed: false }),
  );
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const switchComponent = component(page, 'switch-spdt');
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);
  await switchComponent.getByTestId('spdt-actuator').click();
  await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);

  const inspector = page.locator('.workbench-inspector');
  await inspector
    .getByRole('button', { name: 'Техническое состояние Ползунковый переключатель' })
    .click();
  await expect(inspector.getByTestId('spdt-contact-summary')).toContainText('правым выводом');
  await expect(inspector.getByRole('button', { name: 'Правый вывод' })).toHaveAttribute(
    'aria-pressed',
    'true',
  );

  await inspector.getByRole('button', { name: 'Левый вывод' }).click();
  await expect(inspector.getByTestId('spdt-contact-summary')).toContainText('левым выводом');
  await expect.poll(() => brightnessValue(page)).toBe(0);
  await inspector.getByRole('button', { name: 'Правый вывод' }).click();
  await expect.poll(() => brightnessValue(page)).toBeGreaterThan(0);

  await inspector
    .getByRole('button', { name: 'Справка о компоненте Ползунковый переключатель' })
    .click();
  await expect(
    page.getByText('Общий контакт всегда соединён ровно с одним выводом', { exact: false }),
  ).toBeVisible();

  await page.reload();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await selectLed(page);
  await expect.poll(() => brightnessValue(page)).toBe(0);
  await expect(page.locator('[data-testid="schematic-wire"]')).toHaveCount(5);
  failures.assertEmpty();
});

test('independent and parallel sources keep diagnostics local and expose current direction', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'R4-M1 isolated source diagnostics');
  await saveDocument(page, projectId, isolatedSourceDiagnosticsDocument());
  await page.goto(`/#/home/${projectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const renderedComponents = page.locator('[data-testid="schematic-component"]');
  const shortedSource = renderedComponents.nth(0);
  const safeSource = renderedComponents.nth(1);
  const burnoutSource = renderedComponents.nth(2);
  await expect(shortedSource).toHaveAttribute('data-diagnostics', /short_circuit/);
  await expect(safeSource).not.toHaveAttribute('data-diagnostics', /short_circuit/);
  await expect(burnoutSource).not.toHaveAttribute('data-diagnostics', /short_circuit/);
  await expect(
    page.locator('[data-testid="component-diagnostic"][data-component-id="safe-source"]'),
  ).toHaveCount(0);

  const burnedLedDiagnostic = page.locator(
    '[data-testid="component-diagnostic"][data-component-id="burned-led"]',
  );
  await burnedLedDiagnostic.locator('[data-testid="led-burnout-explosion"]').click();
  const technicalState = page.getByRole('button', {
    name: 'Техническое состояние Светодиод',
  });
  await expect(technicalState).toHaveAttribute('data-diagnostic-severity', 'error');
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-isolated-source-diagnostics.png`,
    fullPage: true,
  });
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  const conflictProjectId = await createProject(page, 'R4-M1 parallel source modes');
  await saveDocument(page, conflictProjectId, conflictingParallelSourcesDocument());
  await page.goto('/#/home/' + conflictProjectId);

  const highSource = page.locator(
    '[data-testid="schematic-component"][data-component-id="source-high"]',
  );
  const lowSource = page.locator(
    '[data-testid="schematic-component"][data-component-id="source-low"]',
  );

  // E1: static/preflight diagnostics remain available in edit mode, but
  // runtime operating/presentation state is absent until modeling starts.
  await expect(
    page.getByRole('button', {
      name: '\u041d\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434\u0435\u043b\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435',
    }),
  ).toBeVisible();
  await expect(highSource).not.toHaveAttribute('data-source-operating-mode');
  await expect(lowSource).not.toHaveAttribute('data-source-operating-mode');
  await expect(highSource).not.toHaveAttribute('data-presentation-state');
  await expect(lowSource).not.toHaveAttribute('data-presentation-state');
  await expect(highSource).toHaveAttribute('data-diagnostics', /conflicting_sources/);
  await expect(lowSource).toHaveAttribute('data-diagnostics', /conflicting_sources/);
  await page.screenshot({
    path: ARTIFACT_DIR + '/electronics-source-conflict-simulation-off.png',
    fullPage: true,
  });

  await page
    .getByRole('button', {
      name: '\u041d\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434\u0435\u043b\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435',
    })
    .click();
  await expect(highSource).toHaveAttribute('data-source-operating-mode', 'delivering');
  await expect(lowSource).toHaveAttribute('data-source-operating-mode', 'absorbing');
  await expect(highSource).toHaveAttribute('data-diagnostics', /conflicting_sources/);
  await expect(lowSource).toHaveAttribute('data-diagnostics', /conflicting_sources/);
  await expect(
    page.getByRole('button', {
      name: '\u041e\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043c\u043e\u0434\u0435\u043b\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435',
    }),
  ).toBeVisible();
  await page.screenshot({
    path: ARTIFACT_DIR + '/electronics-parallel-source-conflict.png',
    fullPage: true,
  });

  await page
    .getByRole('button', {
      name: '\u041e\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043c\u043e\u0434\u0435\u043b\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435',
    })
    .click();
  await expect(
    page.getByRole('button', {
      name: '\u041d\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434\u0435\u043b\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435',
    }),
  ).toBeVisible();
  await expect(highSource).not.toHaveAttribute('data-source-operating-mode');
  await expect(lowSource).not.toHaveAttribute('data-source-operating-mode');
  await expect(highSource).not.toHaveAttribute('data-presentation-state');
  await expect(lowSource).not.toHaveAttribute('data-presentation-state');
  await expect(highSource).toHaveAttribute('data-diagnostics', /conflicting_sources/);
  await expect(lowSource).toHaveAttribute('data-diagnostics', /conflicting_sources/);
  await page.screenshot({
    path: ARTIFACT_DIR + '/electronics-source-conflict-after-stop.png',
    fullPage: true,
  });
  failures.assertEmpty();
});

test('a direct 3 V / 166 ohm LED branch stays lit beside loose editor parts', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'R4-M1 direct 166 ohm LED regression');
  await saveDocument(page, projectId, directLedWithLoosePartsDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();

  const workingLed = component(page, 'led-5mm').first();
  await expect(workingLed.locator('.workbench-production-visual')).toHaveAttribute(
    'data-led-runtime-state',
    'lit',
  );
  await expect
    .poll(async () =>
      Number(
        (await workingLed
          .locator('.workbench-production-visual')
          .getAttribute('data-led-brightness')) ?? '0',
      ),
    )
    .toBeGreaterThan(40);
  await expect(workingLed).not.toHaveAttribute('data-diagnostics', /numerical_instability/);
  await expect(workingLed.locator('image:not([filter])').first()).not.toHaveAttribute(
    'href',
    /led_red_i000\.svg$/,
  );
  await page.screenshot({ path: `${ARTIFACT_DIR}/electronics-direct-led-166.png`, fullPage: true });
  failures.assertEmpty();
});

test('RGB LED mixes three calculated channels for both common modes', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  for (const commonMode of ['common-cathode', 'common-anode'] as const) {
    const projectId = await createProject(page, `R4-M1 RGB LED ${commonMode}`);
    await saveDocument(page, projectId, rgbLedDocument(commonMode));
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
    await page.getByRole('button', { name: 'Начать моделирование' }).click();

    const rgb = component(page, 'rgb-led');
    const visual = rgb.locator('.workbench-production-visual');
    await expect(visual).toHaveAttribute('data-rgb-runtime-state', 'lit');
    for (const channel of ['red', 'green', 'blue'] as const) {
      await expect
        .poll(async () => Number((await visual.getAttribute(`data-rgb-${channel}`)) ?? '0'))
        .toBeGreaterThan(0);
    }
    await expect(visual).not.toHaveAttribute('data-rgb-colour', 'rgb(0, 0, 0)');
    await expect(rgb.getByTestId('rgb-led-mixture')).toHaveCSS('opacity', /^(?!0(?:\.0+)?$)/);
    await rgb.locator('.workbench-part').click();
    const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
    const technicalState = inspector.getByRole('button', {
      name: 'Техническое состояние RGB-светодиод',
    });
    if ((await technicalState.getAttribute('aria-expanded')) !== 'true') {
      await technicalState.click();
    }
    await expect(inspector.getByLabel('Разводка выводов RGB-светодиода')).toHaveValue('RCBG');
    await expect(inspector.locator('.workbench-calculated-property')).toHaveCount(0);
    await expect(inspector.locator('.workbench-terminal-list')).toHaveCount(0);
    await expect(inspector.getByTestId('rgb-led-channel-measurements')).toHaveCount(1);

    if (commonMode === 'common-cathode') {
      await page.screenshot({
        path: `${ARTIFACT_DIR}/electronics-rgb-mixed-common-cathode.png`,
        fullPage: true,
      });
    }
  }
  failures.assertEmpty();
});

test('MATH-6E RGB inspector reports every physical channel independently', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'MATH-6E RGB independent channels');
  await saveDocument(page, projectId, rgbLedDocument('common-cathode'));
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

  const rgb = component(page, 'rgb-led');
  await rgb.locator('.workbench-part').click();
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  const technicalState = inspector.getByRole('button', {
    name: 'Техническое состояние RGB-светодиод',
  });
  await expect(technicalState).toHaveAttribute('aria-expanded', 'false');
  await expect(inspector.getByTestId('rgb-led-primary-controls')).toBeVisible();
  await expect(inspector.getByLabel('Тип общего вывода RGB-светодиода')).toHaveValue(
    'common-cathode',
  );
  await expect(inspector.getByLabel('Разводка выводов RGB-светодиода')).toHaveValue('RCBG');
  await expect(inspector.getByTestId('rgb-led-channel-measurements')).toHaveCount(0);
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-rgb-led-compact-controls.png`,
    fullPage: true,
  });

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await technicalState.click();
  await expect(inspector.locator('.workbench-terminal-list')).toHaveCount(0);
  const channels = inspector.getByTestId('rgb-led-channel-measurements');
  await expect(channels).toContainText('Красный R');
  await expect(channels).toContainText('Зелёный G');
  await expect(channels).toContainText('Синий B');
  await expect(channels).toContainText('Подключён');
  await expect(channels).toContainText('Общая мощность');
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-rgb-led-math-6e-runtime.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('MATH-6E seven-segment display uses physical pins and an arbitrary segment mask', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  for (const commonMode of ['common-cathode', 'common-anode'] as const) {
    const projectId = await createProject(page, `MATH-6E seven segment ${commonMode}`);
    await saveDocument(page, projectId, sevenSegmentDocument(commonMode));
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

    const display = component(page, 'seven-segment-display');
    await display.locator('.workbench-part').press('Enter');
    const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
    const technicalState = inspector.getByRole('button', {
      name: 'Техническое состояние Семисегментный индикатор',
    });
    if ((await technicalState.getAttribute('aria-expanded')) === 'true') {
      await technicalState.click();
    }
    await expect(technicalState).toHaveAttribute('aria-expanded', 'false');
    await expect(inspector.getByTestId('seven-segment-primary-controls')).toBeVisible();
    await expect(inspector.getByLabel('Тип общего вывода семисегментного индикатора')).toHaveValue(
      commonMode,
    );
    await expect(inspector.getByTestId('seven-segment-junction-measurements')).toHaveCount(0);
    if (commonMode === 'common-cathode') {
      await page.screenshot({
        path: `${ARTIFACT_DIR}/electronics-seven-segment-compact-controls.png`,
        fullPage: true,
      });
    }

    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    const visual = display.getByTestId('seven-segment-state');
    for (const segment of ['a', 'b', 'd', 'e', 'g']) {
      await expect
        .poll(async () =>
          Number(
            (await visual.locator(`[data-segment="${segment}"]`).getAttribute('opacity')) ?? '0',
          ),
        )
        .toBeGreaterThan(0);
    }
    for (const segment of ['c', 'f', 'dp']) {
      await expect(visual.locator(`[data-segment="${segment}"]`)).toHaveAttribute('opacity', '0');
    }

    await technicalState.click();
    await expect(inspector.locator('.workbench-terminal-list')).toHaveCount(0);
    await expect(inspector.getByTestId('seven-segment-active-mask')).toContainText('A, B, D, E, G');
    const segments = inspector.getByTestId('seven-segment-junction-measurements');
    await expect(segments).toContainText('DP');
    await expect(segments).toContainText('Подключён');
    await expect(inspector).toContainText('COM1 и COM2 электрически соединены внутри корпуса');

    if (commonMode === 'common-cathode') {
      await page.screenshot({
        path: `${ARTIFACT_DIR}/electronics-seven-segment-math-6e-runtime.png`,
        fullPage: true,
      });
    }
  }
  failures.assertEmpty();
});

test('MATH-10A1 multimeter measures signed DC voltage with a finite input', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  for (const reverseProbes of [false, true]) {
    const projectId = await createProject(
      page,
      reverseProbes ? 'Мультиметр: обратная полярность' : 'Мультиметр: 3 В',
    );
    await saveDocument(page, projectId, multimeterDcVoltageDocument(reverseProbes));
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

    const meter = component(page, 'multimeter');
    await meter.locator('.workbench-part').press('Enter');
    const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
    await expect(inspector.getByTestId('multimeter-primary-controls')).toBeVisible();
    await expect(inspector.getByLabel('Режим мультиметра')).toHaveValue('dc-voltage');
    await expect(inspector.getByTestId('multimeter-panel-reading')).toContainText(
      'Запустите моделирование',
    );

    await page.getByRole('button', { name: 'Начать моделирование' }).click();
    const display = meter.getByTestId('multimeter-runtime-display');
    await expect(display).toHaveAttribute('data-measurement-mode', 'dc-voltage');
    await expect
      .poll(async () => Number((await display.getAttribute('data-measured-value')) ?? 'NaN'))
      .toBeCloseTo(reverseProbes ? -2.999999865 : 2.999999865, 6);
    await expect(display).toContainText(reverseProbes ? '-3.000 V' : '3.000 V');
    await expect(inspector.getByTestId('multimeter-panel-reading')).toContainText(
      reverseProbes ? '-3.000 В' : '3.000 В',
    );

    const technicalState = inspector.getByRole('button', {
      name: 'Техническое состояние Мультиметр',
    });
    if ((await technicalState.getAttribute('aria-expanded')) !== 'true') {
      await technicalState.click();
    }
    await expect(inspector.getByTestId('multimeter-reference-profile')).toContainText('10 МОм');
    await expect(inspector.getByTestId('multimeter-reference-profile')).toContainText(
      'Параллельно измеряемому участку',
    );
    await expect(inspector).not.toContainText('математическая модель пока не реализована');
    await page.screenshot({
      path: `${ARTIFACT_DIR}/${
        reverseProbes
          ? 'electronics-multimeter-reversed-probes.png'
          : 'electronics-multimeter-dc-voltage.png'
      }`,
      fullPage: true,
    });
  }
  failures.assertEmpty();
});

test('MATH-10A2 multimeter measures series DC current from the owner A button', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Мультиметр: ток 100 Ом');
  await saveDocument(page, projectId, multimeterDcCurrentDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

  const meter = component(page, 'multimeter');
  await meter.locator('.workbench-part').press('Enter');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await expect(inspector.getByLabel('Режим мультиметра')).toHaveValue('dc-voltage');
  await meter.locator('.workbench-multimeter-mode-current').first().click();
  await expect(inspector.getByLabel('Режим мультиметра')).toHaveValue('dc-current');

  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const display = meter.getByTestId('multimeter-runtime-display');
  await expect(display).toHaveAttribute('data-measurement-mode', 'dc-current');
  await expect
    .poll(async () => Number((await display.getAttribute('data-measured-value')) ?? 'NaN'))
    .toBeCloseTo(3 / (0.45 + 100 + 1.8), 5);
  await expect(display).toContainText('29.3 mA');
  await expect(inspector.getByTestId('multimeter-panel-reading')).toContainText('29.3 мА');

  const technicalState = inspector.getByRole('button', {
    name: 'Техническое состояние Мультиметр',
  });
  if ((await technicalState.getAttribute('aria-expanded')) !== 'true') {
    await technicalState.click();
  }
  const profile = inspector.getByTestId('multimeter-reference-profile');
  await expect(profile).toContainText('1.8 Ом');
  await expect(profile).toContainText('Последовательно с нагрузкой');
  await expect(profile).toContainText('Исправен · 440 мА');
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-multimeter-dc-current.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('MATH-10A3 multimeter measures resistance from the owner R button and blocks powered circuits', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'Мультиметр: сопротивление 1 кОм');
  await saveDocument(page, projectId, multimeterResistanceDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

  const meter = component(page, 'multimeter');
  await meter.locator('.workbench-part').press('Enter');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await expect(inspector.getByLabel('Режим мультиметра')).toHaveValue('dc-voltage');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await page.evaluate(() => {
    document
      .querySelector('[data-testid="schematic-component"][data-component-id="meter"]')
      ?.addEventListener(
        'pointerdown',
        (event) => {
          (window as Window & { __meterPointerTargetClass?: string }).__meterPointerTargetClass =
            (event.target as Element).getAttribute('class') ?? '';
        },
        { capture: true, once: true },
      );
  });
  await meter.locator('.workbench-multimeter-mode-resistance').first().click();
  expect(
    await page.evaluate(
      () => (window as Window & { __meterPointerTargetClass?: string }).__meterPointerTargetClass,
    ),
  ).toContain('workbench-multimeter-mode-resistance');
  await expect(inspector.getByLabel('Режим мультиметра')).toHaveValue('resistance');
  await expect(meter.getByTestId('multimeter-runtime-display')).toContainText('1.000 kΩ');
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  await meter.locator('.workbench-multimeter-mode-resistance').first().click();
  await expect(inspector.getByLabel('Режим мультиметра')).toHaveValue('resistance');
  await page.getByRole('button', { name: 'Сохранить проект' }).click();
  await expect
    .poll(async () => {
      const saved = await page.context().request.get(`/api/projects/${projectId}`, {
        headers: { origin: new URL(page.url()).origin },
      });
      expect(saved.ok()).toBe(true);
      const savedPayload = (await saved.json()) as { draft: { document: SchematicDocument } };
      return savedPayload.draft.document.components.find((item) => item.id === 'meter')
        ?.stateProperties?.['measurementMode'];
    })
    .toBe('resistance');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const display = meter.getByTestId('multimeter-runtime-display');
  await expect(display).toHaveAttribute('data-measurement-mode', 'resistance');
  await expect
    .poll(async () => Number((await display.getAttribute('data-measured-value')) ?? 'NaN'))
    .toBeCloseTo(1_000, 2);
  await expect(display).toContainText('1.000 kΩ');
  await expect(inspector.getByTestId('multimeter-panel-reading')).toContainText('1.00 кОм');

  const technicalState = inspector.getByRole('button', {
    name: 'Техническое состояние Мультиметр',
  });
  if ((await technicalState.getAttribute('aria-expanded')) !== 'true') await technicalState.click();
  const profile = inspector.getByTestId('multimeter-reference-profile');
  await expect(profile).toContainText('Авто · до 50.00 МОм');
  await expect(profile).toContainText('Между щупами не обнаружено');
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-multimeter-resistance.png`,
    fullPage: true,
  });

  const poweredProjectId = await createProject(page, 'Мультиметр: R под питанием');
  await saveDocument(page, poweredProjectId, multimeterResistanceDocument(true));
  await page.goto(`/#/home/${poweredProjectId}`);
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const poweredMeter = component(page, 'multimeter');
  await poweredMeter.locator('.workbench-part').press('Enter');
  const poweredInspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await expect(poweredMeter.getByTestId('multimeter-runtime-display')).toContainText('ОШИБКА');
  await expect(poweredInspector.getByTestId('multimeter-panel-reading')).toContainText(
    'Ошибка · внешнее напряжение',
  );
  failures.assertEmpty();
});

test('MATH-10B regulated supply operates its owner controls and transitions between CC and CV', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Лабораторный источник: CV и CC');
  await saveDocument(page, projectId, regulatedPowerSupplyDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });

  const supply = component(page, 'regulated-power-supply');
  await supply.locator('.workbench-part').press('Enter');
  const visual = supply.getByTestId('regulated-power-supply-runtime');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await expect(visual).toHaveAttribute('data-output-enabled', 'false');
  await expect(inspector.getByTestId('regulated-power-supply-primary-controls')).toBeVisible();
  await inspector.getByLabel('Уставка напряжения лабораторного источника').fill('12');
  await inspector.getByLabel('Ограничение тока лабораторного источника').fill('0.1');
  await expect(visual).toHaveAttribute('data-voltage-setpoint', '12');
  await expect(visual).toHaveAttribute('data-current-limit', '0.1');

  await visual.locator('.workbench-regulated-supply-power-slider').click();
  await expect(visual).toHaveAttribute('data-output-enabled', 'true');
  await expect(inspector.getByLabel('Включить выход лабораторного источника')).toBeChecked();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(visual).toHaveAttribute('data-regulation-mode', 'cc');
  await expect(inspector.getByTestId('regulated-power-supply-panel-reading')).toContainText('CC');
  await expect(visual.locator('.workbench-regulated-supply-reading').nth(0)).toContainText(
    '10.00 V',
  );
  await expect(visual.locator('.workbench-regulated-supply-reading').nth(1)).toContainText(
    '0.100 A',
  );
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-regulated-supply-cc.png`,
    fullPage: true,
  });

  await inspector.getByLabel('Ограничение тока лабораторного источника').fill('0.2');
  await expect(visual).toHaveAttribute('data-current-limit', '0.2');
  await expect(visual).toHaveAttribute('data-regulation-mode', 'cv');
  await expect(inspector.getByTestId('regulated-power-supply-panel-reading')).toContainText('CV');
  await expect(visual.locator('.workbench-regulated-supply-reading').nth(0)).toContainText(
    '11.99 V',
  );
  await expect(visual.locator('.workbench-regulated-supply-reading').nth(1)).toContainText(
    '0.120 A',
  );
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-regulated-supply-cv.png`,
    fullPage: true,
  });

  // U/I are now persistent pupil settings; the live output remains temporary.
  await saveEditorNow(page);
  await expect
    .poll(
      async () => {
        const saved = await page.context().request.get(`/api/projects/${projectId}`, {
          headers: { origin: new URL(page.url()).origin },
        });
        expect(saved.ok()).toBe(true);
        const payload = (await saved.json()) as { draft: { document: SchematicDocument } };
        return payload.draft.document.components.find((item) => item.id === 'bench-supply')
          ?.stateProperties;
      },
      { timeout: 15_000 },
    )
    .toMatchObject({
      voltageSetpointVolt: 12,
      currentLimitAmp: 0.2,
      outputEnabled: true,
    });
  await expect(visual).toHaveAttribute('data-current-limit', '0.2');

  await page.reload();
  await expect(page.getByRole('button', { name: 'Начать моделирование' })).toBeVisible();
  await expect(visual).toHaveAttribute('data-voltage-setpoint', '12');
  await expect(visual).toHaveAttribute('data-current-limit', '0.2');
  await expect(visual).toHaveAttribute('data-output-enabled', 'true');
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect(visual).toHaveAttribute('data-regulation-mode', 'cv');
  failures.assertEmpty();
});

test('live supply and oscilloscope controls keep one canonical generation and the saved circuit', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await observeSimulationWorkerClock(page);
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Live source and scope continuity');
  const base = regulatedPowerSupplyDocument();
  const circuit: SchematicDocument = {
    ...base,
    components: [
      ...base.components.map((item) =>
        item.id === 'bench-supply'
          ? {
              ...item,
              state: true,
              stateProperties: { ...item.stateProperties, outputEnabled: true },
            }
          : item,
      ),
      {
        id: 'scope',
        kind: 'visual',
        componentTypeId: 'oscilloscope',
        variantId: 'oscilloscope',
        name: 'Осциллограф',
        position: { x: 700, y: 540 },
        rotation: 0,
        value: 1,
        state: true,
        pinIds: ['signal', 'ground'],
        stateProperties: {
          voltsPerDivision: 1,
          timePerDivisionMs: 1,
          triggerLevelVolt: 0,
          displayEnabled: true,
        },
      },
    ],
    connections: [
      ...base.connections,
      {
        id: 'scope-signal',
        from: { componentId: 'bench-supply', terminal: 'positive' },
        to: { componentId: 'scope', terminal: 'signal' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'scope-ground',
        from: { componentId: 'bench-supply', terminal: 'negative' },
        to: { componentId: 'scope', terminal: 'ground' },
        color: '#2a3035',
        vertices: [],
      },
    ],
  };
  await saveDocument(page, projectId, circuit);
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const supply = component(page, 'regulated-power-supply');
  const supplyVisual = supply.getByTestId('regulated-power-supply-runtime');
  await expect(supplyVisual).toHaveAttribute('data-regulation-mode', 'cv');
  await expect(supplyVisual.locator('.workbench-regulated-supply-reading').nth(0)).toContainText(
    '5.00 V',
  );
  await expect
    .poll(
      async () =>
        (await simulationWorkerObservation(page)).workerSamples
          .filter((sample) => sample.status === 'ready')
          .at(-1)?.committedMicroseconds ?? 0,
      { timeout: 15_000 },
    )
    .toBeGreaterThan(100_000);
  const before = await simulationWorkerObservation(page);
  const generation = before.workerSamples
    .filter((sample) => sample.status === 'ready')
    .at(-1)!.generationId;
  const beforeHorizon = before.workerSamples
    .filter((sample) => sample.status === 'ready')
    .at(-1)!.committedMicroseconds;

  const scope = component(page, 'oscilloscope');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await scope.locator('.workbench-part').press('Enter');
  await expect
    .poll(async () =>
      Number.parseFloat(
        (await inspector.getByTestId('oscilloscope-panel-reading').textContent()) ?? '',
      ),
    )
    .toBeGreaterThan(4.9);
  await supply.locator('.workbench-part').press('Enter');
  await inspector.getByLabel('Уставка напряжения лабораторного источника').fill('8');
  await expect(supplyVisual.locator('.workbench-regulated-supply-reading').nth(0)).toContainText(
    '8.00 V',
  );
  const output = inspector.getByLabel('Включить выход лабораторного источника');
  await output.uncheck();
  await expect(output).not.toBeChecked();
  await expect(supplyVisual).toHaveAttribute('data-regulation-mode', 'off');
  await expect(inspector.getByTestId('regulated-power-supply-panel-reading')).toContainText(
    'Выход выключен',
  );
  await output.check();
  await expect(output).toBeChecked();
  await expect(supplyVisual).toHaveAttribute('data-regulation-mode', 'cv');
  await expect(supplyVisual.locator('.workbench-regulated-supply-reading').nth(0)).toContainText(
    '8.00 V',
  );
  await scope.locator('.workbench-part').press('Enter');
  await expect
    .poll(async () =>
      Number.parseFloat(
        (await inspector.getByTestId('oscilloscope-panel-reading').textContent()) ?? '',
      ),
    )
    .toBeGreaterThan(7.9);
  await inspector.getByLabel('Масштаб осциллографа по напряжению').fill('2');
  await expect(
    scope.getByTestId('oscilloscope-runtime').locator('.workbench-oscilloscope-scale'),
  ).toContainText('2.00 V/div');
  await expect
    .poll(
      async () =>
        (await simulationWorkerObservation(page)).workerSamples
          .filter((sample) => sample.status === 'ready')
          .at(-1)?.committedMicroseconds ?? 0,
      { timeout: 15_000 },
    )
    .toBeGreaterThan(beforeHorizon);
  const after = await simulationWorkerObservation(page);
  expect(
    after.workerSamples.filter((sample) => sample.status === 'ready').at(-1)?.generationId,
  ).toBe(generation);
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  await expect(page.locator('.workbench-simulation-message')).toHaveCount(0);

  // Use the normal save queue, never a request for each live knob adjustment.
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const saved = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin: new URL(page.url()).origin },
  });
  expect(saved.ok()).toBe(true);
  const persisted = (await saved.json()) as { draft: { document: SchematicDocument } };
  expect(
    persisted.draft.document.components.find((item) => item.id === 'bench-supply')
      ?.stateProperties?.['voltageSetpointVolt'],
  ).toBe(8);
  expect(
    persisted.draft.document.components.find((item) => item.id === 'scope')?.stateProperties?.[
      'voltsPerDivision'
    ],
  ).toBe(1);
  expect(persisted.draft.document.connections).toEqual(circuit.connections);
  failures.assertEmpty();
});

// Observe genuine Worker messages without changing transport, continuation,
// budgets, clock or result. Explicit files below survive a passing test with
// the repository's list reporter and retain-on-failure trace policy.
async function observePsuPersistenceWorker(page: Page) {
  await page.addInitScript(() => {
    const probe = window as Window & { __psu543?: unknown[] };
    const records: unknown[] = [];
    probe.__psu543 = records;
    const push = (record: unknown) => {
      records.push(record);
      if (records.length > 200) records.shift();
    };
    window.Worker = new Proxy(window.Worker, {
      construct(target, args, newTarget) {
        const worker = Reflect.construct(target, args, newTarget) as Worker;
        if ((args[1] as WorkerOptions | undefined)?.name !== 'asa-electronics-simulation')
          return worker;
        const post = worker.postMessage.bind(worker);
        worker.postMessage = ((request: {
          kind?: string;
          generationId?: number;
          requestedHorizonMicroseconds?: number;
          inputEvents?: unknown;
          state?: {
            continuation?: { committedHorizonMicroseconds?: number; serializedState?: string };
          };
        }) => {
          if (request.kind === 'advance')
            push({
              direction: 'request',
              at: performance.now(),
              generationId: request.generationId,
              requested: request.requestedHorizonMicroseconds,
              previousCommitted: request.state?.continuation?.committedHorizonMicroseconds ?? 0,
              inputEvents: request.inputEvents ?? [],
              previousState: request.state?.continuation?.serializedState ?? null,
            });
          post(request);
        }) as Worker['postMessage'];
        worker.addEventListener('message', (event: MessageEvent) => {
          const response = event.data as {
            ok?: boolean;
            kind?: string;
            generationId?: number;
            metrics?: unknown;
            advance?: {
              executionStatus: string;
              requestedHorizonMicroseconds: number;
              committedHorizonMicroseconds: number;
              state: { continuation?: { serializedState?: string } };
              result?: {
                solved?: boolean;
                status?: string;
                quality?: { finite: boolean; passed: boolean };
                components?: Array<{
                  componentId: string;
                  voltageDrop: number;
                  current: number;
                  regulationMode?: string;
                }>;
              };
              serial?: unknown;
            };
          };
          if (!response.ok || response.kind !== 'advance' || !response.advance) return;
          push({
            direction: 'response',
            at: performance.now(),
            generationId: response.generationId,
            status: response.advance.executionStatus,
            requested: response.advance.requestedHorizonMicroseconds,
            committed: response.advance.committedHorizonMicroseconds,
            serializedState: response.advance.state.continuation?.serializedState ?? null,
            solved: response.advance.result?.solved ?? false,
            resultStatus: response.advance.result?.status,
            quality: response.advance.result?.quality,
            supplyResult:
              response.advance.result?.components?.find(
                (component) => component.componentId === 'bench-supply',
              ) ?? null,
            serial: response.advance.serial,
            metrics: response.metrics,
            uiClockBeforePublication: document.querySelector('.workbench-simulation-time')
              ?.textContent,
          });
        });
        return worker;
      },
    });
  });
}

type Psu543Sample = {
  direction: 'request' | 'response';
  generationId: number;
  status?: string;
  requested: number;
  committed?: number;
  serializedState?: string;
  previousState?: string;
  previousCommitted?: number;
  inputEvents?: Array<{ operation: string; payload: unknown; atMicroseconds: number }>;
  solved?: boolean;
  resultStatus?: string;
  quality?: { finite: boolean; passed: boolean };
  supplyResult?: {
    componentId: string;
    voltageDrop: number;
    current: number;
    regulationMode?: string;
  } | null;
  metrics?: unknown;
};
async function psu543Records(page: Page): Promise<Psu543Sample[]> {
  return page.evaluate(() => (window as Window & { __psu543?: Psu543Sample[] }).__psu543 ?? []);
}

for (const width of [1440, 1024, 390, 320]) {
  test(`ELECTRONICS-E04 PSU settings survive live edits Stop Save and cookies-only reopen at ${width}px`, async ({
    page,
    browser,
  }, testInfo) => {
    test.setTimeout(120_000);
    const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
    const evidenceDir = `${ARTIFACT_DIR}/psu-setpoints-543`;
    mkdirSync(evidenceDir, { recursive: true });
    const audit: Record<string, unknown> = { width, canonicalTimeAndTimeoutsUnchanged: true };
    const puts: Array<{ at: number; document: SchematicDocument; baseRevision: number }> = [];
    const snapshots: unknown[] = [];
    let profile: Awaited<ReturnType<typeof browser.newContext>> | null = null;
    let reopened: Page | null = null;
    // The shared native organization login uses the desktop public banner.
    await page.setViewportSize({ width: 1440, height: 900 });
    await observePsuPersistenceWorker(page);
    await loginWithOrganization(page, teacher);
    // Every project/editor action still runs at the requested pupil viewport.
    await page.setViewportSize({ width, height: 900 });
    const id = await createProject(page, `E04 pupil settings ${width}`);
    const source =
      '// E04 whole pupil sketch\nint cycles=0;void setup(){pinMode(13,OUTPUT);digitalWrite(13,HIGH);}\nvoid loop(){cycles++;delay(100);}\n';
    const board = arduinoInputDocument('button').components.find((part) => part.id === 'uno')!;
    const base = regulatedPowerSupplyDocument();
    const initial: SchematicDocument = {
      ...base,
      components: [
        ...base.components.map((part) =>
          part.id === 'bench-supply'
            ? {
                ...part,
                state: true,
                stateProperties: { ...part.stateProperties, outputEnabled: true },
              }
            : {
                ...part,
                stateProperties: {
                  tolerancePercent: 5,
                  resistanceUnit: 'Ω',
                  ...part.stateProperties,
                },
              },
        ),
        {
          ...board,
          position: { x: 1000, y: 550 },
          stateProperties: {
            ...board.stateProperties,
            arduinoCodeMode: 'text',
            arduinoSource: source,
            arduinoWorkspace: '{"blocks":{"blocks":[]}}',
          },
        },
      ],
    };
    await saveDocument(page, id, initial);
    const seeded = await e01Server(page, id);
    audit.seeded = seeded;
    const expected = (voltage: number, limit: number): SchematicDocument => ({
      ...seeded.draft.document,
      components: seeded.draft.document.components.map((part) =>
        part.id === 'bench-supply'
          ? {
              ...part,
              value: voltage,
              stateProperties: {
                ...part.stateProperties,
                voltageSetpointVolt: voltage,
                currentLimitAmp: limit,
              },
            }
          : part,
      ),
    });
    page.on('request', (request) => {
      if (
        request.method() === 'PUT' &&
        new URL(request.url()).pathname === `/api/projects/${id}/draft`
      ) {
        const body = request.postDataJSON() as {
          document: SchematicDocument;
          baseRevision: number;
        };
        puts.push({ at: Date.now(), ...body });
      }
    });
    try {
      await page.goto(`/#/home/${id}`);
      await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
      const supply = component(page, 'regulated-power-supply');
      const visual = supply.getByTestId('regulated-power-supply-runtime');
      await supply.locator('.workbench-part').press('Enter');
      const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
      if (width <= 980) {
        const catalogToggle = page.getByRole('button', { name: 'Каталог деталей', exact: true });
        await expect(catalogToggle).toHaveAttribute('aria-pressed', 'true');
        await catalogToggle.click();
        await expect(catalogToggle).toHaveAttribute('aria-pressed', 'false');
        await expect(inspector).toBeVisible();
      }
      const voltage = inspector.getByLabel('Уставка напряжения лабораторного источника');
      const limit = inspector.getByLabel('Ограничение тока лабораторного источника');
      for (const input of [voltage, limit]) {
        await input.scrollIntoViewIfNeeded();
        const layout = await input.evaluate((element) => {
          const rect = element.getBoundingClientRect();
          return {
            tag: element.tagName,
            type: (element as HTMLInputElement).type,
            x: rect.x,
            right: rect.right,
            width: rect.width,
            hit:
              document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2) ===
              element,
            pageOverflow: document.documentElement.scrollWidth > innerWidth + 1,
          };
        });
        snapshots.push(layout);
        expect(layout.tag).toBe('INPUT');
        expect(layout.type).toBe('number');
        expect(layout.width).toBeGreaterThan(0);
        expect(layout.x).toBeGreaterThanOrEqual(0);
        expect(layout.right).toBeLessThanOrEqual(width + 1);
        expect(layout.hit).toBe(true);
        expect(layout.pageOverflow).toBe(false);
      }
      await page.getByRole('button', { name: 'Начать моделирование', exact: true }).click();
      await expect(visual).toHaveAttribute('data-regulation-mode', 'cv');
      await expect
        .poll(
          async () =>
            (await psu543Records(page))
              .filter((record) => record.direction === 'response' && record.status === 'ready')
              .at(-1)?.committed ?? 0,
          { timeout: 15_000 },
        )
        .toBeGreaterThan(100_000);
      const before = (await psu543Records(page))
        .filter((record) => record.direction === 'response' && record.status === 'ready')
        .at(-1)!;
      audit.beforeLiveEdit = before;
      await voltage.fill('7.5');
      await limit.fill('0.15');
      await expect(visual).toHaveAttribute('data-voltage-setpoint', '7.5');
      await expect(visual).toHaveAttribute('data-current-limit', '0.15');
      await expect(visual).toHaveAttribute('data-regulation-mode', 'cv');
      await expect(visual.locator('.workbench-regulated-supply-reading').nth(0)).toContainText(
        '7.50 V',
      );
      await expect(visual.locator('.workbench-regulated-supply-reading').nth(1)).toContainText(
        '0.075 A',
      );
      await expect
        .poll(
          async () =>
            (await psu543Records(page))
              .filter((record) => record.direction === 'response' && record.status === 'ready')
              .at(-1)?.committed ?? 0,
          { timeout: 15_000 },
        )
        .toBeGreaterThan(before.committed!);
      const after = (await psu543Records(page))
        .filter((record) => record.direction === 'response' && record.status === 'ready')
        .at(-1)!;
      audit.afterLiveEdit = after;
      expect(after.generationId).toBe(before.generationId);
      expect(after.committed).toBe(after.requested);
      expect(after.solved).toBe(true);
      const beforeState = JSON.parse(before.serializedState!);
      const afterState = JSON.parse(after.serializedState!);
      expect(afterState.boards[0].runtime.virtualTimeMs).toBeGreaterThanOrEqual(
        beforeState.boards[0].runtime.virtualTimeMs,
      );
      expect(afterState.boards[0].runtime.pinModes).toEqual(beforeState.boards[0].runtime.pinModes);
      expect(afterState.physicalState.simulationTimeMs).toBeGreaterThan(
        beforeState.physicalState.simulationTimeMs,
      );
      const requests = (await psu543Records(page)).filter(
        (record) => record.direction === 'request',
      );
      expect(
        requests
          .flatMap((record) => record.inputEvents ?? [])
          .some((event) => event.operation === 'voltageSetpointVolt' && event.payload === 7.5),
      ).toBe(true);
      expect(
        requests
          .flatMap((record) => record.inputEvents ?? [])
          .some((event) => event.operation === 'currentLimitAmp' && event.payload === 0.15),
      ).toBe(true);
      // Output stays runtime-only while both saved settings are already local.
      await inspector.getByLabel('Включить выход лабораторного источника').uncheck();
      await expect(visual).toHaveAttribute('data-regulation-mode', 'off');
      audit.localWhileOutputOff = JSON.parse((await e01LocalDraft(page, id))!);
      expect(puts).toHaveLength(0);
      await page.screenshot({ path: `${evidenceDir}/psu-${width}-running.png`, fullPage: true });
      audit.beforeStopRecords = await psu543Records(page);
      await page.getByRole('button', { name: 'Остановить моделирование', exact: true }).click();
      // The old product loses U/I at this exact pupil action; keep these asserts.
      await expect(voltage).toHaveValue('7.5');
      await expect(limit).toHaveValue('0.15');
      expect((audit.localWhileOutputOff as { document: SchematicDocument }).document).toEqual(
        expected(7.5, 0.15),
      );
      await expect(visual).toHaveAttribute('data-output-enabled', 'true');
      await page.getByRole('button', { name: 'Начать моделирование', exact: true }).click();
      await expect(visual).toHaveAttribute('data-regulation-mode', 'cv');
      await expect
        .poll(async () =>
          (await psu543Records(page)).some(
            (record) =>
              record.direction === 'response' &&
              record.generationId !== before.generationId &&
              record.status === 'ready' &&
              record.committed === 0 &&
              record.requested === 0,
          ),
        )
        .toBe(true);
      await expect(voltage).toHaveValue('7.5');
      await expect(limit).toHaveValue('0.15');
      const save = page.getByRole('button', { name: 'Сохранить проект', exact: true });
      await save.click();
      await expect(page.locator('.workbench-main')).toHaveAttribute(
        'data-project-save-status',
        'saved',
      );
      const manual = await e01Server(page, id);
      audit.manualSave = manual;
      expect(manual.draft.document).toEqual(expected(7.5, 0.15));
      expect(manual.draft.revision).toBe(seeded.draft.revision + 1);
      expect(puts).toHaveLength(1);
      expect(puts[0]!.document).toEqual(manual.draft.document);
      await page.getByRole('button', { name: 'Остановить моделирование', exact: true }).click();
      let latest = manual;
      if (width === 1440) {
        // Real quiet minute, with no clock install/fastForward, pagehide, focus,
        // reload or additional edit used to cause the eventual request.
        await voltage.fill('6.5');
        await limit.fill('0.12');
        const quietStarted = Date.now();
        expect(puts).toHaveLength(1);
        await expect.poll(() => puts.length, { timeout: 65_000 }).toBe(2);
        await expect(page.locator('.workbench-main')).toHaveAttribute(
          'data-project-save-status',
          'saved',
        );
        latest = await e01Server(page, id);
        audit.quietAutosave = {
          quietStarted,
          sentAt: puts[1]!.at,
          elapsed: puts[1]!.at - quietStarted,
          server: latest,
        };
        expect(puts[1]!.at - quietStarted).toBeGreaterThanOrEqual(59_000);
        expect(latest.draft.document).toEqual(expected(6.5, 0.12));
        expect(latest.draft.revision).toBe(manual.draft.revision + 1);
        expect(puts[1]!.document).toEqual(latest.draft.document);
      }
      expect(await e01PendingLocalDraft(page, id)).toBeNull();
      profile = await browser.newContext({
        baseURL: new URL(page.url()).origin,
        viewport: { width, height: 900 },
      });
      await profile.addCookies(await page.context().cookies());
      reopened = await profile.newPage();
      await observePsuPersistenceWorker(reopened);
      const reopenedFailures = collectBrowserFailures(reopened, {
        allowAnonymousSessionProbe: true,
      });
      await reopened.goto(`/#/home/${id}`);
      await expect(reopened.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
      expect(await e01LocalDraft(reopened, id)).toBeNull();
      await component(reopened, 'regulated-power-supply').locator('.workbench-part').press('Enter');
      if (width <= 980) {
        const catalogToggle = reopened.getByRole('button', {
          name: 'Каталог деталей',
          exact: true,
        });
        await expect(catalogToggle).toHaveAttribute('aria-pressed', 'true');
        await catalogToggle.click();
        await expect(catalogToggle).toHaveAttribute('aria-pressed', 'false');
        await expect(
          reopened.getByRole('complementary', { name: 'Параметры выделения' }),
        ).toBeVisible();
      }
      const latestSupply = latest.draft.document.components.find(
        (part) => part.id === 'bench-supply',
      )!;
      await expect(reopened.getByLabel('Уставка напряжения лабораторного источника')).toHaveValue(
        String(latestSupply.value),
      );
      await expect(reopened.getByLabel('Ограничение тока лабораторного источника')).toHaveValue(
        String(latestSupply.stateProperties!.currentLimitAmp),
      );
      audit.cookiesOnlyServer = await e01Server(reopened, id);
      expect((audit.cookiesOnlyServer as typeof latest).draft).toEqual(latest.draft);
      await reopened.getByRole('button', { name: 'Открыть редактор кода', exact: true }).click();
      await expect(reopened.getByLabel('Код Arduino C++', { exact: true })).toHaveValue(source);
      await reopened.getByRole('button', { name: 'Закрыть редактор кода', exact: true }).click();
      await reopened.getByRole('button', { name: 'Начать моделирование', exact: true }).click();
      const load = latest.draft.document.components.find((part) => part.id === 'load')!;
      const outputResistance = Number(latestSupply.stateProperties!.outputResistanceOhm);
      const expectedCurrent = Number(latestSupply.value) / (load.value + outputResistance);
      const expectedVoltage = expectedCurrent * load.value;
      // CV alone can be a pre-ready fallback. Require a genuine complete
      // electrical frame from this new page before checking its publication.
      await expect
        .poll(async () =>
          (await psu543Records(reopened!)).some(
            (record) =>
              record.direction === 'response' &&
              record.status === 'ready' &&
              record.committed === record.requested &&
              record.solved === true &&
              record.resultStatus === 'solved' &&
              record.quality?.finite === true &&
              record.quality.passed === true &&
              record.supplyResult?.regulationMode === 'cv' &&
              Number.isFinite(record.supplyResult.voltageDrop) &&
              Number.isFinite(record.supplyResult.current) &&
              Math.abs(record.supplyResult.voltageDrop - expectedVoltage) < 1e-9 &&
              Math.abs(Math.abs(record.supplyResult.current) - expectedCurrent) < 1e-9,
          ),
        )
        .toBe(true);
      const reopenedVisual = component(reopened, 'regulated-power-supply').getByTestId(
        'regulated-power-supply-runtime',
      );
      await expect(
        component(reopened, 'regulated-power-supply').getByTestId('regulated-power-supply-runtime'),
      ).toHaveAttribute('data-regulation-mode', 'cv');
      await expect(
        reopenedVisual.locator('.workbench-regulated-supply-reading').nth(0),
      ).toContainText(`${expectedVoltage.toFixed(2)} V`);
      await expect(
        reopenedVisual.locator('.workbench-regulated-supply-reading').nth(1),
      ).toContainText(`${expectedCurrent.toFixed(3)} A`);
      audit.reopenedElectricalPublication = await reopened.evaluate(() => {
        const records = (window as Window & { __psu543?: Psu543Sample[] }).__psu543 ?? [];
        const visual = document.querySelector('[data-testid="regulated-power-supply-runtime"]');
        return {
          at: performance.now(),
          latestReady: records
            .filter((record) => record.direction === 'response' && record.status === 'ready')
            .at(-1),
          voltageText: visual?.querySelectorAll('.workbench-regulated-supply-reading')[0]
            ?.textContent,
          currentText: visual?.querySelectorAll('.workbench-regulated-supply-reading')[1]
            ?.textContent,
        };
      });
      await reopened.screenshot({
        path: `${evidenceDir}/psu-${width}-reopened.png`,
        fullPage: true,
      });
      reopenedFailures.assertEmpty();
      failures.assertEmpty();
    } finally {
      audit.workerRecords = await psu543Records(page).catch(() => []);
      audit.reopenedWorkerRecords = reopened ? await psu543Records(reopened).catch(() => []) : [];
      audit.puts = puts;
      audit.layouts = snapshots;
      const path = `${evidenceDir}/psu-${width}-raw.json`;
      writeFileSync(path, JSON.stringify(audit, null, 2));
      await testInfo.attach(`psu-${width}-raw`, { path, contentType: 'application/json' });
      await profile?.close();
    }
  });
}

test('live generator waveform and frequency reach the scope calculation without a new generation', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await observeSimulationWorkerClock(page);
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Live generator continuity');
  const circuit: SchematicDocument = {
    schemaVersion: 4,
    components: [
      {
        id: 'generator',
        kind: 'source',
        componentTypeId: 'signal-generator',
        variantId: 'signal-generator',
        name: 'Генератор',
        position: { x: 270, y: 250 },
        rotation: 0,
        value: 1_000,
        state: true,
        pinIds: ['signal', 'ground'],
        stateProperties: {
          waveform: 'sine',
          frequencyHz: 1_000,
          amplitudeVpp: 5,
          dcOffsetVolt: 0,
          outputEnabled: true,
          outputResistanceOhm: 50,
          maxContinuousCurrentAmp: 0.1,
        },
      },
      {
        id: 'scope',
        kind: 'visual',
        componentTypeId: 'oscilloscope',
        variantId: 'oscilloscope',
        name: 'Осциллограф',
        position: { x: 720, y: 310 },
        rotation: 0,
        value: 1,
        state: true,
        pinIds: ['signal', 'ground'],
        stateProperties: {
          voltsPerDivision: 1,
          timePerDivisionMs: 1,
          triggerLevelVolt: 0,
          displayEnabled: true,
        },
      },
    ],
    connections: [
      {
        id: 'signal',
        from: { componentId: 'generator', terminal: 'signal' },
        to: { componentId: 'scope', terminal: 'signal' },
        color: '#e3212b',
        vertices: [],
      },
      {
        id: 'ground',
        from: { componentId: 'generator', terminal: 'ground' },
        to: { componentId: 'scope', terminal: 'ground' },
        color: '#2a3035',
        vertices: [],
      },
    ],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
  await saveDocument(page, projectId, circuit);
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  await expect
    .poll(
      async () =>
        (await simulationWorkerObservation(page)).workerSamples
          .filter((sample) => sample.status === 'ready')
          .at(-1)?.committedMicroseconds ?? 0,
      { timeout: 15_000 },
    )
    .toBeGreaterThan(100_000);
  const before = await simulationWorkerObservation(page);
  const generation = before.workerSamples
    .filter((sample) => sample.status === 'ready')
    .at(-1)!.generationId;
  const generator = component(page, 'signal-generator');
  await generator.locator('.workbench-part').press('Enter');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  await inspector.getByLabel('Форма сигнала').selectOption('square');
  await inspector.getByLabel('Частота генератора').fill('2');
  await expect(generator.getByTestId('signal-generator-runtime')).toHaveAttribute(
    'data-waveform',
    'square',
  );
  const scope = component(page, 'oscilloscope');
  await scope.locator('.workbench-part').press('Enter');
  const scopeReading = inspector.getByTestId('oscilloscope-panel-reading');
  await expect(scopeReading).toContainText('2 Гц');
  await expect
    .poll(async () => Number.parseFloat((await scopeReading.textContent()) ?? ''), {
      timeout: 15_000,
    })
    .toBeLessThan(-2.49);
  await expect
    .poll(async () => Number.parseFloat((await scopeReading.textContent()) ?? ''), {
      timeout: 15_000,
    })
    .toBeGreaterThan(2.49);
  const after = await simulationWorkerObservation(page);
  expect(
    after.workerSamples.filter((sample) => sample.status === 'ready').at(-1)?.generationId,
  ).toBe(generation);
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  await expect(page.locator('.workbench-simulation-message')).toHaveCount(0);
  const saved = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin: new URL(page.url()).origin },
  });
  expect(saved.ok()).toBe(true);
  const persisted = (await saved.json()) as { draft: { document: SchematicDocument } };
  expect(
    persisted.draft.document.components.find((item) => item.id === 'generator')?.stateProperties?.[
      'waveform'
    ],
  ).toBe('sine');
  expect(
    persisted.draft.document.components.find((item) => item.id === 'generator')?.stateProperties?.[
      'frequencyHz'
    ],
  ).toBe(1_000);
  failures.assertEmpty();
});

test('multimeter A/V/R changes stay local to one canonical generation', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await observeSimulationWorkerClock(page);
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Live meter mode continuity');
  await saveDocument(page, projectId, multimeterResistanceDocument(false));
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
  await page.getByRole('button', { name: 'Начать моделирование' }).click();
  const meter = component(page, 'multimeter');
  await meter.locator('.workbench-part').press('Enter');
  const inspector = page.getByRole('complementary', { name: 'Параметры выделения' });
  const mode = inspector.getByLabel('Режим мультиметра');
  await expect(mode).toBeEnabled();
  await expect(mode).toHaveValue('dc-voltage');
  await expect
    .poll(
      async () =>
        (await simulationWorkerObservation(page)).workerSamples.filter(
          (sample) => sample.status === 'ready',
        ).length,
    )
    .toBeGreaterThan(0);
  const initial = await simulationWorkerObservation(page);
  const generation = initial.workerSamples
    .filter((sample) => sample.status === 'ready')
    .at(-1)!.generationId;
  await meter.locator('.workbench-multimeter-mode-resistance').first().click();
  await expect(mode).toHaveValue('resistance');
  const display = meter.getByTestId('multimeter-runtime-display');
  await expect(display).toContainText('1.000 kΩ');
  await mode.selectOption('dc-current');
  await expect(display).toHaveAttribute('data-measurement-mode', 'dc-current');
  await mode.selectOption('dc-voltage');
  await expect(display).toHaveAttribute('data-measurement-mode', 'dc-voltage');
  const after = await simulationWorkerObservation(page);
  expect(
    after.workerSamples.filter((sample) => sample.status === 'ready').at(-1)?.generationId,
  ).toBe(generation);
  expect(
    after.workerSamples.filter((sample) => sample.status === 'ready').at(-1)?.committedMicroseconds,
  ).toBeGreaterThanOrEqual(
    initial.workerSamples.filter((sample) => sample.status === 'ready').at(-1)!
      .committedMicroseconds,
  );
  await expect(page.getByRole('button', { name: 'Остановить моделирование' })).toBeVisible();
  const saved = await page.context().request.get(`/api/projects/${projectId}`, {
    headers: { origin: new URL(page.url()).origin },
  });
  expect(saved.ok()).toBe(true);
  const persisted = (await saved.json()) as { draft: { document: SchematicDocument } };
  expect(
    persisted.draft.document.components.find((item) => item.id === 'meter')?.stateProperties?.[
      'measurementMode'
    ],
  ).toBe('dc-voltage');
  await page.getByRole('button', { name: 'Остановить моделирование' }).click();
  failures.assertEmpty();
});

test('RGB LED visibly mixes the saved 3 V red and blue owner wiring', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'R4-M1 RGB red blue 3 V regression');
  await saveDocument(page, projectId, ownerRedBlueRgbDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible();
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const rgb = component(page, 'rgb-led');
  const visual = rgb.locator('.workbench-production-visual');
  await expect(visual).toHaveAttribute('data-rgb-runtime-state', 'lit');
  const red = Number((await visual.getAttribute('data-rgb-red')) ?? '0');
  const green = Number((await visual.getAttribute('data-rgb-green')) ?? '0');
  const blue = Number((await visual.getAttribute('data-rgb-blue')) ?? '0');
  expect(red).toBeGreaterThan(0);
  expect(green).toBe(0);
  expect(blue).toBeGreaterThan(red);
  await expect(visual).not.toHaveAttribute('data-rgb-colour', /^rgb\((?:0, 0, 0|255, 0, 0)\)$/);
  await expect(rgb.getByTestId('rgb-led-mixture')).toHaveCSS('opacity', /^(?!0(?:\.0+)?$)/);
  await expect(diagnostic(page, 'rgb-led', 'rgb-led-burnout-explosion')).toHaveCount(0);
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-rgb-red-blue-3v.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('RGB LED visibly mixes equal 220 ohm green and blue branches at 3 V', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const projectId = await createProject(page, 'R4-M1 RGB green blue equal 220 ohm regression');
  await saveDocument(page, projectId, ownerGreenBlueEqualRgbDocument());
  await page.goto(`/#/home/${projectId}`);
  await expect(page.locator('.workbench-stage')).toBeVisible({ timeout: 15_000 });
  await page.getByRole('button', { name: 'Начать моделирование' }).click();

  const rgb = component(page, 'rgb-led');
  const visual = rgb.locator('.workbench-production-visual');
  await expect(visual).toHaveAttribute('data-rgb-runtime-state', 'lit');
  const red = Number((await visual.getAttribute('data-rgb-red')) ?? '0');
  const green = Number((await visual.getAttribute('data-rgb-green')) ?? '0');
  const blue = Number((await visual.getAttribute('data-rgb-blue')) ?? '0');
  expect(red).toBe(0);
  expect(green).toBeGreaterThan(0);
  expect(blue).toBeGreaterThanOrEqual(green * 0.45);
  expect(blue).toBeLessThan(green);

  const mixture = rgb.getByTestId('rgb-led-mixture');
  const displayColour = (await mixture.getAttribute('fill')) ?? '';
  const channels = displayColour.match(/^rgb\((\d+), (\d+), (\d+)\)$/);
  expect(channels).not.toBeNull();
  expect(Number(channels?.[1] ?? 0)).toBe(0);
  expect(Number(channels?.[2] ?? 0)).toBe(255);
  expect(Number(channels?.[3] ?? 0)).toBeGreaterThanOrEqual(110);
  await expect(rgb).toHaveAttribute('data-diagnostics', '');
  await expect(page.getByTestId('component-diagnostic-indicator')).toHaveCount(0);
  await page.screenshot({
    path: `${ARTIFACT_DIR}/electronics-rgb-green-blue-equal-220.png`,
    fullPage: true,
  });
  failures.assertEmpty();
});

test('RGB LED mirrors ordinary LED lit, reverse-polarity and burnout states', async ({ page }) => {
  test.setTimeout(120_000);
  const failures = collectBrowserFailures(page, { allowAnonymousSessionProbe: true });
  await page.setViewportSize({ width: 1920, height: 1080 });
  await loginWithOrganization(page, teacher);

  const scenarios = [
    {
      name: 'single-green',
      document: singleChannelRgbLedDocument({
        componentMode: 'common-cathode',
        wiringMode: 'common-cathode',
        resistorOhms: 220,
      }),
      runtimeState: 'lit',
      diagnostic: null,
    },
    {
      name: 'owner-reversed-common',
      document: singleChannelRgbLedDocument({
        componentMode: 'common-cathode',
        wiringMode: 'common-anode',
        resistorOhms: null,
      }),
      runtimeState: 'off',
      diagnostic: 'reverse_polarity',
    },
    {
      name: 'direct-overload',
      document: singleChannelRgbLedDocument({
        componentMode: 'common-anode',
        wiringMode: 'common-anode',
        resistorOhms: null,
      }),
      runtimeState: 'burned',
      diagnostic: 'led_burnout',
    },
  ] as const;

  for (const scenario of scenarios) {
    const projectId = await createProject(page, `R4-M1 RGB ${scenario.name}`);
    await saveDocument(page, projectId, scenario.document);
    await page.goto(`/#/home/${projectId}`);
    await expect(page.locator('.workbench-stage')).toBeVisible();
    await page.getByRole('button', { name: 'Начать моделирование' }).click();

    const rgb = component(page, 'rgb-led');
    const visual = rgb.locator('.workbench-production-visual');
    await expect(visual).toHaveAttribute('data-rgb-runtime-state', scenario.runtimeState);
    if (scenario.runtimeState === 'lit') {
      await expect(visual).toHaveAttribute('data-rgb-red', '0');
      await expect
        .poll(async () => Number((await visual.getAttribute('data-rgb-green')) ?? '0'))
        .toBeGreaterThan(0);
      await expect(visual).toHaveAttribute('data-rgb-blue', '0');
      await expect(rgb.getByTestId('rgb-led-mixture')).toHaveCSS('opacity', /^(?!0(?:\.0+)?$)/);
    } else {
      await expect(rgb).toHaveAttribute('data-diagnostics', new RegExp(scenario.diagnostic ?? ''));
      await expect(rgb.getByTestId('rgb-led-mixture')).toHaveCSS('opacity', '0');
    }
    if (scenario.diagnostic === 'reverse_polarity') {
      await expect(diagnostic(page, 'rgb-led', 'led-diagnostic-badge')).toHaveCount(0);
      await expect(diagnostic(page, 'rgb-led', 'rgb-led-burnout-explosion')).toHaveCount(0);
    }
    if (scenario.runtimeState === 'burned') {
      await expect(diagnostic(page, 'rgb-led', 'rgb-led-burnout-explosion')).toBeVisible();
      await expect(diagnostic(page, 'rgb-led', 'rgb-led-burnout-explosion')).toHaveAttribute(
        'aria-label',
        /перегорел/i,
      );
    }
  }
  failures.assertEmpty();
});

test('Electronics automatic save retry waits a minute and preserves latest work', async ({
  page,
}) => {
  test.setTimeout(120_000);
  const evidenceDir = 'reports/playwright/electronics-save-retry';
  mkdirSync(evidenceDir, { recursive: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await loginWithOrganization(page, teacher);
  const projectId = await createProject(page, 'Owner point4 minute retry');
  await saveDocument(page, projectId, e01Document());
  await page.goto(`/#/home/${projectId}`);
  await component(page, 'resistor-axial').locator('.workbench-part').press('Enter');
  const value = page
    .locator('.workbench-inspector label')
    .filter({ hasText: 'Сопротивление' })
    .locator('input[type="number"]');
  await expect(value).toHaveValue('50');
  const requests: { at: number; body: unknown }[] = [];
  const replies: { at: number; status: number }[] = [];
  page.on('request', (request) => {
    if (
      request.method() === 'PUT' &&
      new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
    )
      requests.push({ at: Date.now(), body: request.postDataJSON() });
  });
  page.on('response', (response) => {
    if (
      response.request().method() === 'PUT' &&
      new URL(response.url()).pathname === `/api/projects/${projectId}/draft`
    )
      replies.push({ at: Date.now(), status: response.status() });
  });
  let failureSentAt = 0;
  let failed = false;
  await page.route(`**/api/projects/${projectId}/draft`, async (route) => {
    if (route.request().method() === 'PUT' && !failed) {
      failed = true;
      failureSentAt = Date.now();
      await route.fulfill({
        status: 503,
        contentType: 'application/json',
        body: JSON.stringify({ code: 'temporary', message: 'Temporary transport failure' }),
      });
    } else await route.continue();
  });
  await value.fill('166.7');
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'error',
  );
  expect(requests).toHaveLength(1);
  await expect.poll(() => replies[0]?.status).toBe(503);
  // Real elapsed browser time: no fake clock, online/focus event, reload or
  // manual retry wakes the automatic retry during this quiet interval.
  await page.waitForTimeout(30_000);
  writeFileSync(
    `${evidenceDir}/quiet-30s.json`,
    JSON.stringify(
      {
        failureSentAt,
        capturedAt: Date.now(),
        requests,
        replies,
        local: await e01LocalDraft(page, projectId),
      },
      null,
      2,
    ),
  );
  expect(requests).toHaveLength(1);
  await value.fill('220.5');
  const localDuringDelay = JSON.parse((await e01LocalDraft(page, projectId)) ?? 'null') as {
    document: SchematicDocument;
  } | null;
  expect(localDuringDelay?.document.components.find((item) => item.id === 'resistor')?.value).toBe(
    220.5,
  );
  await page.waitForTimeout(Math.max(0, failureSentAt + 59_000 - Date.now()));
  writeFileSync(
    `${evidenceDir}/quiet-59s.json`,
    JSON.stringify(
      { failureSentAt, capturedAt: Date.now(), requests, replies, localDuringDelay },
      null,
      2,
    ),
  );
  expect(requests).toHaveLength(1);
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'error',
  );
  await expect
    .poll(() => replies.filter((reply) => reply.status === 200).length, {
      timeout: 10_000,
      intervals: [100],
    })
    .toBe(1);
  expect(requests).toHaveLength(2);
  expect(requests[1]!.at - failureSentAt).toBeGreaterThanOrEqual(60_000);
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const automaticServer = await e01Server(page, projectId);
  expect(
    automaticServer.draft.document.components.find((item) => item.id === 'resistor')?.value,
  ).toBe(220.5);
  expect(await e01PendingLocalDraft(page, projectId)).toBeNull();

  // A deliberate save remains immediate after another pupil edit.
  await value.fill('330.5');
  const manualLocal = JSON.parse((await e01LocalDraft(page, projectId)) ?? 'null') as {
    document: SchematicDocument;
  } | null;
  expect(manualLocal?.document.components.find((item) => item.id === 'resistor')?.value).toBe(
    330.5,
  );
  const manualRequestedAt = Date.now();
  await page.getByRole('button', { name: 'Сохранить проект', exact: true }).click();
  await expect.poll(() => replies.filter((reply) => reply.status === 200).length).toBe(2);
  expect(requests).toHaveLength(3);
  expect(requests[2]!.at - manualRequestedAt).toBeLessThan(10_000);
  await expect(page.locator('.workbench-main')).toHaveAttribute(
    'data-project-save-status',
    'saved',
  );
  const manualServer = await e01Server(page, projectId);
  expect(manualServer.draft.document.components.find((item) => item.id === 'resistor')?.value).toBe(
    330.5,
  );
  writeFileSync(
    `${evidenceDir}/minute-retry.json`,
    JSON.stringify(
      {
        projectId,
        failureSentAt,
        requests,
        replies,
        localDuringDelay,
        automaticServer,
        manualRequestedAt,
        manualLocal,
        manualServer,
        finalLocal: await e01LocalDraft(page, projectId),
      },
      null,
      2,
    ),
  );
  await page.screenshot({ path: `${evidenceDir}/saved-latest-1440.png`, fullPage: true });
});

// TASK-ELECTRONICS-MOBILE-ADD-CONNECT-001: identical native BEFORE/AFTER probes.
const mobilePlacementTest = test.extend({ hasTouch: true });
type MobilePoint = { x: number; y: number };
type MobileCaseInfo = import('@playwright/test').TestInfo;

function mobileEmptyDocument(): SchematicDocument {
  return {
    schemaVersion: 4,
    components: [],
    connections: [],
    viewport: { x: 0, y: 0, zoom: 1 },
    simulation: { running: false, maxIterations: 24 },
  };
}

function mobileFourComponentDocument(): SchematicDocument {
  const existing = circuitDocument({ switchClosed: false, resistorOhms: 220, reversedLed: false });
  const original = existing.components.filter((part) => part.id !== 'board');
  const identities: Record<string, readonly [string, string]> = {
    source: ['ideal-dc-source', 'generic-battery-pack-aa-2'],
    switch: ['spdt-switch', 'slide-switch-spdt'],
    resistor: ['resistor', 'axial-resistor'],
    led: ['ordinary-led', 'generic-red-led'],
  };
  const components = original.map((part) => {
    const [electricalModelId, modelProfileId] = identities[part.id]!;
    return {
      ...part,
      electricalModelId,
      electricalModelVersion: 1,
      modelProfileId,
      modelProfileVersion: 1,
      ...(part.id === 'resistor'
        ? { stateProperties: { ...part.stateProperties, powerRatingWatt: 0.25 } }
        : {}),
    };
  });
  expect(
    components.map(
      ({
        electricalModelId,
        electricalModelVersion,
        modelProfileId,
        modelProfileVersion,
        ...part
      }) => {
        expect([electricalModelId, modelProfileId]).toEqual(identities[part.id]);
        expect([electricalModelVersion, modelProfileVersion]).toEqual([1, 1]);
        if (part.id === 'resistor') {
          const { powerRatingWatt, ...stateProperties } = part.stateProperties!;
          expect(powerRatingWatt).toBe(0.25);
          return { ...part, stateProperties };
        }
        return part;
      },
    ),
  ).toEqual(original);
  expect(components).toHaveLength(4);
  return { ...existing, components, connections: [] };
}

async function mobilePlacementJourney(
  page: Page,
  info: MobileCaseInfo,
  initial: SchematicDocument,
  run: (tools: {
    read: () => Promise<SchematicDocument>;
    checkpoint: (name: string, extra?: unknown) => Promise<void>;
    puts: unknown[];
  }) => Promise<SchematicDocument | null>,
): Promise<void> {
  const entries: unknown[] = [];
  const puts: unknown[] = [];
  const errors: string[] = [];
  const journal: Record<string, unknown> = { title: info.title, initial, entries, puts, errors };
  const write = () =>
    writeFileSync(info.outputPath('mobile-add-connect.json'), JSON.stringify(journal, null, 2));
  let projectId = '';
  let localKey = '';
  let userId = '';
  let fresh: import('@playwright/test').BrowserContext | undefined;
  const read = async (): Promise<SchematicDocument> => {
    const raw = await page.evaluate((key) => localStorage.getItem(key), localKey);
    if (raw === null) return initial;
    const record = JSON.parse(raw) as {
      schemaVersion: number;
      identityKind: string;
      userId: string;
      projectId: string;
      moduleKey: string;
      document: SchematicDocument;
    };
    expect(record).toMatchObject({
      schemaVersion: 3,
      identityKind: 'account',
      userId,
      projectId,
      moduleKey: 'electronics',
    });
    return record.document;
  };
  const checkpoint = async (name: string, extra?: unknown) => {
    journal['checkpoint'] = name;
    entries.push({ name, extra });
    write(); // Keep Node-owned originals even if the next browser call fails.
    const observation = await page.evaluate((key) => {
      const bounds = (selector: string) =>
        [...document.querySelectorAll(selector)].map((node) => {
          const box = node.getBoundingClientRect();
          return {
            className: node.getAttribute('class'),
            x: box.x,
            y: box.y,
            width: box.width,
            height: box.height,
          };
        });
      const canvas = document.querySelector<SVGSVGElement>('.workbench-canvas');
      return {
        events: (window as unknown as { mobilePlacementEvents?: unknown[] }).mobilePlacementEvents,
        observerReady: (window as unknown as { mobilePlacementObserverReady?: boolean })
          .mobilePlacementObserverReady,
        local: localStorage.getItem(key),
        viewBox: canvas?.getAttribute('viewBox'),
        matrix: canvas?.getScreenCTM()?.toString(),
        canvasClass: canvas?.getAttribute('class'),
        bounds: bounds(
          '.workbench-stage,.workbench-library,.workbench-inspector,.workbench-stage-controls',
        ),
        scrollWidth: document.documentElement.scrollWidth,
        clientWidth: document.documentElement.clientWidth,
        statuses: [...document.querySelectorAll('[role="status"]')].map((node) => node.textContent),
      };
    }, localKey);
    entries.push({ name, observation });
    write();
    expect(observation.observerReady).toBe(true);
    expect(Array.isArray(observation.events)).toBe(true);
    if (['tap-selected', 'before-cancel', 'first-terminal-pending'].includes(name)) {
      const events = observation.events as {
        type: string;
        trusted: boolean;
        pointerType: string;
      }[];
      for (const type of ['pointerdown', 'pointerup']) {
        expect(
          events.some(
            (event) => event.type === type && event.trusted && event.pointerType === 'touch',
          ),
        ).toBe(true);
      }
    }
    expect(observation.scrollWidth).toBeLessThanOrEqual(observation.clientWidth);
    if (['tap-selected', 'before-cancel', 'desktop-keyboard-placement'].includes(name)) {
      await page.screenshot({ path: info.outputPath(`mobile-${entries.length}-placement.png`) });
    }
  };
  try {
    const targetViewport = page.viewportSize();
    expect(targetViewport).not.toBeNull();
    journal['targetViewport'] = targetViewport;
    await page.setViewportSize({ width: 1440, height: 900 });
    await loginWithOrganization(page, teacher);
    const session = await page.context().request.get('/api/auth/me');
    expect(session.status()).toBe(200);
    const actor = (await session.json()) as { authenticated: boolean; user: { id: string } };
    expect(actor.authenticated).toBe(true);
    userId = actor.user.id;
    projectId = await createProject(page, 'R4-M1 live simulation');
    localKey = `asa-project-local-draft:user:account:${encodeURIComponent(actor.user.id)}:${encodeURIComponent(projectId)}`;
    await saveDocument(page, projectId, initial);
    const seed = await e01Server(page, projectId);
    expect(seed.draft.document).toEqual(initial);
    journal['projectId'] = projectId;
    journal['seed'] = seed;
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('request', (request) => {
      if (
        request.method() === 'PUT' &&
        new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
      ) {
        puts.push(request.postDataJSON());
        write();
      }
    });
    const installPassiveJournal = () => {
      const probe = window as unknown as {
        mobilePlacementEvents?: unknown[];
        mobilePlacementObserverReady?: boolean;
      };
      if (probe.mobilePlacementObserverReady) return;
      const events = probe.mobilePlacementEvents ?? [];
      probe.mobilePlacementEvents = events;
      for (const type of [
        'pointerdown',
        'pointerup',
        'pointercancel',
        'gotpointercapture',
        'lostpointercapture',
        'click',
        'touchstart',
        'touchend',
        'touchcancel',
      ]) {
        window.addEventListener(
          type,
          (event) => {
            const pointer = event as PointerEvent;
            const target = event.target instanceof Element ? event.target : null;
            events.push({
              type,
              trusted: event.isTrusted,
              pointerType: pointer.pointerType,
              id: pointer.pointerId,
              x: pointer.clientX,
              y: pointer.clientY,
              target: target?.getAttribute('class'),
              terminal: target?.getAttribute('data-terminal-id'),
              component: target?.getAttribute('data-terminal-component-id'),
              touches: (event as TouchEvent).touches?.length,
            });
          },
          { capture: true, passive: true },
        );
      }
      probe.mobilePlacementObserverReady = true;
    };
    await page.addInitScript(installPassiveJournal);
    await page.evaluate(installPassiveJournal);
    await page.setViewportSize(targetViewport!);
    await openProject(page, projectId);
    await checkpoint('opened');
    const expected = await run({ read, checkpoint, puts });
    expect(puts).toHaveLength(0);
    if (expected) {
      expect(await read()).toEqual(expected);
      await page.getByRole('button', { name: 'Сохранить проект', exact: true }).tap();
      await expect
        .poll(async () => (await e01Server(page, projectId)).draft.document)
        .toEqual(expected);
      const saved = await e01Server(page, projectId);
      expect(saved.draft.revision).toBe(seed.draft.revision + 1);
      expect(puts).toHaveLength(1);
      expect((puts[0] as { document: SchematicDocument }).document).toEqual(expected);
      expect((puts[0] as { baseRevision: number }).baseRevision).toBe(seed.draft.revision);
      journal['saved'] = saved;
      await checkpoint('saved', expected);
      const viewport = page.viewportSize()!;
      fresh = await page
        .context()
        .browser()!
        .newContext({ baseURL: new URL(page.url()).origin, viewport, hasTouch: true });
      await fresh.addCookies(await page.context().cookies());
      const freshOrigins = (await fresh.storageState()).origins;
      journal['freshStorageOrigins'] = freshOrigins;
      write();
      expect(freshOrigins).toEqual([]);
      await fresh.addInitScript((appOrigin: string) => {
        if (window !== window.top || window.location.origin !== appOrigin) return;
        const entries = (storage: Storage) =>
          Object.keys(storage).map((key) => [key, storage.getItem(key)]);
        (
          window as unknown as {
            mobilePlacementPreAppStorage?: {
              local: (string | null)[][];
              session: (string | null)[][];
            };
          }
        ).mobilePlacementPreAppStorage = {
          local: entries(localStorage),
          session: entries(sessionStorage),
        };
      }, new URL(page.url()).origin);
      const reopened = await fresh.newPage();
      reopened.on('pageerror', (error) => errors.push(`reopened: ${error.message}`));
      reopened.on('request', (request) => {
        if (
          request.method() === 'PUT' &&
          new URL(request.url()).pathname === `/api/projects/${projectId}/draft`
        ) {
          puts.push(request.postDataJSON());
          write();
        }
      });
      const delivery = reopened.waitForResponse(
        (response) =>
          response.request().method() === 'GET' &&
          new URL(response.url()).pathname === `/api/projects/${projectId}`,
      );
      await reopened.goto(`/#/home/${projectId}`);
      const preAppStorage = await reopened.evaluate(
        () =>
          (
            window as unknown as {
              mobilePlacementPreAppStorage?: unknown;
            }
          ).mobilePlacementPreAppStorage,
      );
      journal['preAppStorage'] = preAppStorage;
      write();
      expect(preAppStorage).toEqual({ local: [], session: [] });
      await expect(reopened.getByTestId('schematic-component')).toHaveCount(
        expected.components.length,
      );
      const delivered = await delivery;
      expect(delivered.status()).toBe(200);
      expect(((await delivered.json()) as { draft: unknown }).draft).toEqual(saved.draft);
      const reopenedDraftStorage = await reopened.evaluate(() => ({
        local: Object.keys(localStorage)
          .filter((key) => key.startsWith('asa-project-local-draft:'))
          .map((key) => [key, localStorage.getItem(key)]),
        session: Object.keys(sessionStorage)
          .filter((key) => key.startsWith('asa-project-local-draft:'))
          .map((key) => [key, sessionStorage.getItem(key)]),
      }));
      journal['reopenedDraftStorage'] = reopenedDraftStorage;
      write();
      expect(reopenedDraftStorage).toEqual({
        local: [],
        session: [[`${localKey}:electronics-editor:`, 'saved']],
      });
      expect((await e01Server(reopened, projectId)).draft).toEqual(saved.draft);
      const rendered = await reopened.getByTestId('schematic-component').evaluateAll((nodes) =>
        nodes.map((node) => ({
          id: node.getAttribute('data-component-id'),
          x: Number(node.getAttribute('data-x')),
          y: Number(node.getAttribute('data-y')),
        })),
      );
      expect(rendered).toEqual(
        expected.components.map((part) => ({
          id: part.id,
          x: part.position.x,
          y: part.position.y,
        })),
      );
      await expect(reopened.getByTestId('schematic-wire')).toHaveCount(expected.connections.length);
      journal['reopened'] = { server: await e01Server(reopened, projectId), rendered };
      await reopened.screenshot({ path: info.outputPath('mobile-reopened.png') });
      expect(puts).toHaveLength(1);
    } else {
      expect(await read()).toEqual(initial);
      expect((await e01Server(page, projectId)).draft).toEqual(seed.draft);
    }
    expect(errors).toEqual([]);
    await checkpoint('complete');
  } catch (error) {
    journal['primaryFailure'] = String(error);
    write();
    throw error;
  } finally {
    journal['testErrors'] = info.errors.map((error) => ({
      message: error.message,
      stack: error.stack,
    }));
    write();
    for (const [name, capture] of [
      ['final-browser', () => checkpoint('final-browser')],
      [
        'final-server',
        async () => {
          if (projectId) journal['finalServer'] = await e01Server(page, projectId);
        },
      ],
      ['final-png', () => page.screenshot({ path: info.outputPath('mobile-final.png') })],
      [
        'fresh-close',
        async () => {
          await fresh?.close();
        },
      ],
    ] as const) {
      try {
        await capture();
      } catch (error) {
        entries.push({ unavailable: name, error: String(error) });
      }
      write();
    }
    try {
      await info.attach('mobile-add-connect-originals', {
        path: info.outputPath('mobile-add-connect.json'),
        contentType: 'application/json',
      });
    } catch (error) {
      entries.push({ unavailable: 'attachment', error: String(error) });
      write();
    }
  }
}

async function mobileNativeDrag(
  page: Page,
  from: MobilePoint,
  to: MobilePoint,
  cancel = false,
): Promise<void> {
  const session = await page.context().newCDPSession(page);
  try {
    await session.send('Input.dispatchTouchEvent', {
      type: 'touchStart',
      touchPoints: [{ id: 1, ...from }],
    });
    for (let step = 1; step <= 8; step++)
      await session.send('Input.dispatchTouchEvent', {
        type: 'touchMove',
        touchPoints: [
          {
            id: 1,
            x: from.x + ((to.x - from.x) * step) / 8,
            y: from.y + ((to.y - from.y) * step) / 8,
          },
        ],
      });
    await session.send('Input.dispatchTouchEvent', {
      type: cancel ? 'touchCancel' : 'touchEnd',
      touchPoints: [],
    });
  } finally {
    await session.detach();
  }
}

async function mobileTerminalPoint(page: Page, id: string, terminal: string): Promise<MobilePoint> {
  return page
    .locator(`[data-terminal-component-id="${id}"][data-terminal-id="${terminal}"]`)
    .evaluate((node) => {
      const box = node.getBoundingClientRect();
      const point = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
      const target = document.elementFromPoint(point.x, point.y);
      if (!target?.closest('.workbench-canvas')) throw new Error('Terminal is obscured by a panel');
      return point;
    });
}

async function mobileTapPlace(
  page: Page,
  read: () => Promise<SchematicDocument>,
  checkpoint: (name: string, extra?: unknown) => Promise<void>,
  fraction: number,
): Promise<SchematicDocument> {
  const before = await read();
  const shelf = page.locator('.workbench-library');
  if (await shelf.evaluate((node) => node.classList.contains('collapsed'))) {
    await page.getByRole('button', { name: 'Каталог деталей', exact: true }).tap();
  }
  await expect(shelf).not.toHaveClass(/collapsed/);
  const strip = page.locator('.workbench-catalog-grid');
  const stripBox = await strip.boundingBox();
  if (!stripBox) throw new Error('Missing component shelf');
  // Exercise real native horizontal scrolling, then return to the first card.
  const right = { x: stripBox.x + stripBox.width - 24, y: stripBox.y + stripBox.height / 2 };
  const left = { x: stripBox.x + 24, y: right.y };
  await mobileNativeDrag(page, right, left);
  await expect.poll(() => strip.evaluate((node) => node.scrollLeft)).toBeGreaterThan(0);
  await mobileNativeDrag(page, left, right);
  expect(await read()).toEqual(before);
  await page.getByRole('button', { name: 'Резистор', exact: true }).tap();
  await expect(shelf).toHaveClass(/collapsed/);
  await expect(page.locator('.workbench-canvas')).toHaveClass(/placing/);
  await checkpoint('tap-selected', { before });
  await expect
    .soft(page.getByRole('status').filter({ hasText: /резистор.*(?:место|поле)/is }))
    .toBeVisible();
  const placement = await page.locator('.workbench-canvas').evaluate((node, fraction) => {
    const canvas = node as SVGSVGElement;
    const box = canvas.getBoundingClientRect();
    const screen = { x: box.x + box.width * fraction, y: box.y + box.height * 0.7 };
    if (!document.elementFromPoint(screen.x, screen.y)?.classList.contains('workbench-grid-hit')) {
      throw new Error('Intended landing point is not exposed empty canvas');
    }
    const matrix = canvas.getScreenCTM();
    if (!matrix) throw new Error('Missing actual canvas screen matrix');
    const world = new DOMPoint(screen.x, screen.y).matrixTransform(matrix.inverse());
    return { screen, world: { x: world.x, y: world.y } };
  }, fraction);
  await checkpoint('before-landing', placement);
  await page.touchscreen.tap(placement.screen.x, placement.screen.y);
  await expect(page.getByTestId('schematic-component')).toHaveCount(before.components.length + 1);
  const actual = await read();
  const added = actual.components.filter(
    (part) => !before.components.some((old) => old.id === part.id),
  );
  expect(added).toHaveLength(1);
  const expected: SchematicDocument = {
    ...before,
    components: [
      ...before.components,
      {
        id: added[0]!.id,
        kind: 'resistor',
        componentTypeId: 'resistor-axial',
        variantId: 'resistor-axial',
        electricalModelId: 'resistor',
        electricalModelVersion: 1,
        modelProfileId: 'axial-resistor',
        modelProfileVersion: 1,
        position: {
          x: Math.round(placement.world.x - 12.7 / 2),
          y: Math.round(placement.world.y - 57.91 / 2),
        },
        value: 220,
        rotation: 0,
        name: 'Осевой резистор',
        stateProperties: { tolerancePercent: 5, resistanceUnit: 'Ω', powerRatingWatt: 0.25 },
        pinIds: ['lead-1', 'lead-2'],
      },
    ],
  };
  expect(actual).toEqual(expected);
  await expect(page.locator('.workbench-canvas')).not.toHaveClass(/placing/);
  await checkpoint('placed', { expected });
  return expected;
}

for (const [width, height] of [
  [320, 568],
  [390, 844],
  [568, 320],
] as const) {
  mobilePlacementTest(
    `MOBILE-ADD-CONNECT original280 tap four-to-five ${width}x${height}`,
    async ({ page }, info) => {
      await page.setViewportSize({ width, height });
      const initial = mobileFourComponentDocument();
      expect(initial.components).toHaveLength(4);
      await mobilePlacementJourney(page, info, initial, async ({ read, checkpoint }) => {
        const expected = await mobileTapPlace(page, read, checkpoint, 0.72);
        expect(expected.components.slice(0, 4)).toEqual(initial.components);
        return expected;
      });
    },
  );

  mobilePlacementTest(
    `MOBILE-ADD-CONNECT cancellation stays deliberate ${width}x${height}`,
    async ({ page }, info) => {
      await page.setViewportSize({ width, height });
      await mobilePlacementJourney(
        page,
        info,
        mobileEmptyDocument(),
        async ({ read, checkpoint, puts }) => {
          const before = await read();
          await page.getByRole('button', { name: 'Резистор', exact: true }).tap();
          await expect(page.locator('.workbench-canvas')).toHaveClass(/placing/);
          await checkpoint('before-cancel');
          // Deliberately strict in BOTH refs: missing cancellation is never a skipped PASS.
          const cancel = page.getByRole('button', { name: 'Отменить размещение', exact: true });
          await expect(cancel).toBeVisible();
          await cancel.tap();
          await expect(page.locator('.workbench-canvas')).not.toHaveClass(/placing/);
          const box = await page.locator('.workbench-canvas').boundingBox();
          if (!box) throw new Error('Missing canvas after cancellation');
          await page.touchscreen.tap(box.x + box.width * 0.7, box.y + box.height * 0.7);
          expect(await read()).toEqual(before);
          expect(puts).toHaveLength(0);
          await checkpoint('cancelled-without-landing');
          return null;
        },
      );
    },
  );

  mobilePlacementTest(
    `MOBILE-ADD-CONNECT native tap and held wire Save reopen ${width}x${height}`,
    async ({ page }, info) => {
      await page.setViewportSize({ width, height });
      await mobilePlacementJourney(
        page,
        info,
        mobileEmptyDocument(),
        async ({ read, checkpoint }) => {
          const first = await mobileTapPlace(page, read, checkpoint, 0.32);
          const pair = await mobileTapPlace(page, read, checkpoint, 0.72);
          expect(first.components).toHaveLength(1);
          expect(pair.components).toHaveLength(2);
          // Close the selected part's inspector through the existing empty-field gesture.
          const clear = await page.locator('.workbench-canvas').evaluate((node) => {
            const box = node.getBoundingClientRect();
            const point = { x: box.x + box.width * 0.12, y: box.y + box.height * 0.88 };
            if (
              !document.elementFromPoint(point.x, point.y)?.classList.contains('workbench-grid-hit')
            ) {
              throw new Error('Empty-field deselection point is obscured');
            }
            return point;
          });
          await page.touchscreen.tap(clear.x, clear.y);
          await expect(page.locator('.workbench-inspector')).toHaveCount(0);
          expect(await read()).toEqual(pair);
          const a = pair.components[0]!.id;
          const b = pair.components[1]!.id;
          const source = () => mobileTerminalPoint(page, a, 'lead-1');
          const target = () => mobileTerminalPoint(page, b, 'lead-1');
          const tap = async (point: MobilePoint) => page.touchscreen.tap(point.x, point.y);
          const undo = page.getByRole('button', { name: 'Отменить (Ctrl+Z)', exact: true });
          const redo = page.getByRole('button', { name: 'Повторить (Ctrl+Shift+Z)', exact: true });
          await tap(await source());
          await expect(page.locator('.workbench-wire-preview')).toHaveCount(1);
          await checkpoint('first-terminal-pending');
          await tap(await target());
          await expect(page.getByTestId('schematic-wire')).toHaveCount(1);
          const connected = await read();
          const expectedWire = {
            id: connected.connections[0]!.id,
            from: { componentId: a, terminal: 'lead-1' },
            to: { componentId: b, terminal: 'lead-1' },
            color: '#149447',
            vertices: [],
          };
          expect(connected).toEqual({ ...pair, connections: [expectedWire] });
          await checkpoint('tap-wire', connected);
          await undo.tap();
          expect(await read()).toEqual(pair);
          await redo.tap();
          expect(await read()).toEqual(connected);
          await undo.tap();
          expect(await read()).toEqual(pair);
          const start = await source();
          await mobileNativeDrag(page, start, { x: start.x - 24, y: start.y - 24 }, true);
          await expect(page.locator('.workbench-wire-preview')).toHaveCount(0);
          expect(await read()).toEqual(pair);
          await checkpoint('wire-gesture-cancelled');
          await mobileNativeDrag(page, await source(), await target());
          await expect(page.getByTestId('schematic-wire')).toHaveCount(1);
          const held = await read();
          const expected = {
            ...pair,
            connections: [{ ...expectedWire, id: held.connections[0]!.id }],
          };
          expect(held).toEqual(expected);
          await expect(page.locator('.workbench-wire-preview')).toHaveCount(0);
          await checkpoint('held-wire', expected);
          return expected;
        },
      );
    },
  );
}

for (const width of [1024, 1440]) {
  test(`MOBILE-ADD-CONNECT desktop placement cue regression ${width}`, async ({ page }, info) => {
    await page.setViewportSize({ width, height: 900 });
    await mobilePlacementJourney(page, info, mobileEmptyDocument(), async ({ checkpoint }) => {
      await page.getByRole('button', { name: 'Резистор', exact: true }).press('Enter');
      await expect(page.locator('.workbench-canvas')).toHaveClass(/placing/);
      await checkpoint('desktop-keyboard-placement');
      await expect
        .soft(page.getByRole('status').filter({ hasText: /резистор.*(?:место|поле)/is }))
        .toBeVisible();
      const cancel = page.getByRole('button', { name: 'Отменить размещение', exact: true });
      await expect(cancel).toBeVisible();
      await cancel.click();
      await expect(page.locator('.workbench-canvas')).not.toHaveClass(/placing/);
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= document.documentElement.clientWidth,
        ),
      ).toBe(true);
      return null;
    });
  });
}
