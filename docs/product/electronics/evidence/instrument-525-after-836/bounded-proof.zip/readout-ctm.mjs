import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createRequire } from 'node:module';
import { chromium } from '@playwright/test';

const require = createRequire(import.meta.url);
const { build } = createRequire(require.resolve('vite'))('esbuild');
const catalog = readFileSync('apps/web/public/assets/electronics/component-database/catalog.json', 'utf8');
const source = `
import React from 'react'; import {createRoot} from 'react-dom/client'; import {flushSync} from 'react-dom';
import {ProductionComponentVisual} from './src/electronics/ProductionComponentVisual';
import {configureProductionLibrary} from './src/electronics/production-manifest-adapter';
import {catalogEntry,renderedSize} from './src/electronics/component-catalog';
import {componentTransform} from './src/electronics/workbench-model';
configureProductionLibrary(${catalog});
const root=createRoot(document.getElementById('stage'));
window.configure=(rotation,mirrorX,mirrorY)=>flushSync(()=>root.render(<>{['multimeter','regulated-power-supply','signal-generator','oscilloscope'].map((id,i)=>{
 const entry=catalogEntry(id);const size=renderedSize(entry,0);
 const component={id,componentTypeId:id,kind:entry.kind,value:entry.defaultValue,state:true,rotation,position:{x:40+(i%2)*500,y:40+Math.floor(i/2)*500},stateProperties:{mirrorX,mirrorY,outputEnabled:true,frequencyHz:1000,amplitudeVpp:5,dcOffsetVolt:-1}};
 const result=id==='multimeter'?{measurementMode:'dc-voltage',measuredValue:-3}:id==='regulated-power-supply'?{voltageDrop:5,current:.05,regulationMode:'cv'}:{oscilloscopeInputVoltageVolt:-3,oscilloscopeTrace:[{timeMs:0,voltageVolt:-3},{timeMs:1,voltageVolt:2}]};
 return <g key={id} data-proof-id={id} transform={componentTransform(component)}><ProductionComponentVisual entry={entry} component={component} width={size.width} height={size.height} simulationRunning={true} result={result}/></g>;
})}</>));
`;
const ui = (await build({bundle:true,write:false,platform:'browser',format:'iife',jsx:'automatic',stdin:{contents:source,loader:'tsx',resolveDir:resolve('apps/web')},loader:{'.css':'empty'},alias:Object.fromEntries(['','/rendering','/simulation','/engine'].map(s=>['@asa-lab/electronics'+s,resolve('contexts/electronics/'+(s.slice(1)||'index')+'.ts')])),define:{'process.env.NODE_ENV':'"production"','import.meta.env':'{}'}})).outputFiles[0].text;
const css=readFileSync('apps/web/src/electronics/workbench.css','utf8');
const browser=await chromium.launch({headless:true});
const errors=[],rows=[];
try {
 const context=await browser.newContext({viewport:{width:1440,height:1200}});const page=await context.newPage();
 page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 await context.route('https://readout525.invalid/**',route=>{
  const path=new URL(route.request().url()).pathname;
  if(path.startsWith('/assets/'))return route.fulfill({body:readFileSync(resolve('apps/web/public','.'+path)),contentType:'image/svg+xml'});
  return route.fulfill({contentType:'text/html',body:'<!doctype html><style>'+css+'body{margin:0}</style><svg id="stage" width="1600" height="1200" viewBox="0 0 1600 1200"></svg><script>'+ui+'</script>'});
 });
 await page.goto('https://readout525.invalid/');
 const selector='.workbench-multimeter-reading,.workbench-regulated-supply-reading,.workbench-signal-generator-readings text,.workbench-oscilloscope-status,.workbench-oscilloscope-scale';
 for(const width of [1440,1024,390,320])for(const rotation of [0,90,180,270])for(const [x,y] of [[false,false],[true,false],[false,true],[true,true]]){
  await page.setViewportSize({width,height:1200});await page.evaluate(([r,x,y])=>window.configure(r,x,y),[rotation,x,y]);
  await page.waitForFunction(s=>document.querySelectorAll(s).length===8,selector);
  const sample=await page.locator(selector).evaluateAll(texts=>texts.map(text=>{
   const m=text.getScreenCTM(),p=text.parentElement.getScreenCTM(),b=text.getBBox();const c=new DOMPoint(b.x+b.width/2,b.y+b.height/2);
   const a=c.matrixTransform(m),expected=c.matrixTransform(p);
   return {id:text.closest('[data-proof-id]').getAttribute('data-proof-id'),text:text.textContent,axes:[m.a/Math.hypot(m.a,m.b),m.b/Math.hypot(m.a,m.b),m.c/Math.hypot(m.c,m.d),m.d/Math.hypot(m.c,m.d)],centerError:Math.hypot(a.x-expected.x,a.y-expected.y)};
  }));
  const r=rotation*Math.PI/180,expected=[Math.cos(r),Math.sin(r),-Math.sin(r),Math.cos(r)];
  for(const item of sample){assert.ok(item.axes.every((n,i)=>Math.abs(n-expected[i])<1e-6),JSON.stringify({width,rotation,x,y,item,expected}));assert.ok(item.centerError<1e-4,JSON.stringify({width,rotation,x,y,item}));}
  rows.push({width,rotation,x,y,sample});
 }
 assert.deepEqual(errors,[]);
 await page.screenshot({path:new URL('readouts-320-xy.png',import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'),fullPage:true});
 await context.close();
 writeFileSync(new URL('readout-ctm-result.json',import.meta.url),JSON.stringify({qualification:'bounded_visual_CTM_not_full_native_journey_or_worker_timing',poses:rows.length,readings:rows.reduce((n,r)=>n+r.sample.length,0),errors,rows},null,2)+'\n');
 console.log(JSON.stringify({poses:rows.length,readings:rows.length*8,errors}));
} finally {await browser.close();}
