const fs = require('node:fs');
const crypto = require('node:crypto');
const path = 'apps/web/src/electronics/testing/arduino-check-messages.browser.mjs';
const original = fs.readFileSync(path, 'utf8');
const replacements = [
  ["const output = resolve('docs/product/electronics/evidence/arduino-check-863', phase);", "const output = resolve('test-results/review-863', phase);"],
  ["resolve(output, '../before/structures.json')", "resolve('docs/product/electronics/evidence/arduino-check-863/before/structures.json')"],
  ["resolve(output, '../before/native.json')", "resolve('docs/product/electronics/evidence/arduino-check-863/before/native.json')"],
];
let probe = original;
for (const [from, to] of replacements) {
  if (probe.split(from).length !== 2) throw Error('replacement not unique');
  probe = probe.replace(from, to);
}
fs.writeFileSync('test-results/review-863/native-probe.mjs', probe);
fs.writeFileSync('test-results/review-863/probe-delta.json', JSON.stringify({ replacements, originalSha256: crypto.createHash('sha256').update(original).digest('hex'), probeSha256: crypto.createHash('sha256').update(probe).digest('hex') }, null, 2));
console.log('Probe prepared: only output and BEFORE input paths changed; all assertions retained');
